package com.liguanghong.gdqylatitude.adapter;

public class SignAdapter {
}
