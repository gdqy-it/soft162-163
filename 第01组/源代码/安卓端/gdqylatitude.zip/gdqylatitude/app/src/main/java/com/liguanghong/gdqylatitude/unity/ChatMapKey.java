package com.liguanghong.gdqylatitude.unity;

public class ChatMapKey {

    private boolean isSingle;

    private Integer targetID;

    public boolean isSingle() {
        return isSingle;
    }

    public void setSingle(boolean single) {
        isSingle = single;
    }

    public Integer getTargetID() {
        return targetID;
    }

    public void setTargetID(Integer targetID) {
        this.targetID = targetID;
    }
}
