package com.liguanghong.gdqylatitude.mapper;

import com.liguanghong.gdqylatitude.pojo.User;
import com.liguanghong.gdqylatitude.pojo.UserExample;
import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface UserMapper {
	
	List<User> selectAllByExample(UserExample example);
	
    List<User> selectAllByExamplePrivate(UserExample example);
    
    User selectByExample(UserExample example);
    
    User selectByExamplePrivate(UserExample example);
    
    User selectByPrimaryKey(Integer userid);
    
    User selectByPrimaryKeyPrivate(Integer userid);
    
    int deleteByPrimaryKey(Integer userid);
    
    int deleteByExample(UserExample example);
    
    int insert(User user);
    
    int insertSelective(User user);
    
    int countByExample(UserExample example);
    
    int updateByExampleSelective(@Param("record") User user, @Param("example") UserExample example);
    
    int updateByExample(@Param("record") User user, @Param("example") UserExample example);
    
    int updateByPrimaryKeySelective(User user);
    
    int updateByPrimaryKey(User user);
    
}