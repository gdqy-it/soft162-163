package com.liguanghong.gdqylatitude.controller;


import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.liguanghong.gdqylatitude.pojo.Dynamic;
import com.liguanghong.gdqylatitude.service.DynamicService;
import com.liguanghong.gdqylatitude.util.JsonResult;

@Controller
@RequestMapping("/dynamic")  
public class DynamicController {
	@Resource(name="dynamicService")
	private DynamicService dynamicService;
	
	/**
	 * ������̬
	 * @param dynamic
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/public", method=RequestMethod.POST)
	public JsonResult<Integer> publicDynamic(Dynamic dynamic){
		return dynamicService.publicDynamic(dynamic);
	}
	
	/**
	 * ���ҡ��ҡ��Ķ�̬
	 * @param dynamic
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/findmy", method=RequestMethod.POST)
	public JsonResult<List<Dynamic>> findMyDynamic(Integer userid){
		return dynamicService.findMyDynamic(userid);
	}
	
	/**
	 * ���ҡ��ҡ��ĺ��ѵĶ�̬
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/findfriends", method=RequestMethod.POST)
	public JsonResult<List<Dynamic>> findFriendsDynamic(Integer userid){
		return dynamicService.findFriendsDynamic(userid);
	}
	
}
