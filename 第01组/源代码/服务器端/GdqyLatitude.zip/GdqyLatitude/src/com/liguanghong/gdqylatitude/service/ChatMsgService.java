package com.liguanghong.gdqylatitude.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.liguanghong.gdqylatitude.mapper.ChatMsgMapper;
import com.liguanghong.gdqylatitude.pojo.ChatMsg;
import com.liguanghong.gdqylatitude.pojo.ChatMsgExample;
import com.liguanghong.gdqylatitude.pojo.ChatMsgExample.Criteria;

@Service("chatMsgService")
public class ChatMsgService {
	@Resource
	private ChatMsgMapper dao;
	
	/**
	 * ���������¼
	 * @param chatMsg
	 */
	public void saveMsg(ChatMsg chatMsg){
		dao.insert(chatMsg);
	}
	
	/**
	 * ��ȡ������Ϣ
	 * @param targetID
	 * @return
	 */
	public List<ChatMsg> getMsg(Integer targetID, List<Integer> groupListID) {
		List<ChatMsg> list = new ArrayList<>();
		ChatMsgExample example1 = new ChatMsgExample();
		Criteria criteria1 = example1.createCriteria();
		criteria1.andReceiveridEqualTo(targetID);
		criteria1.andIssingleEqualTo(true);
		list.addAll(dao.selectByExampleWithBLOBs(example1));
		
		if(!groupListID.isEmpty()) {
			ChatMsgExample example2 = new ChatMsgExample();
			Criteria criteria2 = example2.createCriteria();
			criteria2.andReceiveridIn(groupListID);
			criteria2.andIssingleEqualTo(false);
			list.addAll(dao.selectByExampleWithBLOBs(example2));	
		}
		
		return list;
	}
	
	/**
	 * ɾ���Ѷ�������Ϣ
	 * @param chatMsg
	 */
	public void deleteMsg(ChatMsg chatMsg) {
		dao.deleteByPrimaryKey(chatMsg.getMsgid());
	}

}
