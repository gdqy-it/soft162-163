package com.liguanghong.gdqylatitude.pojo;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * ���ѷ���
 * @author LGH
 *
 */
public class FriendsSet {
	
	@JSONField(ordinal = 1)
	private String name;
	@JSONField(ordinal = 2)
	private List<Friend> friends;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Friend> getFriends() {
		return friends == null ? new ArrayList<>() : friends;
	}

	public void setFriends(List<Friend> friends) {
		this.friends = friends;
	}

	public void addFriend(Friend friend) {
		this.friends.add(friend);
	}
	
	public void addFriends(List<Friend> newFriends) {
		this.friends.addAll(newFriends);
	}
	
	public void deleteFriend(Friend friend) {
		this.friends.remove(friend);
	}
	
}
