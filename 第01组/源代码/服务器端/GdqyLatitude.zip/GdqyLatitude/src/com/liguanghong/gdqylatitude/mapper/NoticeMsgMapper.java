package com.liguanghong.gdqylatitude.mapper;

import com.liguanghong.gdqylatitude.pojo.NoticeMsg;
import com.liguanghong.gdqylatitude.pojo.NoticeMsgExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NoticeMsgMapper {
    int countByExample(NoticeMsgExample example);

    int deleteByExample(NoticeMsgExample example);

    int deleteByPrimaryKey(Integer noticeid);

    int insert(NoticeMsg record);

    int insertSelective(NoticeMsg record);

    List<NoticeMsg> selectByExample(NoticeMsgExample example);

    NoticeMsg selectByPrimaryKey(Integer noticeid);

    int updateByExampleSelective(@Param("record") NoticeMsg record, @Param("example") NoticeMsgExample example);

    int updateByExample(@Param("record") NoticeMsg record, @Param("example") NoticeMsgExample example);

    int updateByPrimaryKeySelective(NoticeMsg record);

    int updateByPrimaryKey(NoticeMsg record);
}