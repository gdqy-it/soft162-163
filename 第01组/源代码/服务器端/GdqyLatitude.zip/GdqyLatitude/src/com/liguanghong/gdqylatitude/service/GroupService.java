 package com.liguanghong.gdqylatitude.service;


import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.liguanghong.gdqylatitude.mapper.GroupchatMapper;
import com.liguanghong.gdqylatitude.mapper.UserMapper;
import com.liguanghong.gdqylatitude.pojo.Groupchat;
import com.liguanghong.gdqylatitude.pojo.GroupchatExample;
import com.liguanghong.gdqylatitude.pojo.User;
import com.liguanghong.gdqylatitude.pojo.UserExample;
import com.liguanghong.gdqylatitude.pojo.GroupchatExample.Criteria;
import com.liguanghong.gdqylatitude.util.JsonResult;

@Service("groupService")
public class GroupService {
	
	@Resource
	private GroupchatMapper dao;
	
	@Resource
	private UserMapper userDao;

	/**
	 * ����Ⱥ��
	 * @param userid
	 * @param groupName
	 * @return
	 */
	public JsonResult<Groupchat> createGroup(Groupchat groupchat){
		GroupchatExample example = new GroupchatExample();
		Criteria criteria = example.createCriteria();
		criteria.andOwneridEqualTo(groupchat.getOwnerid());
		List<Groupchat> list = dao.selectByExample(example);
		for(Groupchat tempGroup : list) {
			if(tempGroup.getGroupname().equals(groupchat.getGroupname())) {
				return new JsonResult<Groupchat>(false, "��Ⱥ������ռ�ã��������ԣ�");
			}
		}
		groupchat.setGroupmember("["+groupchat.getOwnerid()+"]");
		//Ⱥ��������½�Ⱥ��
		int row = dao.insertSelective(groupchat);
		if(row > 0) {
			GroupchatExample example2 = new GroupchatExample();
			Criteria criteria2 = example2.createCriteria();
			criteria2.andGroupnameEqualTo(groupchat.getGroupname());
			criteria2.andOwneridEqualTo(groupchat.getOwnerid());
			List<Groupchat> ll = dao.selectByExampleWithBLOBs(example2);
			groupchat = ll.get(0);
			return new JsonResult<Groupchat>(true, "����Ⱥ��ɹ�", groupchat);
		} else {
			return new JsonResult<Groupchat>(false, "����Ⱥ��ʧ��");
		}
	}
	
	/**
	 * ɾ��Ⱥ��
	 * @param userid
	 * @param groupid
	 * @return
	 */
	public JsonResult<Integer> deleteGroup(Integer userid, Integer groupid){
		GroupchatExample example = new GroupchatExample();
		Criteria criteria = example.createCriteria();
		criteria.andGroupidEqualTo(groupid);
		criteria.andOwneridEqualTo(userid);
		int row = dao.deleteByExample(example);
		if(row > 0) {
			return new JsonResult<Integer>(true, "ɾ��Ⱥ��ɹ�");
		} else {
			return new JsonResult<Integer>(false, "ɾ��Ⱥ��ʧ��");
		}
	}
	
	/**
	 * ����Ⱥ����Ϣ
	 * @param groupid
	 * @param groupName
	 * @param groupAnnouncement
	 * @param groupHeadPortrait
	 * @return
	 */
	public JsonResult<Groupchat> updateGroup(Groupchat groupchat){
		int row = dao.updateByPrimaryKeySelective(groupchat);
		if(row > 0) {
			return new JsonResult<Groupchat>(true, "����Ⱥ����Ϣ�ɹ�", groupchat);
		} else {
			return new JsonResult<Groupchat>(false, "����Ⱥ����Ϣʧ��");	
		}
	}
	
	/**
	 * ģ������Ⱥ��
	 * @param userid
	 * @param keyword
	 * @return
	 */
	public JsonResult<PageInfo<Groupchat>> search(Integer userid, String keyword, Integer page){
		GroupchatExample example = new GroupchatExample();
		Criteria criteria = example.createCriteria();
		if(keyword != null) {
			keyword = "%" + keyword + "%";
			criteria.andGroupnameLike(keyword);
		}
		PageHelper.startPage(page, 10); 
		List<Groupchat> list = dao.selectByExampleWithBLOBs(example);
		PageInfo<Groupchat> pageInfo = new PageInfo<>(list);
		if(list != null) {
			return new JsonResult<PageInfo<Groupchat>>(true, "��ѯȺ��ɹ�", pageInfo);
		} else {
			return new JsonResult<PageInfo<Groupchat>>(false, "��ѯȺ��ʧ��");
		}
	}
	
	/**
	 * ��ѯȺ��Ա��Ϣ����ָ����ѯ����
	 * @param userid
	 * @param groupid
	 * @param size
	 * @return
	 */
	public JsonResult<List<User>> searchMember(Integer userid, Integer groupid, Integer size){
		Groupchat groupchat = dao.selectByPrimaryKey(groupid);
		List<Integer> list = JSONArray.parseArray(groupchat.getGroupmember(), Integer.class);
		int maxSize;
		if(list == null)
			return new JsonResult<List<User>>(true, "");
		if(null == size || size > list.size()) {
			maxSize = list.size();
		} else {
			maxSize = size;
		}
		List<User> members = new ArrayList<User>();
		for(int i = 0; i < maxSize; i++) {
			User user = userDao.selectByPrimaryKey(list.get(i));
			members.add(user);
		}
		return new JsonResult<List<User>>(true, "��ѯ�ɹ�", members);
	}
	
	/**
	 * ��ѯ����Ⱥ��
	 * @return
	 */
	public JsonResult<List<Groupchat>> findAll(){
		GroupchatExample example = new GroupchatExample();
		List<Groupchat> list = dao.selectByExampleWithBLOBs(example);
		return new JsonResult<List<Groupchat>>(true, "��ѯ�ɹ�", list);
	}
	
	/**
	 * ��ѯȺ������
	 * @param status
	 * @return
	 */
	public JsonResult<Integer> getCount(Integer status){
		GroupchatExample example = new GroupchatExample();
		if(status != null) {
			Criteria criteria = example.createCriteria();
			criteria.andStatusEqualTo(status);
		}
		int count = dao.countByExample(example);
		return new JsonResult<Integer>(true, "��ѯ�ɹ�", count);
	}
	
	/**
	 * ��ȡ�����Ⱥ���б�
	 * @param userid
	 * @return
	 */
	public JsonResult<List<Groupchat>> findMyGroup(Integer userid){
		GroupchatExample example = new GroupchatExample();
		Criteria criteria = example.createCriteria();
		criteria.andOwneridEqualTo(userid);
		List<Groupchat> list = dao.selectByExampleWithBLOBs(example);
		
		UserExample example2 = new UserExample();
		UserExample.Criteria criteria2 = example2.createCriteria();
		criteria2.andUseridEqualTo(userid);
		User user = userDao.selectByExamplePrivate(example2);
		List<Integer> list2 = JSONArray.parseArray(user.getJoingroupid(), Integer.class);
		if(list2 != null &&!list2.isEmpty()) {
			GroupchatExample example3 = new GroupchatExample();
			Criteria criteria3 = example3.createCriteria();
			criteria3.andGroupidIn(list2);
			List<Groupchat> list3 = dao.selectByExampleWithBLOBs(example3);
			list.addAll(list3);
		}
		System.out.println("Ⱥ���б���" + JSONArray.toJSONString(list));
		return new JsonResult<List<Groupchat>>(true, "��ȡȺ���б��ɹ�", list);
	}
	
	/**
	 * ����ָ��Ⱥ��
	 * @param groupid
	 * @return
	 */
	public Groupchat findGroupByID(Integer groupid) {
		return dao.selectByPrimaryKey(groupid);
	}
	
	/**
	 * ����Ⱥ��
	 * @param userid
	 * @param groupid
	 * @return
	 */
	public JsonResult<Integer> joininGroup(Integer userid, Integer groupid){
		Groupchat groupchat = dao.selectByPrimaryKey(groupid);
		if(groupchat == null)
			return new JsonResult<Integer>(false, "Ⱥ�鲻����");
	
		UserExample example = new UserExample();
		UserExample.Criteria criteria = example.createCriteria();
		criteria.andUseridEqualTo(userid);
		User user = userDao.selectByExample(example);
		List<Integer> list = JSONArray.parseArray(user.getJoingroupid(), Integer.class);
		
		if(list == null)
			list = new ArrayList<Integer>();
		else if(list.remove(groupid)) {
			return new JsonResult<Integer>(false, "�Ѿ������Ⱥ��");
		}
		
		list.add(groupid);
		user.setJoingroupid(JSONArray.toJSONString(list));
		int row = userDao.updateByPrimaryKeySelective(user);
		if(row > 0) {
			List<Integer> menber = JSONArray.parseArray(groupchat.getGroupmember(), Integer.class);
			menber.add(userid);
			groupchat.setGroupmember(JSONArray.toJSONString(menber));
			groupchat.setGroupnum(groupchat.getGroupnum()+1);
			dao.updateByPrimaryKeySelective(groupchat);
			return new JsonResult<Integer>(true, "����Ⱥ��ɹ�");
		} else {
			return new JsonResult<Integer>(false, "����Ⱥ��ʧ��");
		}
	}
	
	/**
	 * �˳�Ⱥ��
	 * @param userid
	 * @param groupid
	 * @return
	 */
	public JsonResult<Integer> quitGroup(Integer userid, Integer groupid){
		Groupchat groupchat = dao.selectByPrimaryKey(groupid);
		if(groupchat == null)
			return new JsonResult<Integer>(false, "Ⱥ�鲻����");
		
		UserExample example = new UserExample();
		UserExample.Criteria criteria = example.createCriteria();
		criteria.andUseridEqualTo(userid);
		User user = userDao.selectByExample(example);
		List<Integer> list = JSONArray.parseArray(user.getJoingroupid(), Integer.class);
		if(list.remove(groupid)) {
			user.setJoingroupid(JSONArray.toJSONString(list));
			int row = userDao.updateByPrimaryKeySelective(user);
			if(row > 0) {
				List<Integer> menber = JSONArray.parseArray(groupchat.getGroupmember(), Integer.class);
				menber.remove(userid);
				groupchat.setGroupmember(JSONArray.toJSONString(menber));
				dao.updateByPrimaryKeySelective(groupchat);
				return new JsonResult<Integer>(true, "�˳�Ⱥ��ɹ�");
			} else {
				return new JsonResult<Integer>(false, "�˳�Ⱥ��ʧ��");
			}
		} else {
			return new JsonResult<Integer>(false, "��û�����Ⱥ");
		}
		
	}
	
	/**
	 * ����Ⱥ��
	 * @param groupid
	 * @return
	 */
	public JsonResult<Integer> freeze(Integer groupid) {
		Groupchat groupchat = dao.selectByPrimaryKey(groupid);
		if(groupchat == null) {
			return new JsonResult<Integer>(false, "Ⱥ�鲻����");
		}else if(groupchat.getStatus() == 0) {
			//�Ѿ��Ƕ���״̬
			return new JsonResult<Integer>(false, "��Ⱥ���Ѿ������ᣬ�����ظ�����");
		}else {
			//���ж���
			groupchat.setStatus(0);
			int rows = dao.updateByPrimaryKeySelective(groupchat);
			if(rows == 1)
				return new JsonResult<Integer>(true, "����ɹ�");
			else
				return new JsonResult<Integer>(false, "����ʧ�ܣ�δ֪ԭ��");
		}
	}
	
	/**
	 * ���Ⱥ��
	 * @param groupid
	 * @return
	 */
	public JsonResult<Integer> unFreeze(Integer groupid) {
		Groupchat groupchat = dao.selectByPrimaryKey(groupid);
		if(groupchat == null) {
			return new JsonResult<Integer>(false, "���ʧ�ܣ�Ⱥ�鲻����");
		}else if(groupchat.getStatus() != 0) {
			//�˻�״̬����
			return new JsonResult<Integer>(false, "���ʧ�ܣ�Ⱥ��״̬����������Ҫ���");
		}else {
			//���н��
			groupchat.setStatus(2);
			int rows =  dao.updateByPrimaryKeySelective(groupchat);
			if(rows == 1)
				return new JsonResult<Integer>(true, "���ɹ�");
			else
				return new JsonResult<Integer>(false, "���ʧ�ܣ�δ֪ԭ��");
		}
	}
	
}
