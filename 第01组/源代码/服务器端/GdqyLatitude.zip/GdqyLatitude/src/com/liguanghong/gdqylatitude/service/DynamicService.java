package com.liguanghong.gdqylatitude.service;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.liguanghong.gdqylatitude.mapper.DynamicMapper;
import com.liguanghong.gdqylatitude.mapper.UserMapper;
import com.liguanghong.gdqylatitude.pojo.Dynamic;
import com.liguanghong.gdqylatitude.pojo.DynamicExample;
import com.liguanghong.gdqylatitude.pojo.Friend;
import com.liguanghong.gdqylatitude.pojo.DynamicExample.Criteria;
import com.liguanghong.gdqylatitude.pojo.FriendsSet;
import com.liguanghong.gdqylatitude.pojo.User;
import com.liguanghong.gdqylatitude.pojo.UserExample;
import com.liguanghong.gdqylatitude.util.JsonResult;

@Service("dynamicService")
public class DynamicService {
	
	@Resource
	private DynamicMapper dao;
	@Resource
	private UserMapper userDao;

	public JsonResult<Integer> publicDynamic(Dynamic dynamic){
		System.out.println(dynamic.getPic());
		System.out.println(dynamic.getPic2());
		System.out.println(dynamic.getPic3());
		dynamic.setPostedtime(new Date());
		int row = dao.insertSelective(dynamic);
		if(row > 0) {
			return new JsonResult<Integer>(true, "�����ɹ�");
		} else {
			return new JsonResult<Integer>(false, "����ʧ��");
		}
	}
	
	public JsonResult<List<Dynamic>> findMyDynamic(Integer userid){
		DynamicExample example = new DynamicExample();
		Criteria criteria = example.createCriteria();
		criteria.andUseridEqualTo(userid);
		List<Dynamic> list = dao.selectByExampleWithBLOBs(example);
		return new JsonResult<List<Dynamic>>(true, "��ѯ�ɹ�", list);
	}
	
	public JsonResult<List<Dynamic>> findFriendsDynamic(Integer userid){
		UserExample userExample = new UserExample();
		UserExample.Criteria userCriteria = userExample.createCriteria();
		userCriteria.andUseridEqualTo(userid);
		User user = userDao.selectByExamplePrivate(userExample);
		List<Integer> friendsID = new ArrayList<>();
		List<FriendsSet> friendsSets = JSONArray.parseArray(user.getFriendsid(), FriendsSet.class);
		for(FriendsSet fs : friendsSets) {
			for(Friend tempFriend : fs.getFriends()) {
				friendsID.add(tempFriend.getFriendid());
			}
		}
		
		DynamicExample example = new DynamicExample();
		for(Integer id : friendsID) {
			Criteria criteria = example.createCriteria();
			criteria.andUseridEqualTo(id);
			example.or(criteria);
		}
		
		List<Dynamic> list = dao.selectByExampleWithBLOBs(example);
		return new JsonResult<List<Dynamic>>(true, "��ѯ�ɹ�", list);
	}
	
}
