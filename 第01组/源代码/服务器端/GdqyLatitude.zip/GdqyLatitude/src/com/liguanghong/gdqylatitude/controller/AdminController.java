package com.liguanghong.gdqylatitude.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.liguanghong.gdqylatitude.pojo.Admin;
import com.liguanghong.gdqylatitude.service.AdminService;;

@Controller
@RequestMapping("/admin")  
public class AdminController {
	@Resource(name="adminService")
	private AdminService adminService;
	
	@RequestMapping(value="/login")
	public String queryById(@RequestParam("logname") String logname,
			@RequestParam("password") String password){
		System.out.println("controller");
		ModelAndView mv = new ModelAndView();
		try{
			Admin var = adminService.login(logname, password);
			if(var != null) {
				mv.setViewName("user");
				mv.addObject("var", var);
				return "redirect:/user.jsp";
			} else {
				
			}
		} catch(Exception e){
            e.printStackTrace();
		}
		return "redirect:/user.jsp";
	}
	
}
