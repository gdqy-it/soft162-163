package com.liguanghong.gdqylatitude.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.liguanghong.gdqylatitude.pojo.Groupchat;
import com.liguanghong.gdqylatitude.pojo.User;
import com.liguanghong.gdqylatitude.service.GroupService;
import com.liguanghong.gdqylatitude.util.JsonResult;;

@Controller
@RequestMapping("/group")  
public class GroupController {
	@Resource(name="groupService")
	private GroupService groupService;

	/**
	 * api-group-001-����Ⱥ��
	 * @param userid
	 * @param groupname
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/creategroup", method=RequestMethod.POST)
	public JsonResult<Groupchat> createGroup(Groupchat groupchat){
		return groupService.createGroup(groupchat);
	}
	
	/**
	 * api-group-002-ɾ��Ⱥ��
	 * @param userid
	 * @param groupid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/deletegroup", method=RequestMethod.POST)
	public JsonResult<Integer> deleteGroup(@RequestParam("userid") Integer userid,
			@RequestParam("groupid") Integer groupid){
		return groupService.deleteGroup(userid, groupid);
	}

	/**
	 * api-group-003-����Ⱥ����Ϣ
	 * @param groupchat
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/updategroup", method=RequestMethod.POST)
	public JsonResult<Groupchat> updateGroup(Groupchat groupchat){
		return groupService.updateGroup(groupchat);
	}
	
	/**
	 * api-group-004-ģ������Ⱥ��
	 * @param userid
	 * @param keyword
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/search", method=RequestMethod.POST)
	public JsonResult<PageInfo<Groupchat>> search(@RequestParam("userid") Integer userid,
			@RequestParam("keyword") String keyword,
			@RequestParam("page") Integer page){
		return groupService.search(userid, keyword, page);
	}
	
	/**
	 * ��ѯȺ��Ա��Ϣ����ָ����ѯ����
	 * @param userid
	 * @param groupid
	 * @param size
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/searchmember", method=RequestMethod.POST)
	public JsonResult<List<User>> searchMember(@RequestParam("userid") Integer userid,
			@RequestParam("groupid") Integer groupid,
			@RequestParam("size") Integer size){
		return groupService.searchMember(userid, groupid, size);
	}
	
	/**
	 * ��ȡ�����Ⱥ���б�
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/fingmygroup", method=RequestMethod.POST)
	public JsonResult<List<Groupchat>> findMyGroup(@RequestParam("userid") Integer userid){
		return groupService.findMyGroup(userid);
	}
	
	
	/**
	 * api-group-005-����Ⱥ��
	 * @param userid
	 * @param groupid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/joiningroup", method=RequestMethod.POST)
	public JsonResult<Integer> joininGroup(@RequestParam("userid") Integer userid,
			@RequestParam("groupid") Integer groupid){
		return groupService.joininGroup(userid, groupid);
	}
	
	/**
	 * api-group-006-�˳�Ⱥ��
	 * @param userid
	 * @param groupid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/quitgroup", method=RequestMethod.POST)
	public JsonResult<Integer> quitGroup(@RequestParam("userid") Integer userid,
			@RequestParam("groupid") Integer groupid){
		return groupService.quitGroup(userid, groupid);
	}
	
	/**
	 * api-user-007-����
	 * @param groupid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/freeze", method=RequestMethod.POST)
	public JsonResult<Integer> freeze(@RequestParam("groupid") Integer groupid){
		return groupService.freeze(groupid);
	}
	
	/**
	 * api-user-008-���
	 * @param groupid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/unfreeze", method=RequestMethod.POST)
	public JsonResult<Integer> unFreeze(@RequestParam("groupid") Integer groupid){
		return groupService.unFreeze(groupid);
	}
	
}
