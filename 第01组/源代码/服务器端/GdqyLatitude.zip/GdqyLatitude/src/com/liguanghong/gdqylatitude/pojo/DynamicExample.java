package com.liguanghong.gdqylatitude.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DynamicExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public DynamicExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andDynamicidIsNull() {
            addCriterion("dynamicID is null");
            return (Criteria) this;
        }

        public Criteria andDynamicidIsNotNull() {
            addCriterion("dynamicID is not null");
            return (Criteria) this;
        }

        public Criteria andDynamicidEqualTo(Integer value) {
            addCriterion("dynamicID =", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotEqualTo(Integer value) {
            addCriterion("dynamicID <>", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidGreaterThan(Integer value) {
            addCriterion("dynamicID >", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidGreaterThanOrEqualTo(Integer value) {
            addCriterion("dynamicID >=", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidLessThan(Integer value) {
            addCriterion("dynamicID <", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidLessThanOrEqualTo(Integer value) {
            addCriterion("dynamicID <=", value, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidIn(List<Integer> values) {
            addCriterion("dynamicID in", values, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotIn(List<Integer> values) {
            addCriterion("dynamicID not in", values, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidBetween(Integer value1, Integer value2) {
            addCriterion("dynamicID between", value1, value2, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andDynamicidNotBetween(Integer value1, Integer value2) {
            addCriterion("dynamicID not between", value1, value2, "dynamicid");
            return (Criteria) this;
        }

        public Criteria andUseridIsNull() {
            addCriterion("userID is null");
            return (Criteria) this;
        }

        public Criteria andUseridIsNotNull() {
            addCriterion("userID is not null");
            return (Criteria) this;
        }

        public Criteria andUseridEqualTo(Integer value) {
            addCriterion("userID =", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotEqualTo(Integer value) {
            addCriterion("userID <>", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThan(Integer value) {
            addCriterion("userID >", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThanOrEqualTo(Integer value) {
            addCriterion("userID >=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThan(Integer value) {
            addCriterion("userID <", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThanOrEqualTo(Integer value) {
            addCriterion("userID <=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridIn(List<Integer> values) {
            addCriterion("userID in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotIn(List<Integer> values) {
            addCriterion("userID not in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridBetween(Integer value1, Integer value2) {
            addCriterion("userID between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotBetween(Integer value1, Integer value2) {
            addCriterion("userID not between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andTextIsNull() {
            addCriterion("text is null");
            return (Criteria) this;
        }

        public Criteria andTextIsNotNull() {
            addCriterion("text is not null");
            return (Criteria) this;
        }

        public Criteria andTextEqualTo(String value) {
            addCriterion("text =", value, "text");
            return (Criteria) this;
        }

        public Criteria andTextNotEqualTo(String value) {
            addCriterion("text <>", value, "text");
            return (Criteria) this;
        }

        public Criteria andTextGreaterThan(String value) {
            addCriterion("text >", value, "text");
            return (Criteria) this;
        }

        public Criteria andTextGreaterThanOrEqualTo(String value) {
            addCriterion("text >=", value, "text");
            return (Criteria) this;
        }

        public Criteria andTextLessThan(String value) {
            addCriterion("text <", value, "text");
            return (Criteria) this;
        }

        public Criteria andTextLessThanOrEqualTo(String value) {
            addCriterion("text <=", value, "text");
            return (Criteria) this;
        }

        public Criteria andTextLike(String value) {
            addCriterion("text like", value, "text");
            return (Criteria) this;
        }

        public Criteria andTextNotLike(String value) {
            addCriterion("text not like", value, "text");
            return (Criteria) this;
        }

        public Criteria andTextIn(List<String> values) {
            addCriterion("text in", values, "text");
            return (Criteria) this;
        }

        public Criteria andTextNotIn(List<String> values) {
            addCriterion("text not in", values, "text");
            return (Criteria) this;
        }

        public Criteria andTextBetween(String value1, String value2) {
            addCriterion("text between", value1, value2, "text");
            return (Criteria) this;
        }

        public Criteria andTextNotBetween(String value1, String value2) {
            addCriterion("text not between", value1, value2, "text");
            return (Criteria) this;
        }

        public Criteria andPostedtimeIsNull() {
            addCriterion("postedtime is null");
            return (Criteria) this;
        }

        public Criteria andPostedtimeIsNotNull() {
            addCriterion("postedtime is not null");
            return (Criteria) this;
        }

        public Criteria andPostedtimeEqualTo(Date value) {
            addCriterion("postedtime =", value, "postedtime");
            return (Criteria) this;
        }

        public Criteria andPostedtimeNotEqualTo(Date value) {
            addCriterion("postedtime <>", value, "postedtime");
            return (Criteria) this;
        }

        public Criteria andPostedtimeGreaterThan(Date value) {
            addCriterion("postedtime >", value, "postedtime");
            return (Criteria) this;
        }

        public Criteria andPostedtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("postedtime >=", value, "postedtime");
            return (Criteria) this;
        }

        public Criteria andPostedtimeLessThan(Date value) {
            addCriterion("postedtime <", value, "postedtime");
            return (Criteria) this;
        }

        public Criteria andPostedtimeLessThanOrEqualTo(Date value) {
            addCriterion("postedtime <=", value, "postedtime");
            return (Criteria) this;
        }

        public Criteria andPostedtimeIn(List<Date> values) {
            addCriterion("postedtime in", values, "postedtime");
            return (Criteria) this;
        }

        public Criteria andPostedtimeNotIn(List<Date> values) {
            addCriterion("postedtime not in", values, "postedtime");
            return (Criteria) this;
        }

        public Criteria andPostedtimeBetween(Date value1, Date value2) {
            addCriterion("postedtime between", value1, value2, "postedtime");
            return (Criteria) this;
        }

        public Criteria andPostedtimeNotBetween(Date value1, Date value2) {
            addCriterion("postedtime not between", value1, value2, "postedtime");
            return (Criteria) this;
        }

        public Criteria andLatitudeIsNull() {
            addCriterion("latitude is null");
            return (Criteria) this;
        }

        public Criteria andLatitudeIsNotNull() {
            addCriterion("latitude is not null");
            return (Criteria) this;
        }

        public Criteria andLatitudeEqualTo(Double value) {
            addCriterion("latitude =", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotEqualTo(Double value) {
            addCriterion("latitude <>", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeGreaterThan(Double value) {
            addCriterion("latitude >", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeGreaterThanOrEqualTo(Double value) {
            addCriterion("latitude >=", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeLessThan(Double value) {
            addCriterion("latitude <", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeLessThanOrEqualTo(Double value) {
            addCriterion("latitude <=", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeIn(List<Double> values) {
            addCriterion("latitude in", values, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotIn(List<Double> values) {
            addCriterion("latitude not in", values, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeBetween(Double value1, Double value2) {
            addCriterion("latitude between", value1, value2, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotBetween(Double value1, Double value2) {
            addCriterion("latitude not between", value1, value2, "latitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeIsNull() {
            addCriterion("longitude is null");
            return (Criteria) this;
        }

        public Criteria andLongitudeIsNotNull() {
            addCriterion("longitude is not null");
            return (Criteria) this;
        }

        public Criteria andLongitudeEqualTo(Double value) {
            addCriterion("longitude =", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeNotEqualTo(Double value) {
            addCriterion("longitude <>", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeGreaterThan(Double value) {
            addCriterion("longitude >", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeGreaterThanOrEqualTo(Double value) {
            addCriterion("longitude >=", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeLessThan(Double value) {
            addCriterion("longitude <", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeLessThanOrEqualTo(Double value) {
            addCriterion("longitude <=", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeIn(List<Double> values) {
            addCriterion("longitude in", values, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeNotIn(List<Double> values) {
            addCriterion("longitude not in", values, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeBetween(Double value1, Double value2) {
            addCriterion("longitude between", value1, value2, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeNotBetween(Double value1, Double value2) {
            addCriterion("longitude not between", value1, value2, "longitude");
            return (Criteria) this;
        }

        public Criteria andLikeidIsNull() {
            addCriterion("likeID is null");
            return (Criteria) this;
        }

        public Criteria andLikeidIsNotNull() {
            addCriterion("likeID is not null");
            return (Criteria) this;
        }

        public Criteria andLikeidEqualTo(String value) {
            addCriterion("likeID =", value, "likeid");
            return (Criteria) this;
        }

        public Criteria andLikeidNotEqualTo(String value) {
            addCriterion("likeID <>", value, "likeid");
            return (Criteria) this;
        }

        public Criteria andLikeidGreaterThan(String value) {
            addCriterion("likeID >", value, "likeid");
            return (Criteria) this;
        }

        public Criteria andLikeidGreaterThanOrEqualTo(String value) {
            addCriterion("likeID >=", value, "likeid");
            return (Criteria) this;
        }

        public Criteria andLikeidLessThan(String value) {
            addCriterion("likeID <", value, "likeid");
            return (Criteria) this;
        }

        public Criteria andLikeidLessThanOrEqualTo(String value) {
            addCriterion("likeID <=", value, "likeid");
            return (Criteria) this;
        }

        public Criteria andLikeidLike(String value) {
            addCriterion("likeID like", value, "likeid");
            return (Criteria) this;
        }

        public Criteria andLikeidNotLike(String value) {
            addCriterion("likeID not like", value, "likeid");
            return (Criteria) this;
        }

        public Criteria andLikeidIn(List<String> values) {
            addCriterion("likeID in", values, "likeid");
            return (Criteria) this;
        }

        public Criteria andLikeidNotIn(List<String> values) {
            addCriterion("likeID not in", values, "likeid");
            return (Criteria) this;
        }

        public Criteria andLikeidBetween(String value1, String value2) {
            addCriterion("likeID between", value1, value2, "likeid");
            return (Criteria) this;
        }

        public Criteria andLikeidNotBetween(String value1, String value2) {
            addCriterion("likeID not between", value1, value2, "likeid");
            return (Criteria) this;
        }

        public Criteria andLikenumberIsNull() {
            addCriterion("likeNumber is null");
            return (Criteria) this;
        }

        public Criteria andLikenumberIsNotNull() {
            addCriterion("likeNumber is not null");
            return (Criteria) this;
        }

        public Criteria andLikenumberEqualTo(Integer value) {
            addCriterion("likeNumber =", value, "likenumber");
            return (Criteria) this;
        }

        public Criteria andLikenumberNotEqualTo(Integer value) {
            addCriterion("likeNumber <>", value, "likenumber");
            return (Criteria) this;
        }

        public Criteria andLikenumberGreaterThan(Integer value) {
            addCriterion("likeNumber >", value, "likenumber");
            return (Criteria) this;
        }

        public Criteria andLikenumberGreaterThanOrEqualTo(Integer value) {
            addCriterion("likeNumber >=", value, "likenumber");
            return (Criteria) this;
        }

        public Criteria andLikenumberLessThan(Integer value) {
            addCriterion("likeNumber <", value, "likenumber");
            return (Criteria) this;
        }

        public Criteria andLikenumberLessThanOrEqualTo(Integer value) {
            addCriterion("likeNumber <=", value, "likenumber");
            return (Criteria) this;
        }

        public Criteria andLikenumberIn(List<Integer> values) {
            addCriterion("likeNumber in", values, "likenumber");
            return (Criteria) this;
        }

        public Criteria andLikenumberNotIn(List<Integer> values) {
            addCriterion("likeNumber not in", values, "likenumber");
            return (Criteria) this;
        }

        public Criteria andLikenumberBetween(Integer value1, Integer value2) {
            addCriterion("likeNumber between", value1, value2, "likenumber");
            return (Criteria) this;
        }

        public Criteria andLikenumberNotBetween(Integer value1, Integer value2) {
            addCriterion("likeNumber not between", value1, value2, "likenumber");
            return (Criteria) this;
        }

        public Criteria andTransmitidIsNull() {
            addCriterion("transmitID is null");
            return (Criteria) this;
        }

        public Criteria andTransmitidIsNotNull() {
            addCriterion("transmitID is not null");
            return (Criteria) this;
        }

        public Criteria andTransmitidEqualTo(String value) {
            addCriterion("transmitID =", value, "transmitid");
            return (Criteria) this;
        }

        public Criteria andTransmitidNotEqualTo(String value) {
            addCriterion("transmitID <>", value, "transmitid");
            return (Criteria) this;
        }

        public Criteria andTransmitidGreaterThan(String value) {
            addCriterion("transmitID >", value, "transmitid");
            return (Criteria) this;
        }

        public Criteria andTransmitidGreaterThanOrEqualTo(String value) {
            addCriterion("transmitID >=", value, "transmitid");
            return (Criteria) this;
        }

        public Criteria andTransmitidLessThan(String value) {
            addCriterion("transmitID <", value, "transmitid");
            return (Criteria) this;
        }

        public Criteria andTransmitidLessThanOrEqualTo(String value) {
            addCriterion("transmitID <=", value, "transmitid");
            return (Criteria) this;
        }

        public Criteria andTransmitidLike(String value) {
            addCriterion("transmitID like", value, "transmitid");
            return (Criteria) this;
        }

        public Criteria andTransmitidNotLike(String value) {
            addCriterion("transmitID not like", value, "transmitid");
            return (Criteria) this;
        }

        public Criteria andTransmitidIn(List<String> values) {
            addCriterion("transmitID in", values, "transmitid");
            return (Criteria) this;
        }

        public Criteria andTransmitidNotIn(List<String> values) {
            addCriterion("transmitID not in", values, "transmitid");
            return (Criteria) this;
        }

        public Criteria andTransmitidBetween(String value1, String value2) {
            addCriterion("transmitID between", value1, value2, "transmitid");
            return (Criteria) this;
        }

        public Criteria andTransmitidNotBetween(String value1, String value2) {
            addCriterion("transmitID not between", value1, value2, "transmitid");
            return (Criteria) this;
        }

        public Criteria andTransmitnumberIsNull() {
            addCriterion("transmitNumber is null");
            return (Criteria) this;
        }

        public Criteria andTransmitnumberIsNotNull() {
            addCriterion("transmitNumber is not null");
            return (Criteria) this;
        }

        public Criteria andTransmitnumberEqualTo(Integer value) {
            addCriterion("transmitNumber =", value, "transmitnumber");
            return (Criteria) this;
        }

        public Criteria andTransmitnumberNotEqualTo(Integer value) {
            addCriterion("transmitNumber <>", value, "transmitnumber");
            return (Criteria) this;
        }

        public Criteria andTransmitnumberGreaterThan(Integer value) {
            addCriterion("transmitNumber >", value, "transmitnumber");
            return (Criteria) this;
        }

        public Criteria andTransmitnumberGreaterThanOrEqualTo(Integer value) {
            addCriterion("transmitNumber >=", value, "transmitnumber");
            return (Criteria) this;
        }

        public Criteria andTransmitnumberLessThan(Integer value) {
            addCriterion("transmitNumber <", value, "transmitnumber");
            return (Criteria) this;
        }

        public Criteria andTransmitnumberLessThanOrEqualTo(Integer value) {
            addCriterion("transmitNumber <=", value, "transmitnumber");
            return (Criteria) this;
        }

        public Criteria andTransmitnumberIn(List<Integer> values) {
            addCriterion("transmitNumber in", values, "transmitnumber");
            return (Criteria) this;
        }

        public Criteria andTransmitnumberNotIn(List<Integer> values) {
            addCriterion("transmitNumber not in", values, "transmitnumber");
            return (Criteria) this;
        }

        public Criteria andTransmitnumberBetween(Integer value1, Integer value2) {
            addCriterion("transmitNumber between", value1, value2, "transmitnumber");
            return (Criteria) this;
        }

        public Criteria andTransmitnumberNotBetween(Integer value1, Integer value2) {
            addCriterion("transmitNumber not between", value1, value2, "transmitnumber");
            return (Criteria) this;
        }

        public Criteria andCommentidIsNull() {
            addCriterion("commentID is null");
            return (Criteria) this;
        }

        public Criteria andCommentidIsNotNull() {
            addCriterion("commentID is not null");
            return (Criteria) this;
        }

        public Criteria andCommentidEqualTo(String value) {
            addCriterion("commentID =", value, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidNotEqualTo(String value) {
            addCriterion("commentID <>", value, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidGreaterThan(String value) {
            addCriterion("commentID >", value, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidGreaterThanOrEqualTo(String value) {
            addCriterion("commentID >=", value, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidLessThan(String value) {
            addCriterion("commentID <", value, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidLessThanOrEqualTo(String value) {
            addCriterion("commentID <=", value, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidLike(String value) {
            addCriterion("commentID like", value, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidNotLike(String value) {
            addCriterion("commentID not like", value, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidIn(List<String> values) {
            addCriterion("commentID in", values, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidNotIn(List<String> values) {
            addCriterion("commentID not in", values, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidBetween(String value1, String value2) {
            addCriterion("commentID between", value1, value2, "commentid");
            return (Criteria) this;
        }

        public Criteria andCommentidNotBetween(String value1, String value2) {
            addCriterion("commentID not between", value1, value2, "commentid");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}