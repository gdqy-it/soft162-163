package com.liguanghong.gdqylatitude.util;

import java.util.Date;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.tomcat.util.codec.binary.Base64;


import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;

public class Token {
    
    /**
     * ���ַ������ɼ���key
     * @return
     */
    public static SecretKey generalKey(){
        String stringKey = "liguanghonggdqylatitude";
    	byte[] encodedKey = Base64.decodeBase64(stringKey);
        SecretKey key = new SecretKeySpec(encodedKey, 0, encodedKey.length, "AES");
        return key;
    }

    /**
     * ǩ��jwt
     * @param id
     * @param subject
     * @param ttlMillis
     * @return
     * @throws Exception
     */
    public static String createJWT(String id, String subject, long ttlMillis) throws Exception {
        //ǩ���㷨
        SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
        //ϵͳ��ǰʱ��
        long nowMillis = System.currentTimeMillis();
        Date now = new Date(nowMillis);
        //����key
        SecretKey key = generalKey();
        //ǩ��JWT
        JwtBuilder builder = Jwts.builder()
            .setId(id)
            .setIssuedAt(now)
            .setSubject(subject)
            .signWith(signatureAlgorithm, key);
        //���ù���ʱ��
        if (ttlMillis >= 0) {
            long expMillis = nowMillis + ttlMillis;
            Date exp = new Date(expMillis);
            builder.setExpiration(exp);
        }
        return builder.compact();
    }
    
    /**
     * ��֤jwt
     * @param jwt
     * @return
     * @throws Exception
     */
    public static Claims parseJWT(String jwt) throws Exception{
        //����key
    	SecretKey key = generalKey();
        try {
            Claims claims = Jwts.parser()         
               .setSigningKey(key)
               .parseClaimsJws(jwt).getBody();
            return claims;
        } catch (ExpiredJwtException e) {
			// token�ѹ���
        	System.out.println("token�ѹ��ڣ������µ�¼��");
			return null;
		} catch (UnsupportedJwtException e) {
			// token��֧��
			System.out.println("token��Ϣ���ܱ������������µ�¼��");
			return null;
		} catch (MalformedJwtException e) {
			// token��ʽ����
			System.out.println("token��ʽ���������µ�¼��");
			return null;
		} catch (SignatureException e) {
			// tokenǩ������
			System.out.println("tokenǩ�����������µ�¼��");
			return null;
		} catch (IllegalArgumentException e) {
			// token��ʽת������
			System.out.println("tokenΪ�գ������µ�¼��");
			return null;
		}
    }
    
    public static void main(String [] args) {
    	String json = "{\"userid\":1,\"logname\":\"Tom\",\"password\":123456}";
    	String json2 = "{\"userid\":1,\"logname\":\"Tom\",\"password\":1234356}";
    	try {
    		String jwt = createJWT("1", json, 60000);
			System.out.println(jwt);
			String temp = "1"+jwt.substring(1, jwt.length());
			new Thread() {
				public void run() {
					while(true) {
						try {
							System.out.println("����: \n"+parseJWT(temp));
							Thread.sleep(1000);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							break;
						}
					}
				}
			}.start();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
