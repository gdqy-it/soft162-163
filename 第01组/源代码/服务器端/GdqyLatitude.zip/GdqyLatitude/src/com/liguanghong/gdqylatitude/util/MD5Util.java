package com.liguanghong.gdqylatitude.util;

import java.security.MessageDigest;

/**
 * MD5����
 * @author LGH
 *
 */
public class MD5Util {
	/**
	 * MD5����
	 * @param value
	 * @return
	 */
	public static String getMD5(String value) {
		char hexDigits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd',  'e', 'f'}; 
		try {
			byte[] btInput = value.getBytes();
			MessageDigest md = MessageDigest.getInstance( "MD5" );
			md.update( btInput );
			byte tmp[] = md.digest();         
			char str[] = new char[16 * 2];   
			int k = 0;                               
			for (int i = 0; i < 16; i++) {        
				byte byte0 = tmp[i];               
				str[k++] = hexDigits[byte0 >>> 4 & 0xf];  
				str[k++] = hexDigits[byte0 & 0xf];           
			}
			return new String(str);                               
		} catch( Exception e ) {
			e.printStackTrace();
			//����ʧ��
			return null;
		}
	}
	/**
	 * ���ܽ����㷨 ִ��һ�μ��ܣ����ν���
	 * @param value
	 * @return
	 */
	public static String convertMD5(String value){  
		char[] a = value.toCharArray();  
		for (int i = 0; i < a.length; i++){  
			a[i] = (char) (a[i] ^ 't');  
		}  
		String s = new String(a);  
		return s;  
	}
}
