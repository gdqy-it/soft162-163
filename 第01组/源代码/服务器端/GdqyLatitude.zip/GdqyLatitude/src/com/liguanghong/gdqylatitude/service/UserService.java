package com.liguanghong.gdqylatitude.service;

import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.liguanghong.gdqylatitude.mapper.UserMapper;
import com.liguanghong.gdqylatitude.pojo.Friend;
import com.liguanghong.gdqylatitude.pojo.FriendsSet;
import com.liguanghong.gdqylatitude.pojo.User;
import com.liguanghong.gdqylatitude.pojo.UserExample;
import com.liguanghong.gdqylatitude.pojo.UserExample.Criteria;
import com.liguanghong.gdqylatitude.util.JsonResult;
import com.liguanghong.gdqylatitude.util.MD5Util;
import com.sun.mail.util.MailSSLSocketFactory;

@Service("userService")
public class UserService {
	
	@Resource
	private UserMapper dao;

	/**
	 * ע��
	 * @param logname
	 * @param password
	 * @return
	 */
	public JsonResult<User> signUp(String logname, String password){

		if(null == logname || logname.equals("")) 
			return new JsonResult<User>(false, "ע��ʧ�ܣ��û�������Ϊ��");
		if(null == password|| password.equals(""))
			return new JsonResult<User>(false, "ע��ʧ�ܣ����벻��Ϊ��");	
		if(!password.matches("[A-Za-z0-9]+"))
			return new JsonResult<User>(false, "ע��ʧ�ܣ��������Ϊ���ֻ��Сд��ĸ");
		
		User user = new User();;
		user.setLogname(logname);
		user.setPassword(MD5Util.getMD5(password));
		user.setSignuptime(new Date());
		int rows  = dao.insertSelective(user);
		if(rows > 0) {
			UserExample example = new UserExample();
			Criteria criteria = example.createCriteria();
			criteria.andLognameEqualTo(logname);
			user = dao.selectByExample(example);
			user.setPassword(null);	//����������
			return new JsonResult<User>(true, "ע��ɹ�", user);
		} else {
			return new JsonResult<User>(false, "ע��ʧ�ܣ����û����ѱ�ռ��");
		}
	}
	/**
	 * ��¼
	 * @param logname
	 * @param password
	 * @return
	 */
	public JsonResult<JSONObject> signIn(String logname, String password){
		if(null == logname || logname.equals("")) 
			return new JsonResult<JSONObject>(false, "��¼ʧ�ܣ��û�������Ϊ��");
		if(null == password|| password.equals(""))
			return new JsonResult<JSONObject>(false, "��¼ʧ�ܣ����벻��Ϊ��");	
		if(!password.matches("[A-Za-z0-9]+"))
			return new JsonResult<JSONObject>(false, "��¼ʧ�ܣ������������Ϊ���ֻ��Сд��ĸ");
		
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andLognameEqualTo(logname);
		criteria.andPasswordEqualTo(MD5Util.getMD5(password));
		User user = dao.selectByExamplePrivate(example);
		if(user == null)
			return new JsonResult<JSONObject>(false, "��¼ʧ�ܣ��û������������");
		if(user.getStatu() == 0)
			return new JsonResult<JSONObject>(false, "��¼ʧ�ܣ��˻��ѱ����ᣬ�������ߣ�����ϵ����Ա");
		if(user.getLogname().equals(logname) && user.getPassword().equals(MD5Util.getMD5(password))) {
			user.setSignintime(new Date());
			user.setStatu(2);
			dao.updateByPrimaryKey(user);
			user.setPassword(null);	//����������
			JSONObject object= new JSONObject();
			object.put("user", user);
			object.put("friends", findAddressbook(user.getUserid()));
			return new JsonResult<JSONObject>(true, "��¼�ɹ�", object);
		} else {
			return new JsonResult<JSONObject>(false, "��¼ʧ�ܣ��û������������");
		}
	}
	/**
	 * �˳���¼
	 * @param userid
	 * @return
	 */
	public JsonResult<Integer> signOut(Integer userid){
		User user = dao.selectByPrimaryKey(userid);
		if(user == null) {
			return new JsonResult<Integer>(false, "���û������ڣ��޷�����");
		} else if(user.getStatu() == 0) {
			return new JsonResult<Integer>(false, "���˻������ᣬ�޷�����");
		} else if(user.getStatu() == 1) {
			return new JsonResult<Integer>(false, "���û��Ѿ����ߣ��޷��ظ�����");
		} else {
			user.setStatu(1);
		}
		int rows = dao.updateByPrimaryKeySelective(user);
		if(rows <= 0) {
			return new JsonResult<Integer>(false, "�˳���¼ʧ�ܣ�δ֪ԭ��");
		}
		return new JsonResult<Integer>(true, "�˳���¼�ɹ�");
	}
	
	/**
	 * �����û�״̬
	 * @param userid
	 * @param status
	 * @return
	 */
	public int changeStatus(Integer userid, Integer status) {
		User user = dao.selectByPrimaryKey(userid);
		user.setStatu(status);
		return dao.updateByPrimaryKeySelective(user);
	}
	/**
	 * ע���˻�
	 * @param userid
	 * @return
	 */
	public JsonResult<Integer> logout(Integer userid){
		int rows = dao.deleteByPrimaryKey(userid);
		if(rows < 0) {
			return new JsonResult<Integer>(false, "ע���˺�ʧ�ܣ�δ֪ԭ��");
		} else {
			return new JsonResult<Integer>(true, "ע���˺ųɹ�");
		}
	}

	/**
	 * �����û���Ϣ
	 * @param user
	 * @return
	 */
	public JsonResult<User> update(User user){
		if(user.getPassword() != null)
			user.setPassword(MD5Util.getMD5(user.getPassword()));
		int rows = dao.updateByPrimaryKeySelective(user);
		if(rows <= 0) {
			return new JsonResult<User>(false, "����ʧ�ܣ�δ֪ԭ��");
		}
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andUseridEqualTo(user.getUserid());
		user = dao.selectByExamplePrivate(example);
		user.setPassword(null);
		return new JsonResult<User>(true, "���³ɹ�", user);
	}
	
	/**
	 * ����λ����Ϣ
	 * @param userid
	 * @param latitude
	 * @param longitude
	 */
	public JsonResult<Integer> updateLocation(Integer userid, double latitude, double longitude) {
		System.out.println("��λ���£�" + userid + ":" + latitude + "-" + longitude);
		User user = new User();
		user.setUserid(userid);
		user.setLatitude(latitude);
		user.setLongitude(longitude);
		int row = dao.updateByPrimaryKeySelective(user);
		if(row > 0)
			return new JsonResult<Integer>(true, "����λ�óɹ�");
		else 
			return new JsonResult<Integer>(false, "����λ��ʧ��");
	}
	
	/**
	 * ��ѯָ���û�������Ϣ
	 * @param userid
	 * @return
	 */
	public JsonResult<User> findByID(Integer userid){
		User user = dao.selectByPrimaryKey(userid);
		if(null == user)
			return new JsonResult<User>(false, "��ѯʧ��, �û�������");
		return new JsonResult<User>(true, "��ѯ�ɹ�", user);
	}
	
	/**
	 * ��ѯͨѶ¼�����б�
	 * @param userid
	 * @return
	 */
	public JsonResult<Map<String, List<Friend>>> findFriends(Integer userid){
		return new JsonResult<Map<String, List<Friend>>>(true, "��ѯ�ɹ�", findAddressbook(userid));
	}
	
	public Map<String, List<Friend>> findAddressbook(Integer userid){
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andUseridEqualTo(userid);
		User user = dao.selectByExamplePrivate(example);
		
		Map<String, List<Friend>> friends = new LinkedHashMap<>();
		List<FriendsSet> friendsSets = JSONArray.parseArray(user.getFriendsid(), FriendsSet.class);
			
		for(FriendsSet tempSet : friendsSets) {
			List<Friend> list = tempSet.getFriends();
			for(Friend tempFriend : list) {
				User friend = dao.selectByPrimaryKey(tempFriend.getFriendid());
				tempFriend.setFriend(friend);
			}
			friends.put(tempSet.getName(), list);
		}
		return friends;
	}
	
	/**
	 * ��ѯ����ID�б�
	 * @param userid
	 * @return
	 */
	public List<Friend> findFriendsIDByID(Integer userid){
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andUseridEqualTo(userid);
		User user = dao.selectByExamplePrivate(example);
		
		List<Friend> list = new ArrayList<>();
		List<FriendsSet> friendsSets = JSONArray.parseArray(user.getFriendsid(), FriendsSet.class);
		for(FriendsSet fs : friendsSets) {
			list.addAll(fs.getFriends());
		}
		return list;
	}
	
	/**
	 * ��ѯ�����û�
	 * @param statu
	 * @param required
	 * @return
	 */
	public JsonResult<PageInfo<User>> findAll(Integer userid, Integer statu, Integer required, Integer page){
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		if(null != userid) {
			criteria.andUseridNotEqualTo(userid);
		}
		if(null != statu) {
			criteria.andStatuEqualTo(statu);
		}
		if(null != page)
			PageHelper.startPage(page, 10); 
		List<User> allUser;
		if(required != null && required == 1) {
			allUser = dao.selectAllByExamplePrivate(example);
		}else {
			allUser = dao.selectAllByExample(example);
		}
		PageInfo<User> pageInfo = new PageInfo<>(allUser);
		if(null == allUser)
			return new JsonResult<PageInfo<User>>(false, "��ѯʧ�ܣ�δ֪ԭ��");
		return new JsonResult<PageInfo<User>>(true, "��ѯ�ɹ�", pageInfo);
	}
	
	/**
	 * ģ�������û�
	 * @param keyText
	 * @return
	 */
	public JsonResult<PageInfo<User>> search(Integer userid, String keyword, Integer page){
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andUseridNotEqualTo(userid);
		if(keyword != null) {
			keyword = "%" + keyword + "%";
			criteria.andLognameLike(keyword);
		}
		PageHelper.startPage(page, 10); 
		List<User> allUser = dao.selectAllByExample(example);
		PageInfo<User> pageInfo = new PageInfo<>(allUser);
		return new JsonResult<PageInfo<User>>(true, "��ѯ�ɹ�", pageInfo);
	}
	
	/**
	 * ��ѯ�û�����
	 * @param statu
	 * @return
	 */
	public JsonResult<Integer> getCount(Integer statu){
		UserExample example = new UserExample();
		if(statu != null) {
			Criteria criteria = example.createCriteria();
			criteria.andStatuEqualTo(statu);
		}
		int count = dao.countByExample(example);
		return new JsonResult<Integer>(true, "��ѯ�ɹ�", count);
	}
	/**
	 * �����˻�
	 * @param userid
	 * @return
	 */
	public JsonResult<Integer> freeze(Integer userid) {
		User user = dao.selectByPrimaryKey(userid);
		if(user == null) {
			return new JsonResult<Integer>(false, "�û�������");
		}else if(user.getStatu() == 0) {
			//�Ѿ��Ƕ���״̬
			return new JsonResult<Integer>(false, "���û��Ѿ������ᣬ�����ظ�����");
		}else {
			//���ж���
			user.setStatu(0);
			int rows = dao.updateByPrimaryKeySelective(user);
			if(rows == 1)
				return new JsonResult<Integer>(true, "����ɹ�");
			else
				return new JsonResult<Integer>(false, "����ʧ�ܣ�δ֪ԭ��");
		}
	}
	/**
	 * ����˻�
	 * @param userid
	 * @return
	 */
	public JsonResult<Integer> unFreeze(Integer userid) {
		User user = dao.selectByPrimaryKey(userid);
		if(user == null) {
			return new JsonResult<Integer>(false, "���ʧ�ܣ��û�������");
		}else if(user.getStatu() != 0) {
			//�˻�״̬����
			return new JsonResult<Integer>(false, "���ʧ�ܣ��˻�״̬����������Ҫ���");
		}else {
			//���н��
			user.setStatu(1);
			int rows =  dao.updateByPrimaryKeySelective(user);
			if(rows == 1)
				return new JsonResult<Integer>(true, "���ɹ�");
			else
				return new JsonResult<Integer>(false, "���ʧ�ܣ�δ֪ԭ��");
		}
	}
	
	/**
	 * ���Ӻ���
	 * @param userid
	 * @param targetuserid
	 * @return
	 */
	public JsonResult<Integer> addFriend(Integer userid, Integer targetuserid){
		JsonResult<Integer> result1 = addFriendOperate(userid, targetuserid);	//�����ӶԷ�Ϊ����
		addFriendOperate(targetuserid, userid);	//�Է�������Ϊ����

		return result1;
	}

	/**
	 * ���Ӻ��Ѿ������
	 * @param userid
	 * @param targetuserid
	 * @return
	 */
	private JsonResult<Integer> addFriendOperate(Integer userid, Integer targetuserid) {
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andUseridEqualTo(userid);
		User user = dao.selectByExamplePrivate(example);
		List<FriendsSet> fs = JSONArray.parseArray(user.getFriendsid(), FriendsSet.class);
		boolean ihave = false;
		for(FriendsSet tempSet : fs) {
			for(Friend tempId : tempSet.getFriends()) {
				if(tempId.getFriendid().equals(targetuserid)) {
					//������Ϊ����
					ihave = true;
				}
			}
		}
		if(!ihave) {
			Friend friend = new Friend();
			friend.setFriendid(targetuserid);
			fs.get(0).addFriend(friend);
			user.setFriendsid(JSONArray.toJSONString(fs));
			dao.updateByPrimaryKeySelective(user);
			return new JsonResult<Integer>(true, "���Ӻ��ѳɹ�");
		} else {
			return new JsonResult<Integer>(false, "���Ӻ���ʧ��");
		}
	}
	
	/**
	 * ɾ������
	 * @param userid
	 * @param targetuserid
	 * @return
	 */
	public JsonResult<Integer> deleteFriend(Integer userid, Integer targetuserid){
		JsonResult<Integer> result1 = deleteFriendOperate(userid, targetuserid);	//�����ӶԷ�Ϊ����
		deleteFriendOperate(targetuserid, userid);	//�Է�������Ϊ����
		return result1;
	}
	
	/**
	 * ɾ�����Ѿ������
	 * @param userid
	 * @param targetuserid
	 * @return
	 */
	private JsonResult<Integer> deleteFriendOperate(Integer userid, Integer targetuserid){
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andUseridEqualTo(userid);
		User user = dao.selectByExamplePrivate(example);
		List<FriendsSet> fs = JSONArray.parseArray(user.getFriendsid(), FriendsSet.class);
		for(FriendsSet tempSet : fs) {
			for(Friend tempId : tempSet.getFriends()) {
				if(tempId.getFriendid().equals(targetuserid)) {
					tempSet.getFriends().remove(tempId);
					user.setFriendsid(JSONArray.toJSONString(fs));
					dao.updateByPrimaryKeySelective(user);
					return new JsonResult<Integer>(true, "ɾ�����ѳɹ�");
				}
			}
		}
		return new JsonResult<Integer>(false, "ɾ������ʧ��");
	}
	
	/**
	 * �������ѷ���
	 * @param userid
	 * @param setName
	 * @return
	 */
	public JsonResult<Integer> createFriendsSet(Integer userid, String setName) {
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andUseridEqualTo(userid);
		User user = dao.selectByExamplePrivate(example);
		List<FriendsSet> friendsSets = JSONArray.parseArray(user.getFriendsid(), FriendsSet.class);
		for(FriendsSet tempSet : friendsSets) {
			if(setName.equals(tempSet.getName())) {
				//��������ռ��
				return new JsonResult<Integer>(false, "�������Ѵ���");
			}
		}
		FriendsSet newFriendsSet = new FriendsSet();
		newFriendsSet.setName(setName);
		friendsSets.add(newFriendsSet);
		user.setFriendsid(JSONArray.toJSONString(friendsSets));
		dao.updateByPrimaryKeySelective(user);
		return new JsonResult<Integer>(true, "��������ɹ�");
	}
	
	/**
	 * ɾ�����ѷ���
	 * @param userid
	 * @param setName
	 * @return
	 */
	public JsonResult<Integer> deleteFriendsSet(Integer userid, String setName) {
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andUseridEqualTo(userid);
		User user = dao.selectByExamplePrivate(example);
		List<FriendsSet> friendsSets = JSONArray.parseArray(user.getFriendsid(), FriendsSet.class);
		for(FriendsSet tempSet : friendsSets) {
			if(setName.equals(tempSet.getName())) {
				if(tempSet.getFriends() != null) {
					//���÷������к��ѣ��������ƶ���Ĭ�Ϸ���
					FriendsSet fs = friendsSets.get(0);
					fs.addFriends(tempSet.getFriends());
				}
				friendsSets.remove(tempSet);
				user.setFriendsid(JSONArray.toJSONString(friendsSets));
				dao.updateByPrimaryKeySelective(user);
				return new JsonResult<Integer>(true, "ɾ������ɹ�");
			}
		}
		return new JsonResult<Integer>(false, "���鲻����");
	}
	
	/**
	 * ���·�����
	 * @param userid
	 * @param fromSetName
	 * @param toSetName
	 * @return
	 */
	public JsonResult<Integer> udpateFriendsSet(Integer userid, String fromSetName, String toSetName){
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andUseridEqualTo(userid);
		User user = dao.selectByExamplePrivate(example);
		List<FriendsSet> friendsSets = JSONArray.parseArray(user.getFriendsid(), FriendsSet.class);
		for(FriendsSet tempSet : friendsSets) {
			if(tempSet.getName().equals(fromSetName)) {
				tempSet.setName(toSetName);
				user.setFriendsid(JSONArray.toJSONString(friendsSets));
				int row = dao.updateByPrimaryKeySelective(user);
				if(row > 0)
					return new JsonResult<Integer>(true, "���·������ɹ�");
				else
					return new JsonResult<Integer>(false, "���·�����ʧ��");
			}
		}
		return new JsonResult<Integer>(false, "���鲻����");
	}
	
	/**
	 * �ƶ��������ڷ���
	 * @param userid
	 * @param targetid
	 * @param fromSetName
	 * @param toSetName
	 * @return
	 */
	public JsonResult<Integer> changeFriendsSet(Integer userid, Integer targetid, String fromSetName, String toSetName){
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andUseridEqualTo(userid);
		User user = dao.selectByExamplePrivate(example);
		List<FriendsSet> friendsSets = JSONArray.parseArray(user.getFriendsid(), FriendsSet.class);
		FriendsSet fromFriendsSet = null;
		FriendsSet toFriendsSet = null;
		Friend friend = null;
		for(FriendsSet tempSet : friendsSets) {
			if(fromSetName.equals(tempSet.getName())) {
				fromFriendsSet = tempSet;
				List<Friend> friends = fromFriendsSet.getFriends();
				for(Friend tempFriend : friends) {
					if(tempFriend.getFriendid().equals(targetid)) {
						friend = tempFriend;
					}
				}
			}
			if(toSetName.equals(tempSet.getName())){
				//Ŀ�����
				toFriendsSet = tempSet;
			}
		}
		if(fromFriendsSet == null || toFriendsSet == null) {
			return new JsonResult<Integer>(false, "���鲻����");
		}
		
		fromFriendsSet.getFriends().remove(friend);
		toFriendsSet.addFriend(friend);
		user.setFriendsid(JSONArray.toJSONString(friendsSets));
		dao.updateByPrimaryKeySelective(user);
		return new JsonResult<Integer>(true, "�ƶ��������ڳɹ�");
	}
	
	/**
	 * �޸ĺ��ѱ�ע
	 * @param userid
	 * @param targetuserid
	 * @param remark
	 * @return
	 */
	public JsonResult<Integer> changeFriendRemark(Integer userid, Integer targetid, String remark) {
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andUseridEqualTo(userid);
		User user = dao.selectByExamplePrivate(example);
		List<FriendsSet> fs = JSONArray.parseArray(user.getFriendsid(), FriendsSet.class);
		for(FriendsSet tempSet : fs) {
			for(Friend tempFriend : tempSet.getFriends()) {
				if(tempFriend.getFriendid().equals(targetid)) {
					tempFriend.setRemark(remark);
					user.setFriendsid(JSONArray.toJSONString(fs));
					dao.updateByPrimaryKeySelective(user);
					return new JsonResult<Integer>(true, "�޸ĺ��ѱ�ע�ɹ�");
				}
			}
		}
		return new JsonResult<Integer>(false, "�޸ĺ��ѱ�עʧ��");
	}
	
	public JsonResult<String> getCheck(String email){
		String check = getString();
		Properties props = new Properties();
        // ����debug����
        props.setProperty("mail.debug", "true");
        // ���ͷ�������Ҫ������֤
        props.setProperty("mail.smtp.auth", "true");
        // �����ʼ�������������
        props.setProperty("mail.host", "smtp.qq.com");
        // �����ʼ�Э������
        props.setProperty("mail.transport.protocol", "smtp");
        //ssl��֤
        MailSSLSocketFactory sf = null;
		try {
			sf = new MailSSLSocketFactory();
		} catch (GeneralSecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        sf.setTrustAllHosts(true);
        props.put("mail.smtp.ssl.enable", "true");
        props.put("mail.smtp.ssl.socketFactory", sf);

        Session session = Session.getInstance(props);
        //���÷�����Ϣ
        Message msg = new MimeMessage(session);
        try {
			msg.setSubject("������֤��");
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        StringBuilder builder = new StringBuilder();
        builder.append("������֤���ǣ�"+check);
        try {
			msg.setText(builder.toString());
			msg.setFrom(new InternetAddress("3164671384@qq.com"));
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        


        
        try {
        	Transport transport = session.getTransport();
			transport.connect("smtp.qq.com", "3164671384@qq.com", "nwoleibtppcfdcgi");
			transport.sendMessage(msg, new Address[] { new InternetAddress(email) });
		    transport.close();
	        return new JsonResult<String>(true, "������֤��ɹ�", check);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        return new JsonResult<String>(false, "������֤��ʧ��");
	}
	
    public String getString(){
    	String string = "";
    	String model = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		char[] m = model.toCharArray();
		for (int j = 0; j < 6; j++) {
			char c = m[(int) (Math.random() * 36)];
			// ��֤��λ�����֮��û���ظ���
			if (string.contains(String.valueOf(c))) {
				j--;
				continue;
			}
			string = string + c;
		}
		System.out.println("�������ɵ���֤��Ϊ��"+string);
		return string;
    }
	
}
