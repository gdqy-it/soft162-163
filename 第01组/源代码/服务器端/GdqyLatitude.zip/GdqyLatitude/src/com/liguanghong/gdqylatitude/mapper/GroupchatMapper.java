package com.liguanghong.gdqylatitude.mapper;

import com.liguanghong.gdqylatitude.pojo.Groupchat;
import com.liguanghong.gdqylatitude.pojo.GroupchatExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface GroupchatMapper {
    int countByExample(GroupchatExample example);

    int deleteByExample(GroupchatExample example);

    int deleteByPrimaryKey(Integer groupid);

    int insert(Groupchat record);

    int insertSelective(Groupchat record);

    List<Groupchat> selectByExampleWithBLOBs(GroupchatExample example);

    List<Groupchat> selectByExample(GroupchatExample example);

    Groupchat selectByPrimaryKey(Integer groupid);

    int updateByExampleSelective(@Param("record") Groupchat record, @Param("example") GroupchatExample example);

    int updateByExampleWithBLOBs(@Param("record") Groupchat record, @Param("example") GroupchatExample example);

    int updateByExample(@Param("record") Groupchat record, @Param("example") GroupchatExample example);

    int updateByPrimaryKeySelective(Groupchat record);

    int updateByPrimaryKeyWithBLOBs(Groupchat record);

    int updateByPrimaryKey(Groupchat record);
}