package com.liguanghong.gdqylatitude.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.liguanghong.gdqylatitude.mapper.AdminMapper;
import com.liguanghong.gdqylatitude.pojo.Admin;
import com.liguanghong.gdqylatitude.pojo.AdminExample;
import com.liguanghong.gdqylatitude.pojo.AdminExample.Criteria;

@Service("adminService")
public class AdminService {
	@Resource
	private AdminMapper dao;
	
	public Admin login(String logname, String password) {
		AdminExample example = new AdminExample();
		Criteria criteria = example.createCriteria();
		criteria.andAdminnameEqualTo(logname);
		criteria.andPasswordEqualTo(password);
		Admin admin = dao.selectByExample(example);
		return admin;
	}

}
