package com.liguanghong.gdqylatitude.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.liguanghong.gdqylatitude.pojo.NoticeMsg;
import com.liguanghong.gdqylatitude.service.NoticeService;
import com.liguanghong.gdqylatitude.util.JsonResult;

@Controller
@RequestMapping("/notice")  
public class NoticeController {
	@Resource(name="noticeService")
	private NoticeService noticeService;

	/**
	 * api-notice-001-����֪ͨ
	 * @param noticeMsg
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/createnotice", method=RequestMethod.POST)
	public JsonResult<Integer> createNotice(NoticeMsg noticeMsg){
		return noticeService.createNotice(noticeMsg);
	}
	
	/**
	 * api-notice-002-����
	 * @param userid
	 * @param status
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/findnotices", method=RequestMethod.POST)
	public JsonResult<List<NoticeMsg>> findNotices(@RequestParam("userid") Integer userid,
			@RequestParam("status") Integer status){
		return noticeService.findNotices(userid, status);
	}
	
	/**
	 * api-notice-003-�ܾ�
	 * @param noticeMsg
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/refusenotice", method=RequestMethod.POST)
	public JsonResult<Integer> refuseNotice(NoticeMsg noticeMsg){
		return noticeService.refuseNotice(noticeMsg);
	}
	
	/**
	 * api-notice-004-ͬ��
	 * @param noticeMsg
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/agreenotice", method=RequestMethod.POST)
	public JsonResult<Integer> agreeNotice(NoticeMsg noticeMsg){
		return noticeService.agreeNotice(noticeMsg);
	}
	
}
