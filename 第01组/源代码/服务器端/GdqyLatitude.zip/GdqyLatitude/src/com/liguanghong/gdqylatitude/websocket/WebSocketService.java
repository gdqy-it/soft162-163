package com.liguanghong.gdqylatitude.websocket;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.socket.server.standard.SpringConfigurator;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.liguanghong.gdqylatitude.pojo.ChatMsg;
import com.liguanghong.gdqylatitude.pojo.Friend;
import com.liguanghong.gdqylatitude.pojo.Groupchat;
import com.liguanghong.gdqylatitude.pojo.Msg;
import com.liguanghong.gdqylatitude.pojo.NoticeMsg;
import com.liguanghong.gdqylatitude.pojo.User;
import com.liguanghong.gdqylatitude.service.ChatMsgService;
import com.liguanghong.gdqylatitude.service.GroupService;
import com.liguanghong.gdqylatitude.service.NoticeService;
import com.liguanghong.gdqylatitude.service.UserService;
import com.liguanghong.gdqylatitude.util.MessageType;

/**
 * websocket服务
 * @author LGH
 *
 */
@ServerEndpoint(value = "/websocket/{userid}", configurator = SpringConfigurator.class)
public class WebSocketService {
	@Autowired
	private UserService userService;
	@Autowired
	private ChatMsgService chatMsgService;
	@Autowired
	private GroupService groupService;
	@Autowired
	private NoticeService noticeService;
	
	private static Map<Integer, Session> clients = new LinkedHashMap<>();
	private Integer userid;
	private Session session;

	@OnOpen
	public void open(Session session, @PathParam(value = "userid") Integer userid) {

		this.session = session;
		this.userid = userid;
		try {
			//强制前一台设备退出登录
			SignInCheck();
		} catch (IOException e) {
			e.printStackTrace();
		}
		clients.put(userid, this.session);
		//获取离线消息
		getOfflineMsg();
		//上线通知在线好友
		System.out.print("【"+userid+"】上线了");
		noticeFriends(MessageType.FRIENDONLINE);
	}

	@OnClose
	public void close() {
		
		clients.remove(userid, session);
		//下线通知在线好友
		System.out.print("【"+userid+"】下线了");
		noticeFriends(MessageType.FRIENDOFFLINE);
		
	}

	@OnMessage
	public void message(String message) {

//		ChatMsg chatMsg = JSONObject.parseObject(message, ChatMsg.class);
//		chatMsg.setSendtime(new Date());
//		chatMsg.setStatus(2);
//		if(chatMsg.getIssingle()) {
//			//私聊
//			sendMsgSingle(chatMsg, chatMsg.getReceiverid());
//		} else {
//			//群聊
//			sendMsgGroup(chatMsg, chatMsg.getReceiverid());
//		}
		System.out.println(message);
		JSONObject object = JSONObject.parseObject(message);
		Integer msgType = object.getInteger("msgType");
		if(MessageType.CHATTYPE.equals(msgType)) {
			ChatMsg chatMsg = object.getObject("msg", ChatMsg.class);
			chatMsg.setSendtime(new Date());
			chatMsg.setStatus(2);
			if(chatMsg.getIssingle()) {
				//私聊
				sendMsgSingle(chatMsg, chatMsg.getReceiverid());
			} else {
				//群聊
				sendMsgGroup(chatMsg, chatMsg.getReceiverid());
			}
		} else if(MessageType.NOTICETYPE.equals(msgType)) {
			NoticeMsg<Integer> noticeMsg = JSONObject.parseObject(object.getString("msg"), new TypeReference<NoticeMsg<Integer>>(){});
			sendSystemNotice(noticeMsg, noticeMsg.getReceiverid());
		} else if(MessageType.NOTICEFRIENDTYPE.equals(msgType)) {
			NoticeMsg<User> noticeMsg = JSONObject.parseObject(object.getString("msg"), new TypeReference<NoticeMsg<User>>(){});
			sendFriendNotice(noticeMsg, noticeMsg.getReceiverid());
		} else if(MessageType.NOTICEGROUPTYPE.equals(msgType)) {
			NoticeMsg<Groupchat> noticeMsg = JSONObject.parseObject(object.getString("msg"), new TypeReference<NoticeMsg<Groupchat>>(){});
			sendGroupNotice(noticeMsg, noticeMsg.getReceiverid());
		}

	}
	
	@OnError
	public void error(Throwable e, Session session) {
		System.out.println(e);
	}
	
	/**
	 * 私聊
	 * @param message
	 * @param targetID
	 */
	private void sendMsgSingle(ChatMsg chatMsg, Integer targetID) {
		
		Session session = clients.get(targetID);
		if(session != null) {
			//在线消息
			Msg<ChatMsg> msg = new Msg<>();
			msg.setMsgType(MessageType.CHATTYPE);
			msg.setMsg(chatMsg);
			session.getAsyncRemote().sendText(JSONObject.toJSONString(msg));
			System.out.println("【"+userid+"】发送消息："+JSONObject.toJSONString(msg));
		} else {
			//离线消息
			chatMsgService.saveMsg(chatMsg);
			System.out.println("【"+userid+"】发送离线消息："+JSONObject.toJSONString(chatMsg));
		}
		
	}
	
	/**
	 * 群聊
	 * @param message
	 * @param targetID
	 */
	private void sendMsgGroup(ChatMsg chatMsg, Integer targetID) {

		System.out.println("【"+userid+"】发送群聊消息："+JSONObject.toJSONString(chatMsg));
		
		Groupchat groupchat = groupService.findGroupByID(targetID);
		if(groupchat != null) {
			List<Integer> list = JSONArray.parseArray(groupchat.getGroupmember(), Integer.class);
			if(list == null) {
				list = new ArrayList<Integer>();
			}
			list.add(groupchat.getOwnerid());
			list.remove(chatMsg.getSenderid());
			chatMsg.setStatus(2);
			//chatMsgService.saveMsg(chatMsg); 
			for(Integer temp : list) {
				if(!temp.equals(chatMsg.getSenderid())) {
					chatMsg.setSendtime(new Date());
					Session session = clients.get(temp);
					if(session != null) {
						//在线消息
						Msg<ChatMsg> msg = new Msg<>();
						msg.setMsgType(MessageType.CHATTYPE);
						msg.setMsg(chatMsg);
						session.getAsyncRemote().sendText(JSONObject.toJSONString(msg));
						System.out.println("【"+userid+"】发送消息："+JSONObject.toJSONString(chatMsg));
					}
				}
			}
				
		}
		
	}
	
	/**
	 * 发送系统通知
	 * @param noticeMsg
	 * @param targetID
	 */
	private void sendSystemNotice(NoticeMsg<Integer> noticeMsg, Integer targetID) {
		noticeService.createNotice(noticeMsg);
		Session session = clients.get(targetID);
		if(session != null) {
			//在线消息
			Msg<NoticeMsg<Integer>> msg = new Msg<>();
			msg.setMsgType(MessageType.NOTICETYPE);
			msg.setMsg(noticeMsg);
			session.getAsyncRemote().sendText(JSONObject.toJSONString(msg));
			System.out.println("【"+userid+"】发送通知："+JSONObject.toJSONString(msg));
		}
	}
	
	/**
	 * 发送好友通知
	 * @param noticeMsg
	 * @param targetID
	 */
	private void sendFriendNotice(NoticeMsg<User> noticeMsg, Integer targetID) {
		if(noticeMsg.getNoticetype().equals(MessageType.FRIENDAPPLY))
			noticeService.createNotice(noticeMsg);
		else if(noticeMsg.getNoticetype().equals(MessageType.FRIENDDENIED))
			noticeService.refuseNotice(noticeMsg);
		else if(noticeMsg.getNoticetype().equals(MessageType.FRIENDAGREED))
			noticeService.agreeNotice(noticeMsg);
		Session session = clients.get(targetID);
		if(session != null) {
			//在线消息
			Msg<NoticeMsg<User>> msg = new Msg<>();
			msg.setMsgType(MessageType.NOTICEFRIENDTYPE);
			msg.setMsg(noticeMsg);
			session.getAsyncRemote().sendText(JSONObject.toJSONString(msg));
			System.out.println("【"+userid+"】发送通知："+JSONObject.toJSONString(msg));
		}
	}
	
	/**
	 * 发送群聊通知
	 * @param noticeMsg
	 * @param targetID
	 */
	private void sendGroupNotice(NoticeMsg<Groupchat> noticeMsg, Integer targetID) {
		if(noticeMsg.getNoticetype().equals(MessageType.GROUPAPPLY))
			noticeService.createNotice(noticeMsg);
		else if(noticeMsg.getNoticetype().equals(MessageType.GROUPDENIED))
			noticeService.refuseNotice(noticeMsg);
		else if(noticeMsg.getNoticetype().equals(MessageType.GROUPAGREED))
			noticeService.agreeNotice(noticeMsg);
		Session session = clients.get(targetID);
		if(session != null) {
			//在线消息
			Msg<NoticeMsg<Groupchat>> msg = new Msg<>();
			msg.setMsgType(MessageType.NOTICEGROUPTYPE);
			msg.setMsg(noticeMsg);
			session.getAsyncRemote().sendText(JSONObject.toJSONString(msg));
			System.out.println("【"+userid+"】发送通知："+JSONObject.toJSONString(msg));
		}
	}
	
	/**
	 * 多设备登陆检查
	 * @throws IOException
	 */
	private void SignInCheck() throws IOException {
		Session onlineSession = clients.get(userid);
		if(onlineSession != null) {
			System.out.println("用户【"+userid+"】在新设备登录，强制旧设备登出");
			ChatMsg chatMsg = new ChatMsg();
			chatMsg.setType(MessageType.LOGOUT);
			onlineSession.getAsyncRemote().sendText(JSONObject.toJSONString(chatMsg));
		}
	}

	/**
	 * 获取离线消息
	 */
	private void getOfflineMsg() {
		List<Groupchat> groupList = groupService.findMyGroup(userid).getData();
		List<Integer> groupListID = new ArrayList<>();
		if(groupList != null && !groupList.isEmpty()) {
			for(Groupchat temp : groupList) {
				groupListID.add(temp.getGroupid());
			}
		}
		
		
		List<ChatMsg> list = chatMsgService.getMsg(userid, groupListID);
		for(ChatMsg chatMsg : list) {
			//同步
			try {
				Msg<ChatMsg> msg = new Msg<>();
				msg.setMsgType(MessageType.CHATTYPE);
				msg.setMsg(chatMsg);
				session.getBasicRemote().sendText(JSONObject.toJSONString(msg));
				if(chatMsg.getIssingle())
					chatMsgService.deleteMsg(chatMsg);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * 好友上下线通知
	 */
	private void noticeFriends(Integer type) {
		if(type.equals(MessageType.FRIENDONLINE)) {
			userService.changeStatus(userid, 2);
		} else {
			userService.changeStatus(userid, 1);
		}
		List<Friend> list =userService.findFriendsIDByID(userid);
		System.out.print("-通知了：");
		for(Friend friend : list) {
			Session session = clients.get(friend.getFriendid());
			if(session != null) {
				System.out.print("【"+friend.getFriendid()+"】");
//				ChatMsg chatMsg = new ChatMsg();
//				chatMsg.setSenderid(userid);
//				chatMsg.setType(type);
//				session.getAsyncRemote().sendText(JSONObject.toJSONString(chatMsg));
				NoticeMsg<Integer> noticeMsg = new NoticeMsg<>();
				noticeMsg.setSenderid(userid);
				noticeMsg.setReceiverid(friend.getFriendid());
				noticeMsg.setNoticetype(type);
				Msg<NoticeMsg<Integer>> msg = new Msg<>();
				msg.setMsgType(MessageType.NOTICETYPE);
				msg.setMsg(noticeMsg);
				session.getAsyncRemote().sendText(JSONObject.toJSONString(msg));
			}
		}
		System.out.println();
	}
	
}