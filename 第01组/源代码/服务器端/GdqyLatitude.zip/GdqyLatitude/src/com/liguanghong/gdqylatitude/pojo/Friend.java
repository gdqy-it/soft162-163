package com.liguanghong.gdqylatitude.pojo;

import com.alibaba.fastjson.annotation.JSONField;

public class Friend {
	
	@JSONField(ordinal = 1)
	private Integer friendid;		//����ID
	@JSONField(ordinal = 2)
	private User friend;			//������Ϣ
	@JSONField(ordinal = 3)
	private String remark;			//���ѱ�ע��
	
	public Integer getFriendid() {
		return friendid;
	}
	
	public void setFriendid(Integer friendid) {
		this.friendid = friendid;
	}
	
	public User getFriend() {
		return friend;
	}

	public void setFriend(User friend) {
		this.friend = friend;
	}

	public String getRemark() {
		return remark;
	}
	
	public void setRemark(String remark) {
		this.remark = remark;
	}

}
