package com.liguanghong.gdqylatitude.service;


import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.liguanghong.gdqylatitude.mapper.GroupchatMapper;
import com.liguanghong.gdqylatitude.mapper.NoticeMsgMapper;
import com.liguanghong.gdqylatitude.mapper.UserMapper;
import com.liguanghong.gdqylatitude.pojo.NoticeMsg;
import com.liguanghong.gdqylatitude.pojo.NoticeMsgExample;
import com.liguanghong.gdqylatitude.pojo.NoticeMsgExample.Criteria;
import com.liguanghong.gdqylatitude.util.JsonResult;
import com.liguanghong.gdqylatitude.util.MessageType;

@Service("noticeService")
public class NoticeService {
	
	@Resource
	private NoticeMsgMapper dao;
	@Resource
	private UserMapper userDao;
	@Resource
	private GroupchatMapper groupDao;

	/**
	 * ���ͺ��ѣ�Ⱥ�ģ����루���룩֪ͨ
	 * @param noticeMsg
	 * @return
	 */
	public JsonResult<Integer> createNotice(NoticeMsg noticeMsg){
		int row = dao.insert(noticeMsg);
		if(row > 0)
			return new JsonResult<Integer>(true, "֪ͨ���ͳɹ�");
		else
			return new JsonResult<Integer>(false, "֪ͨ����ʧ��");
	}
	
	/**
	 * ��ȡָ���û���֪ͨ��Ϣ
	 * @param userid
	 * @return
	 */
	public JsonResult<List<NoticeMsg>> findNotices(Integer userid, Integer status){
		NoticeMsgExample example = new NoticeMsgExample();
		Criteria criteria = example.createCriteria();
		criteria.andReceiveridEqualTo(userid);
		if(null != status)
			criteria.andStatusEqualTo(status);
		List<NoticeMsg> list = dao.selectByExample(example);
		for(NoticeMsg msg : list) {
			if(msg.getNoticetype() >= MessageType.FRIENDAPPLY && msg.getNoticetype() <= MessageType.FRIENDAGREED) {
				msg.setData(userDao.selectByPrimaryKey(msg.getSenderid()));
			} else if(msg.getNoticetype() >= MessageType.GROUPAPPLY && msg.getNoticetype() <= MessageType.GROUPAGREED) {
				msg.setData(groupDao.selectByPrimaryKey(msg.getSenderid()));
			} else if(msg.getNoticetype() >= MessageType.GROUPINVITE && msg.getNoticetype() <= MessageType.GROUPINVITEAGREED) {
				msg.setData(userDao.selectByPrimaryKey(msg.getSenderid()));
			}
		}
		return new JsonResult<List<NoticeMsg>>(true, "��ȡ֪ͨ�ɹ�", list);
	}
	
	/**
	 * �ܾ����ѣ�Ⱥ�ģ�����
	 * @param noticeMsg
	 * @return
	 */
	public JsonResult<Integer> refuseNotice(NoticeMsg noticeMsg){
		noticeMsg.setStatus(2);
		int row = dao.updateByPrimaryKeySelective(noticeMsg);
		if(row > 0)
			return new JsonResult<Integer>(true, "����֪ͨ״̬�ɹ�");
		else
			return new JsonResult<Integer>(false, "����֪ͨ״̬ʧ��");	
	}
	
	/**
	 * ͬ����ѣ�Ⱥ�ģ�����
	 * @param noticeMsg
	 * @return
	 */
	public JsonResult<Integer> agreeNotice(NoticeMsg noticeMsg){
		noticeMsg.setStatus(3);
		int row = dao.updateByPrimaryKeySelective(noticeMsg);
		if(row > 0)
			return new JsonResult<Integer>(true, "����֪ͨ״̬�ɹ�");
		else
			return new JsonResult<Integer>(false, "����֪ͨ״̬ʧ��");	
	}
	
}
