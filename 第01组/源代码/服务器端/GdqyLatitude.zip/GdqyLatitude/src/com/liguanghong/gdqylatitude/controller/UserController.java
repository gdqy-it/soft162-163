package com.liguanghong.gdqylatitude.controller;


import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.liguanghong.gdqylatitude.pojo.Friend;
import com.liguanghong.gdqylatitude.pojo.User;
import com.liguanghong.gdqylatitude.service.UserService;
import com.liguanghong.gdqylatitude.util.JsonResult;

@Controller
@RequestMapping("/user")  
public class UserController {
	@Resource(name="userService")
	private UserService userService;
	
	/**
	 * api-user-001-ע��
	 * @param logname
	 * @param password
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/signup", method=RequestMethod.POST)
	public JsonResult<User> signUp(@RequestParam("logname") String logname, 
			@RequestParam("password") String password){
		return userService.signUp(logname, password);
	}
	
	/**
	 * api-user-002-��¼
	 * @param logname
	 * @param password
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/signin", method=RequestMethod.POST)
	public JsonResult<JSONObject> signIn(@RequestParam("logname") String logname, 
			@RequestParam("password") String password){
		return userService.signIn(logname, password);
	}
	
	/**
	 * api-user-003-�˳���¼
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/signout", method=RequestMethod.POST)
	public JsonResult<Integer> signOut(@RequestParam("userid") Integer userid){
		return userService.signOut(userid);
	}
	
	/**
	 * api-user-004-ע��
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/logout", method=RequestMethod.POST)
	public JsonResult<Integer> logOut(@RequestParam("userid") Integer userid){
		return userService.logout(userid);
	}
	
	/**
	 * api-user-005-�����û���Ϣ
	 * @param user
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/update", method=RequestMethod.POST)
	public JsonResult<User> update(User user){
		return userService.update(user);
	}
	
	/**
	 * ����λ����Ϣ
	 * @param userid
	 * @param latitude
	 * @param longitude
	 */
	@ResponseBody
	@RequestMapping(value="/updatelocation", method=RequestMethod.POST)
	public JsonResult<Integer> updateLocation(@RequestParam("userid") Integer userid,
			@RequestParam("latitude") double latitude,
			@RequestParam("longitude") double longitude) {
		return userService.updateLocation(userid, latitude, longitude);
	}
	
	
	/**
	 * api-user-006-��ѯָ���û�
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/find", method=RequestMethod.POST)
	public JsonResult<User> findByID(@RequestParam("userid") Integer userid){
		return userService.findByID(userid);
	}
	
	/**
	 * api-user-007-��ѯ�����б�
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/findfriends", method=RequestMethod.POST)
	public JsonResult<Map<String, List<Friend>>> findFriends(@RequestParam("userid") Integer userid){
		return userService.findFriends(userid);
	}
	
	/**
	 * api-user-008-��ѯ�����û�
	 * @param statu
	 * @param required
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/findall", method=RequestMethod.POST)
	public JsonResult<PageInfo<User>> findAll(@RequestParam("userid") Integer userid,
			@RequestParam("statu") Integer statu, 
			@RequestParam("required") Integer required,
			@RequestParam("page") Integer page){
		return userService.findAll(userid, statu, required, page);
	}
	
	/**
	 * api-user-009-ģ�������û�
	 * @param keyText
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/search", method=RequestMethod.POST)
	public JsonResult<PageInfo<User>> search(@RequestParam("userid") Integer userid,
			@RequestParam("keyword") String keyword,
			@RequestParam("page") Integer page){
		return userService.search(userid, keyword, page);
	}
	
	/**
	 * api-user-010-��ѯ�û�����
	 * @param statu
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/getcount", method=RequestMethod.POST)
	public JsonResult<Integer> getCount(@RequestParam("statu") Integer statu){
		return userService.getCount(statu);
	}
	
	/**
	 * api-user-011-����
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/freeze", method=RequestMethod.POST)
	public JsonResult<Integer> freeze(@RequestParam("userid") Integer userid){
		return userService.freeze(userid);
	}
	
	/**
	 * api-user-012-���
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/unfreeze", method=RequestMethod.POST)
	public JsonResult<Integer> unFreeze(@RequestParam("userid") Integer userid){
		return userService.unFreeze(userid);
	}
	
	/**
	 * api-user-013-���Ӻ���
	 * @param userid
	 * @param targetuserid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/addfriend", method=RequestMethod.POST)
	public JsonResult<Integer> addFriend(@RequestParam("userid") Integer userid, 
			@RequestParam("targetuserid") Integer targetuserid){
		return userService.addFriend(userid, targetuserid);
	}
	
	/**
	 * api-user-014-ɾ������
	 * @param userid
	 * @param targetuserid
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/deletefriend", method=RequestMethod.POST)
	public JsonResult<Integer> deleteFriend(@RequestParam("userid") Integer userid, 
			@RequestParam("targetuserid") Integer targetuserid){
		return userService.deleteFriend(userid, targetuserid);
	}
	
	
	/**
	 * api-user-015-�޸ĺ��ѱ�ע
	 * @param userid
	 * @param targetid
	 * @param remark
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/changefriendremark", method=RequestMethod.POST)
	public JsonResult<Integer> changeFriendRemark(@RequestParam("userid") Integer userid,
			@RequestParam("targetid") Integer targetid,
			@RequestParam("remark") String remark){
		return userService.changeFriendRemark(userid, targetid, remark);
	}
	
	/**
	 * api-user-016-�������ѷ���
	 * @param userid
	 * @param setName
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/createfriendsset", method=RequestMethod.POST)
	public JsonResult<Integer> createFriendsSet(@RequestParam("userid") Integer userid,
			@RequestParam("setName") String setName){
		return userService.createFriendsSet(userid, setName);
	}
	
	/**
	 * api-user-017-ɾ�����ѷ���
	 * @param userid
	 * @param setName
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/deletefriendsset", method=RequestMethod.POST)
	public JsonResult<Integer> deleteFriendsSet(@RequestParam("userid") Integer userid,
			@RequestParam("setName") String setName){
		return userService.deleteFriendsSet(userid, setName);
	}
	
	/**
	 * api-user-018-���·�����
	 * @param userid
	 * @param fromsetname
	 * @param tosetname
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/updatefriendsset", method=RequestMethod.POST)
	public JsonResult<Integer> updateFriendsSet(@RequestParam("userid") Integer userid,
			@RequestParam("fromsetname") String fromsetname,
			@RequestParam("tosetname") String tosetname){
		return userService.udpateFriendsSet(userid, fromsetname, tosetname);
	}
	/**
	 * api-user-019-�ƶ��������ڷ���
	 * @param userid
	 * @param targetid
	 * @param fromSetName
	 * @param toSetName
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/changefriendsset", method=RequestMethod.POST)
	public JsonResult<Integer> removeFriendsSet(@RequestParam("userid") Integer userid,
			@RequestParam("targetid") Integer targetid, 
			@RequestParam("fromSetName") String fromSetName,
			@RequestParam("toSetName") String toSetName){
		return userService.changeFriendsSet(userid, targetid, fromSetName, toSetName);
	}
	
	@ResponseBody
	@RequestMapping(value="/getcheck", method=RequestMethod.POST)
	public JsonResult<String> getCheck(@RequestParam("email") String email){
		return userService.getCheck(email);
	}
	
}
