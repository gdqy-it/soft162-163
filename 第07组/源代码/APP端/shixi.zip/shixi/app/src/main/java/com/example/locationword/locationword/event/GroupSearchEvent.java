package com.example.locationword.locationword.event;

public class GroupSearchEvent {
    public void GroupSearchEvent(){

    }
}
