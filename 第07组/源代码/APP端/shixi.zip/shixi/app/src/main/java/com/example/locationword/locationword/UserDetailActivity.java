package com.example.locationword.locationword;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class UserDetailActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.me_fragment);
        iniView();

        addListener();

    }
    protected void iniView(){

    }
    protected void addListener(){

    }
}
