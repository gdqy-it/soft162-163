package com.example.locationword.locationword.tool;

import android.content.Context;
import android.widget.Toast;

public class ShowUtil {
    public static void showText(Context c,String s){
        Toast.makeText(c,s,Toast.LENGTH_SHORT).show();
    }

}
