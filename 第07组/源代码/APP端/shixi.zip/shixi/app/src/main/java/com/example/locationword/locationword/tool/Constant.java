package com.example.locationword.locationword.tool;

public class Constant {
    public static final int httpSuccess = 1000;
    public static final Integer httpFaile = 1001;
    public static final String  logindata="Login";
    public static final String EaseGroupId="GroupId";
    public static final String EaseChattype="ChatType";

    public static final String UserId="userid";

    public static final String UserPhone="userphone";

    public static String getLocation="getLocation";
    public static String autoLogin="autoLogin";
    public static String autoTuis="autoTuis";

}
