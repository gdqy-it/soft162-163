package com.example.locationword.locationword.event;

public class GroupUpdateEvent {
    boolean f;
    public GroupUpdateEvent(boolean f) {

    }

    public void setF(boolean f) {
        this.f = f;
    }

    public boolean getF() {
        return f;
    }
}
