package com.example.locationword.locationword.event;

public class MessageUpdateEvent {
    boolean f;
    public MessageUpdateEvent(boolean f) {

    }

    public void setF(boolean f) {
        this.f = f;
    }

    public boolean getF() {
        return f;
    }
}
