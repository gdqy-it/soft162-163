package com.example.locationword.locationword.myview;

import com.hyphenate.easeui.ui.EaseChatFragment;

public class ChatFragment extends EaseChatFragment {
}
