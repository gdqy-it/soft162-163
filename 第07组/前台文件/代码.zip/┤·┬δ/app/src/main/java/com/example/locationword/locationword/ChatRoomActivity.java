package com.example.locationword.locationword;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
//
//import com.easemob.easeui.EaseConstant;
//import com.easemob.easeui.ui.EaseChatFragment;

public class ChatRoomActivity extends AppCompatActivity {
    public void onCreate(Bundle bundle){
        super.onCreate(bundle);
        setContentView(R.layout.chatroom_activity);
//        EaseChatFragment chatFragment = new EaseChatFragment();
//        //传入参数
//        Bundle args = new Bundle();
//        args.putInt(EaseConstant.EXTRA_CHAT_TYPE, EaseConstant.CHATTYPE_GROUP);
//        args.putString(EaseConstant.EXTRA_USER_ID, "zw123");
//        args.putString("username","dsdsd");
//
//        getSupportFragmentManager().beginTransaction().add(R.id.fl, chatFragment).commit();
    }
}
