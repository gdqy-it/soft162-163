$(function(){
   $(".all").click(function() {
   	//console.log($(".one").length);
     for (var i = 0; i < $(".one").length; i++) {
         var checkbox = $(".one")[i];
         checkbox.checked = this.checked;
     }
   }); 
});


