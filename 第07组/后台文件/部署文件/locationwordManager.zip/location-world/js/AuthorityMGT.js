var pagenum=10;
var lastest=10;
var http="http://172.17.146.156:8082/locationword/";
var arr=location.search.slice(1).split(";");//加载页面传来的参数
$(function(){
	loadinfo(0,pagenum,true);
	//changePageColor();
//	$(".next-page").click(function(){
//		if(pagenum<lastest){
//			$("tbody")[0].innerHTML = "";
//			loadinfo(pagenum,pagenum+10);
//			//changePageColor();
//			pagenum+=10;
//		}
//		console.log(pagenum);
//	});
//	
//	$(".last-page").click(function(){		 
//		if(pagenum>10){
//			$("tbody")[0].innerHTML= "";
//			pagenum-=10;
//			loadinfo(pagenum-10,pagenum);
//			//changePageColor(pagenum);
//			if(pagenum<0){
//				pagenum=0;
//			}
//		}
//	});
});
//改变按钮颜色，不成功
var changePageColor=function(){
	if(pagenum>=lastest-10){
		$(".next-page").css("color","darkgray");
	}else{
		$(".next-page").css("color","black");
	}
	if(pagenum<=10){	
		$(".last-page").css("color","darkgray");
	}else{
		$(".last-page").css("color","black");
	}
}

var loadinfo=function(a,b,flag){
	var u=http+"Manager/getAdmins";
	var arr=location.search.slice(1).split(";");//加载页面传来的参数
	$.ajax({
			url : u ,
			type : "GET",
			//contentType:"application/x-www-form-urlencoded",	
			dataType:"json",
			data:{
				adminId:arr[1]
			},
			//dataType : "json",//返回的数据类型
			success : function(data) {
				//console.log(data.length);
				var item;
				var item2;
				if(flag) init(Math.ceil(data.length/10));
				$.each(data,function(i,result){
					if(i>=a&&i<b){						
						item='<tr><td><input type="checkbox" class="one" onclick="check(this)" /></td><td class="adminID">'+result.AdminId+"</td><td>"+result.AdminUsername+"</td><td>"+result.AdminUserPassword+"</td><td>"+result.AdminPhone;
						item2="</td><td>"+result.AdminTime+"</td></tr>";
						$('tbody').append(item+item2);
					}
				}); 
			},
			error : function() {

				alert("查询失败！");

			}
});
}

var check=function(box){
	var flag=box.checked;
	if(!box.checked){
		$(".all").prop("checked",flag);
	}
}

//搜索
$(function(){
	$(".btn-search").click(function(){
		if($(".search-name").val()!=""){
			$("tbody")[0].innerHTML= "";
			searchAdmin();
		}
			
	})
});
var searchAdmin=function(){	
	var u=http+"Manager/getAdmins";
	var searchName=$(".search-name").val();
	$.ajax({
			url : u,
			type : "GET",
			//contentType:"application/x-www-form-urlencoded",	
			dataType:"json",
			data:{
				adminId:arr[1]
			},
			//dataType : "json",//返回的数据类型
			success : function(data) {
				//console.log(data.length);
				var item;
				var item2;
				$.each(data,function(i,result){
					if(searchName==result.AdminUsername){						
						item='<tr><td><input type="checkbox" class="one" /></td><td class="adminID">'+result.AdminId+"</td><td>"+result.AdminImage+"</td><td>"+result.AdminUsername+"</td><td>"+result.AdminUserPassword+"</td><td>"+result.AdminPhone;
						item2="</td><td>"+result.AdminTime+"</td></tr>";
						$('tbody').append(item+item2);
					}
				}); 
			},
			error : function() {

				alert("查询失败！");

			}
});
}
//添加管理员
$(function(){
	$(".add-admin").click(function(){
		$(".add-admin-div").show();
	});
	
		$(".new-admin-name").blur(function(){
			var n=$(".new-admin-name").val();
			
			
			if(n.length==0){
				$(".warning").val("用户名不能为空！");
			}
			else{
				$(".warning").val("");
				console.log(n.length);
				$(".new-admin-password").blur(function(){
					var p=$(".new-admin-password").val();
					if(p.length<6||p.length>12){			
						$(".warning").val("请输入6-12位的密码！");
					}
					else{
						$(".warning").val("");
						$(".new-admin-phone").blur(function(){
							var h=$(".new-admin-phone").val();
							var myreg=/^[1][3,4,5,7,8][0-9]{9}$/;
							if(!myreg.test(h)){
								$(".warning").val("输入有效的手机号码");
							}
							else{
								$(".warning").val("");
								$(".new-admin").click(function(){
									addAdmin();
									$(".add-admin-div").hide();
								});
							}
						});
					}
				});
			}
		});	
	
	$(".cancle-admin").click(function(){
		$(".add-admin-div").hide();
	});	
});
var addAdmin=function(){
	var u=http+"Manager/addAdmin";
				var n=$(".new-admin-name").val();
				var p=$(".new-admin-password").val();
				var h=$(".new-admin-phone").val();
				$.ajax({
				url: u,
				type: 'post',  
//				contentType:"application/x-www-form-urlencoded",
				//async:false, 
				dataType:"json",
				data: {
					AdminUsername:n,
					AdminPassword:p,
					AdminPhone:h
				},
				success:function(data){
					//var dataObj = JSON.parse(data);
					console.log(data);
					if(data.message='添加成功'){
						console.log(data.message);
						alert("添加成功");
						$("tbody")[0].innerHTML = "";
						loadinfo(0,10,true);
					}else{
					}
				}, 
				error:function(data){
				}

		});
		}
//取消管理员
$(function(){
	$(".close-admin").click(function(){
		var checkItems=$(".one");
		var checkAdminID=$(".adminID");
		//var array="";
		//alert(checkItems.length);
		var itemArray=new Array();　
		for (var i=0;i<checkItems.length;i++){
			if(checkItems[i].checked){				
				itemArray.push(parseInt(checkAdminID[i].innerText));
			}
		}
		if(itemArray.length>0){
			$(".promt-contain").val("确定取消该管理员?");
			$(".promt").show();
			$(".sure").click(function(){
				$(".promt").hide();
				removeAdmin("["+itemArray+"]");
			});
			$(".cancle").click(function(){
				$(".promt").hide();
			});
		
		}
	})
})
var removeAdmin=function(items){
	var u=http+"Manager/removeAdmin";
	$.ajax({
				url: u,
				type: 'post',  
				contentType:"application/x-www-form-urlencoded",
				data: {
					AdminIdArray:items
				},
				success:function(data){
					console.log(data);
					if(data.message='修改成功'){
						$("tbody")[0].innerHTML = "";
						loadinfo(0,10,true);
						$(".all").attr("checked",false);
					}else{
					}
				}, 
				error:function(data){
				}

		});
}

$(function(){
	$(".add-admin-div").blur(function(){
		$(".add-admin-div").hide();
	})
})

//分页
var Pagination = {

    code: '',

    // --------------------
    // Utility
    // --------------------

    // converting initialize data
    Extend: function(data) {
        data = data || {};
        Pagination.size = data.size || 300;
        Pagination.page = data.page || 1;
        Pagination.step = data.step || 3;
    },

    // add pages by number (from [s] to [f])
    Add: function(s, f) {
        for (var i = s; i < f; i++) {
            Pagination.code += '<a>' + i + '</a>';
        }
    },

    // add last page with separator
    Last: function() {
        Pagination.code += '<i>...</i><a>' + Pagination.size + '</a>';
    },

    // add first page with separator
    First: function() {
        Pagination.code += '<a>1</a><i>...</i>';
    },



    // --------------------
    // Handlers
    // --------------------

    // change page
    Click: function() {
        Pagination.page = +this.innerHTML;
        Pagination.Start();
        $("tbody")[0].innerHTML = "";
        loadinfo(Pagination.page*10-10,Pagination.page*10,false);
    },
	
    // previous page
    Prev: function() {
        Pagination.page--;
        if (Pagination.page < 1) {
            Pagination.page = 1;
        }
        $("tbody")[0].innerHTML = "";
        loadinfo(Pagination.page*10-10,Pagination.page*10,false);
        Pagination.Start();
    },

    // next page
    Next: function() {
        Pagination.page++;
        if (Pagination.page > Pagination.size) {
            Pagination.page = Pagination.size;
        }
        $("tbody")[0].innerHTML = "";
        loadinfo(Pagination.page*10-10,Pagination.page*10,false);
        Pagination.Start();
    },



    // --------------------
    // Script
    // --------------------

    // binding pages
  Bind: function() {
        var a = Pagination.e.getElementsByTagName('a');
        for (var i = 0; i < a.length; i++) {
            if (+a[i].innerHTML === Pagination.page){
            	a[i].className = 'current';
            } 
            a[i].addEventListener('click', Pagination.Click, false);
        }
    },

    // write pagination
    Finish: function() {
        Pagination.e.innerHTML = Pagination.code;
        Pagination.code = '';
        Pagination.Bind();
    },

    // find pagination type
    Start: function() {
        if (Pagination.size < Pagination.step * 2 + 6) {
            Pagination.Add(1, Pagination.size + 1);
        }
        else if (Pagination.page < Pagination.step * 2 + 1) {
            Pagination.Add(1, Pagination.step * 2 + 4);
            Pagination.Last();
        }
        else if (Pagination.page > Pagination.size - Pagination.step * 2) {
            Pagination.First();
            Pagination.Add(Pagination.size - Pagination.step * 2 - 2, Pagination.size + 1);
        }
        else {
            Pagination.First();
            Pagination.Add(Pagination.page - Pagination.step, Pagination.page + Pagination.step + 1);
            Pagination.Last();
        }
        Pagination.Finish();
    },



    // --------------------
    // Initialization
    // --------------------

    // binding buttons
    Buttons: function(e) {
        var nav = e.getElementsByTagName('a');
        nav[0].addEventListener('click', Pagination.Prev, false);
        nav[1].addEventListener('click', Pagination.Next, false);
    },

    // create skeleton
    Create: function(e) {

        var html = [
            '<a>&#9668;</a>', // previous button
            '<span></span>',  // pagination container
            '<a>&#9658;</a>'  // next button
        ];

        e.innerHTML = html.join('');
        Pagination.e = e.getElementsByTagName('span')[0];
        Pagination.Buttons(e);
    },

    // init
    Init: function(e, data) {
        Pagination.Extend(data);
        Pagination.Create(e);
        Pagination.Start();
    }
};





var init = function(pageSize) {
//	alert(pageSize);
    Pagination.Init(document.getElementById('pagination'), {
        size: pageSize, // pages size
        page: 1,  // selected page
        step: 3   // pages before and after current
    });
};