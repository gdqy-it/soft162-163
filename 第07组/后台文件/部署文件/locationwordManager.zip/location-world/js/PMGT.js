var pagenum=10;
var lastest;
var http="http://172.17.146.156:8082/locationword/";
var arr=location.search.slice(1).split(";");//加载页面传来的参数
$(function(){
	
	loadinfo(0,pagenum,true);
	//上下页
//	$(".next-page").click(function(){
//		if(pagenum<lastest){
//			$("tbody")[0].innerHTML = "";
//			loadinfo(pagenum,pagenum+10);
//			//changePageColor();
//			pagenum+=10;
//		}
//	});
//	
//	$(".last-page").click(function(){		 
//		if(pagenum>10){
//			$("tbody")[0].innerHTML= "";
//			pagenum-=10;
//			loadinfo(pagenum-10,pagenum);
//			//changePageColor(pagenum);
//			if(pagenum<0){
//				pagenum=0;
//			}
//		}
//	});
});
var changePageColor=function(){
	if(pagenum>=lastest-10){
		$(".next-page").css("color","darkgray");
	}else{
		$(".next-page").css("color","black");
	}
	if(pagenum<=10){	
		$(".last-page").css("color","darkgray");
	}else{
		$(".last-page").css("color","black");
	}
}
//加载表格数据
var loadinfo=function(a,b,flag){
	var u=http+"Manager/getUsers"
	$.ajax({
			asasync:false,//异步设置
			url : u ,
			type : "GET",
			//contentType:"application/x-www-form-urlencoded",	
			dataType:"json",
			data:{
				adminId:arr[1]
			},
			//dataType : "json",//返回的数据类型
			success : function(data) {
				var item;
				var item2;
				var breaker;			
				if(flag) init(Math.ceil(data.length/10));
				$.each(data,function(i,result){
					if(result.IsBreak==0){
						breaker="普通用户";
					}else{
						breaker="黑名单用户";
					}
					if(i>=a&&i<b){		
						item='<tr><td><input type="checkbox" class="one" onclick="check(this)"/></td><td  class="userID">'+result.UserId+"</td><td>"+result.UserPhone+"</td><td>"+result.NickName+"</td><td>"+result.RealName+"</td><td>"+result.Password;
						if(result.UserAvarl=="null"||result.UserAvarl==""){
							item2="</td><td><img src='../img/logo.png' width='20px' heigh='20px'/></td><td>"+breaker+"</td></tr>";
						}else{
							console.log(result.UserAvarl);
							item2="</td><td><img src='"+http+result.UserAvarl+"' width='20px' heigh='20px'/></td><td>"+breaker+"</td></tr>";
						}
						
						$('tbody').append(item+item2);
					}
				}); 
			},
			error : function() {

				alert("查询失败！");

			}
});
}

var check=function(box){
	var flag=box.checked;
	if(!flag){
		$(".all").prop("checked",flag);
	}
}

//搜索
$(function(){
	$(".btn-search").click(function(){
		if($(".search-name").val()!=""){
			$("tbody")[0].innerHTML= "";
			searchUser();
		}
			
	})
});
var searchUser=function(){	
	var u=http+"Manager/getUsers";
	var searchName=$(".search-name").val();
	var arr=location.search.slice(1).split(";");//加载页面传来的参数
	$.ajax({
			url : u,
			type : "GET",
			//contentType:"application/x-www-form-urlencoded",	
			dataType:"json",
			data:{
				adminId:arr[1]
			},
			//dataType : "json",//返回的数据类型
			success : function(data) {
				//console.log(data.length);
				var item;
				var item2;
				$.each(data,function(i,result){
					if(searchName==result.RealName){						
						item='<tr><td><input type="checkbox" class="one"/></td><td class="userID">'+result.UserId+"</td><td>"+result.UserPhone+"</td><td>"+result.NickName+"</td><td>"+result.RealName+"</td><td>"+result.Password;
						item2="</td><td>"+result.UserAvarl+"</td><td>"+result.IsBreak+"</td></tr>";
						$('tbody').append(item+item2);
					}
				}); 
			},
			error : function() {

				alert("查询失败！");

			}
});
}
//加入黑名单
$(function(){
	$(".set-black").click(function(){
		var checkItems=$(".one");
		var checkUserID=$(".userID");
		var itemArray=new Array();　
		for (var i=0;i<checkItems.length;i++){
			if(checkItems[i].checked){	
				itemArray.push(parseInt(checkUserID[i].innerText));
			}
		}
		if(itemArray.length>0){
			$(".promt-contain").val("确定设置该用户为黑名单?");
			$(".promt").show();
			$(".sure").click(function(){
				$(".promt").hide();
				setUserBlack("["+itemArray+"]");
			});
			$(".cancle").click(function(){
				$(".promt").hide();
			});
		
		}
		
		
	})
})
var setUserBlack=function(items){
	var u=http+"Manager/addUserBreak";
	$.ajax({
				url: u,
				type: 'post',
				contentType:"application/x-www-form-urlencoded",
				data: {
					userArray:items
				},
				success:function(data){
					if(data.message='修改成功'){
						$("tbody")[0].innerHTML = "";
						loadinfo(0,10,true);
						$(".all").attr("checked",false);
					}else{
					}
				}, 
				error:function(data){
				}

		});
}
//解除黑名单
$(function(){
	$(".cancle-black").click(function(){
		var checkItems=$(".one");
		var checkUserID=$(".userID");
		var itemArray=new Array();　
		for (var i=0;i<checkItems.length;i++){
			if(checkItems[i].checked){	
				itemArray.push(parseInt(checkUserID[i].innerText));
			}
		}
		if(itemArray.length>0){
			$(".promt-contain").val("确定取消该用户黑名单?");
			$(".promt").show();
			$(".sure").click(function(){
				$(".promt").hide();
				cancleUserBlack("["+itemArray+"]");
			});
			$(".cancle").click(function(){
				$(".promt").hide();
			});
		
		}
		
		
	})
})
var cancleUserBlack=function(items){
	var u=http+"Manager/removeUserBreak";
	$.ajax({
				url: u,
				type: 'post',
				contentType:"application/x-www-form-urlencoded",
				data: {
					userArray:items
				},
				success:function(data){
					if(data.message='修改成功'){
						$("tbody")[0].innerHTML = "";
						loadinfo(0,10,true);
						$(".all").attr("checked",false);
					}else{
					}
				}, 
				error:function(data){
				}

		});
}

$(function(){
   for (var i = 0; i < $(".one").length; i++) {
    solo( $(".one")[i]);
	}	
})
var solo=function(one){
	one.click(function(){
     	console.log( $(".one").length);
         var isCheckedAll = true;
             if (!this.is(':checked')) {
                 isCheckedAll = false;
                 //alert(isCheckedAll); 
         }
         $(".all").attr("checked",flag);
     });
   }



	


var Pagination = {

    code: '',

    // --------------------
    // Utility
    // --------------------

    // converting initialize data
    Extend: function(data) {
        data = data || {};
        Pagination.size = data.size || 300;
        Pagination.page = data.page || 1;
        Pagination.step = data.step || 3;
    },

    // add pages by number (from [s] to [f])
    Add: function(s, f) {
        for (var i = s; i < f; i++) {
            Pagination.code += '<a>' + i + '</a>';
        }
    },

    // add last page with separator
    Last: function() {
        Pagination.code += '<i>...</i><a>' + Pagination.size + '</a>';
    },

    // add first page with separator
    First: function() {
        Pagination.code += '<a>1</a><i>...</i>';
    },



    // --------------------
    // Handlers
    // --------------------

    // change page
    Click: function() {
        Pagination.page = +this.innerHTML;
        Pagination.Start();
        $("tbody")[0].innerHTML = "";
        loadinfo(Pagination.page*10-10,Pagination.page*10,false);
    },
	
    // previous page
    Prev: function() {
        Pagination.page--;
        if (Pagination.page < 1) {
            Pagination.page = 1;
        }
        $("tbody")[0].innerHTML = "";
        loadinfo(Pagination.page*10-10,Pagination.page*10,false);
        Pagination.Start();
    },

    // next page
    Next: function() {
        Pagination.page++;
        if (Pagination.page > Pagination.size) {
            Pagination.page = Pagination.size;
        }
        $("tbody")[0].innerHTML = "";
        loadinfo(Pagination.page*10-10,Pagination.page*10,false);
        Pagination.Start();
    },



    // --------------------
    // Script
    // --------------------

    // binding pages
  Bind: function() {
        var a = Pagination.e.getElementsByTagName('a');
        for (var i = 0; i < a.length; i++) {
            if (+a[i].innerHTML === Pagination.page){
            	a[i].className = 'current';
            } 
            a[i].addEventListener('click', Pagination.Click, false);
        }
    },

    // write pagination
    Finish: function() {
        Pagination.e.innerHTML = Pagination.code;
        Pagination.code = '';
        Pagination.Bind();
    },

    // find pagination type
    Start: function() {
        if (Pagination.size < Pagination.step * 2 + 6) {
            Pagination.Add(1, Pagination.size + 1);
        }
        else if (Pagination.page < Pagination.step * 2 + 1) {
            Pagination.Add(1, Pagination.step * 2 + 4);
            Pagination.Last();
        }
        else if (Pagination.page > Pagination.size - Pagination.step * 2) {
            Pagination.First();
            Pagination.Add(Pagination.size - Pagination.step * 2 - 2, Pagination.size + 1);
        }
        else {
            Pagination.First();
            Pagination.Add(Pagination.page - Pagination.step, Pagination.page + Pagination.step + 1);
            Pagination.Last();
        }
        Pagination.Finish();
    },



    // --------------------
    // Initialization
    // --------------------

    // binding buttons
    Buttons: function(e) {
        var nav = e.getElementsByTagName('a');
        nav[0].addEventListener('click', Pagination.Prev, false);
        nav[1].addEventListener('click', Pagination.Next, false);
    },

    // create skeleton
    Create: function(e) {

        var html = [
            '<a>&#9668;</a>', // previous button
            '<span></span>',  // pagination container
            '<a>&#9658;</a>'  // next button
        ];

        e.innerHTML = html.join('');
        Pagination.e = e.getElementsByTagName('span')[0];
        Pagination.Buttons(e);
    },

    // init
    Init: function(e, data) {
        Pagination.Extend(data);
        Pagination.Create(e);
        Pagination.Start();
    }
};





var init = function(pageSize) {
    Pagination.Init(document.getElementById('pagination'), {
        size: pageSize, // pages size
        page: 1,  // selected page
        step: 3   // pages before and after current
    });
};
