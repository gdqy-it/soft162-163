var pagenum=10;
var lastest=10;
var http="http://172.17.146.156:8082/locationword/";
var arr=location.search.slice(1).split(";");//加载页面传来的参数
//翻页按钮
$(function(){
	loadinfo(0,pagenum,true);

});


//加载表格数据
var loadinfo=function(a,b,flag){
	var u=http+"Manager/getGroups";
	
	//var num=location.search;
	console.log(arr);	
	$.ajax({
			url:u,
			type : "GET",
			//contentType:"application/x-www-form-urlencoded",	
			dataType:"json",
			data:{
				adminId:arr[1]
			},
			//dataType : "json",//返回的数据类型
			success : function(data) {
				//console.log(data.length);
				var item;
				var item2;
				if(flag) init(Math.ceil(data.length/10));
				$.each(data,function(i,result){
					if(i>=a&&i<b){		
//						if(result.GroupImage=="null"||result.GroupImage==""){
							item2="<img src='../img/logo.png' width='20px' heigh='20px'/></td><td>"+result.GroupMan+"</td><td>"+result.GroupManPhone+"</td><td>"+result.isBreak+"</td></tr>";	
//						}else{
//							item2="<img src='"+http+result.GroupImage+"' width='20px' heigh='20px'/></td><td>"+result.GroupMan+"</td><td>"+result.GroupManPhone+"</td><td>"+result.isBreak+"</td></tr>";
//						}
							
						item='<tr><td><input type="checkbox" class="one" onclick="check(this)" /></td><td class="groupID">'+result.GroupId+"</td><td>"+result.GroupName+"</td><td>"+result.GroupDisctribe+"</td><td class='groupImage'>";
						
//						$(".groupImage").css("background-image","url(../img/logo.png)");
						$('tbody').append(item+item2);
					}
				}); 
			},
			error : function() {

				alert("查询失败！");

			}
});
}

var check=function(box){
	var flag=box.checked;
	if(!flag){
		$(".all").prop("checked",flag);
	}
}
//搜索按钮
$(function(){
	$(".btn-search").click(function(){
		if($(".search-name").val()!=""){
			$("tbody")[0].innerHTML= "";
			searchGroup();
		}
			
	})
	$(".search-name").keydown(function(event){
		if(event.keyCode == 13){
		if($(".search-name").val()!=""){
			$("tbody")[0].innerHTML= "";
			searchGroup();
		}
		}
	});
})
//搜索功能
var searchGroup=function(){	
	var u=http+"Manager/getGroups"
	var searchName=$(".search-name").val();
	$.ajax({
//			url : 'http://172.17.144.25:8082/locationword/Manager/getGroups',
			url:u,
			type : "GET",
			//contentType:"application/x-www-form-urlencoded",	
			dataType:"json",
			data:{
				adminId:arr[1]
			},
			//dataType : "json",//返回的数据类型
			success : function(data) {
				//console.log(data.length);
				var item;
				var item2;
				lastest=data.length;
				$.each(data,function(i,result){
					if(searchName==result.GroupName){						
						item='<tr style><td><input type="checkbox" class="one" /></td><td>'+result.GroupId+"</td><td>"+result.GroupName+"</td><td>"+result.GroupDisctribe+"</td><td>"+result.GroupImage+"</td><td>"+result.GroupMan;
						item2="</td><td>"+result.GroupManPhone+"</td><td>"+result.isBreak+"</td></tr>";
						$('tbody').append(item+item2);
						//alert("desfds");
					}else{
						alert("no no no");
					}
				}); 
			},
			error : function() {

				alert("查询失败！");

			}
});
}
//封群
$(function(){
	$(".set-black").click(function(){
		var checkItems=$(".one");
		var checkUserID=$(".groupID");
		var itemArray=new Array();　
		var flag;
		for (var i=0;i<checkItems.length;i++){
			if(checkItems[i].checked){	
				itemArray.push(parseInt(checkUserID[i].innerText));
				flag=true;
				
			}
		}
		if(flag){
			$(".promt-contain").val("确定加入黑名单群组?");
			$(".promt").show();
			$(".sure").click(function(){
				$(".promt").hide();
				setGroupBlack("["+itemArray+"]");
			});
			$(".cancle").click(function(){
				$(".promt").hide();
			});
			flag=false;
		}
			
		
	})
})
var setGroupBlack=function(items){
	var u=http+"Manager/addGroupBreak"
	$.ajax({
				url:u,
				type: 'post',
				contentType:"application/x-www-form-urlencoded",
				data: {
					GroupArray:items
				},
				success:function(data){
					if(data.message='修改成功'){
//						alert("已成功加入封群");
						$("tbody")[0].innerHTML = "";
						loadinfo(0,10,true);
						$(".all").attr("checked",false);
					}else{
					}
				}, 
				error:function(data){
				}

		});
}
//解群
$(function(){
	$(".cancle-black").click(function(){
		var checkItems=$(".one");
		var checkUserID=$(".groupID");
		var itemArray=new Array();　
		var flag;
		for (var i=0;i<checkItems.length;i++){
			if(checkItems[i].checked){	
				itemArray.push(parseInt(checkUserID[i].innerText));
				flag=true;
			}
		}
		if(flag){
			$(".promt-contain").val("确定解除黑名单群组?");
			$(".promt").show();
			$(".sure").click(function(){
				$(".promt").hide();
				cancleGroupBlack("["+itemArray+"]");
			});
			$(".cancle").click(function(){
				$(".promt-contain").remove();
				$(".promt").hide();
			});
			flag=false;
		}
		
		
	})
})
var cancleGroupBlack=function(items){
	var u=http+"Manager/removeGroupBreak";
	$.ajax({
//				url: 'http://172.17.144.25:8082/locationword/Manager/removeGroupBreak',
				url:u,
				type: 'post',
				contentType:"application/x-www-form-urlencoded",
				data: {
					GroupArray:items
				},
				success:function(data){
					if(data.message='修改成功'){
						alert("已成功加入解群");
						$("tbody")[0].innerHTML = "";
						loadinfo(0,10,true);
						$(".all").attr("checked",false);
					}else{
					}
				}, 
				error:function(data){
				}

		});
}
//分页
var Pagination = {

    code: '',

    // --------------------
    // Utility
    // --------------------

    // converting initialize data
    Extend: function(data) {
        data = data || {};
        Pagination.size = data.size || 300;
        Pagination.page = data.page || 1;
        Pagination.step = data.step || 3;
    },

    // add pages by number (from [s] to [f])
    Add: function(s, f) {
        for (var i = s; i < f; i++) {
            Pagination.code += '<a>' + i + '</a>';
        }
    },

    // add last page with separator
    Last: function() {
        Pagination.code += '<i>...</i><a>' + Pagination.size + '</a>';
    },

    // add first page with separator
    First: function() {
        Pagination.code += '<a>1</a><i>...</i>';
    },



    // --------------------
    // Handlers
    // --------------------

    // change page
    Click: function() {
        Pagination.page = +this.innerHTML;
        Pagination.Start();
        $("tbody")[0].innerHTML = "";
        loadinfo(Pagination.page*10-10,Pagination.page*10,false);
    },
	
    // previous page
    Prev: function() {
        Pagination.page--;
        if (Pagination.page < 1) {
            Pagination.page = 1;
        }
        $("tbody")[0].innerHTML = "";
        loadinfo(Pagination.page*10-10,Pagination.page*10,false);
        Pagination.Start();
    },

    // next page
    Next: function() {
        Pagination.page++;
        if (Pagination.page > Pagination.size) {
            Pagination.page = Pagination.size;
        }
        $("tbody")[0].innerHTML = "";
        loadinfo(Pagination.page*10-10,Pagination.page*10,false);
        Pagination.Start();
    },



    // --------------------
    // Script
    // --------------------

    // binding pages
  Bind: function() {
        var a = Pagination.e.getElementsByTagName('a');
        for (var i = 0; i < a.length; i++) {
            if (+a[i].innerHTML === Pagination.page){
            	a[i].className = 'current';
            } 
            a[i].addEventListener('click', Pagination.Click, false);
        }
    },

    // write pagination
    Finish: function() {
        Pagination.e.innerHTML = Pagination.code;
        Pagination.code = '';
        Pagination.Bind();
    },

    // find pagination type
    Start: function() {
        if (Pagination.size < Pagination.step * 2 + 6) {
            Pagination.Add(1, Pagination.size + 1);
        }
        else if (Pagination.page < Pagination.step * 2 + 1) {
            Pagination.Add(1, Pagination.step * 2 + 4);
            Pagination.Last();
        }
        else if (Pagination.page > Pagination.size - Pagination.step * 2) {
            Pagination.First();
            Pagination.Add(Pagination.size - Pagination.step * 2 - 2, Pagination.size + 1);
        }
        else {
            Pagination.First();
            Pagination.Add(Pagination.page - Pagination.step, Pagination.page + Pagination.step + 1);
            Pagination.Last();
        }
        Pagination.Finish();
    },



    // --------------------
    // Initialization
    // --------------------

    // binding buttons
    Buttons: function(e) {
        var nav = e.getElementsByTagName('a');
        nav[0].addEventListener('click', Pagination.Prev, false);
        nav[1].addEventListener('click', Pagination.Next, false);
    },

    // create skeleton
    Create: function(e) {

        var html = [
            '<a>&#9668;</a>', // previous button
            '<span></span>',  // pagination container
            '<a>&#9658;</a>'  // next button
        ];

        e.innerHTML = html.join('');
        Pagination.e = e.getElementsByTagName('span')[0];
        Pagination.Buttons(e);
    },

    // init
    Init: function(e, data) {
        Pagination.Extend(data);
        Pagination.Create(e);
        Pagination.Start();
    }
};





var init = function(pageSize) {
//	alert(pageSize);
    Pagination.Init(document.getElementById('pagination'), {
        size: pageSize, // pages size
        page: 1,  // selected page
        step: 3   // pages before and after current
    });
};
//$(function(){
//document.addEventListener('DOMContentLoaded', init, false);
//
//})