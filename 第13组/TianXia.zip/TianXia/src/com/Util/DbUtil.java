package com.Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {
	private Connection con;
	private String user = "root";//数据库用户名，
	private String password = "123456";//密码
	private String className = "com.mysql.jdbc.Driver";
	private String url = "jdbc:mysql://172.17.144.10:3306/walk";
	
	/** 创建数据库连接 */
	public Connection getCon() {
		try {
			Class.forName(className);
			con =  DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			con = null;
			e.printStackTrace();
		} 
		return con;
	}

	public void closed(Connection con)  {
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				con=null;
			}
		}
	}
}
