package com.Servlet;

import java.io.Console;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.UserDao;
import com.Util.DbUtil;
import com.model.User;

import org.apache.commons.lang.StringUtils;
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	UserDao userDao = new UserDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		String action = request.getParameter("action");
		if("register".equals(action)) {
			register(request,response);
		}else if("login".equals(action)) {
			login(request,response);
		}
	}

	private void register(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException {
		
		// TODO Auto-generated method stub
		String name = request.getParameter("UName");
		String phone = request.getParameter("UTel");
		String password = request.getParameter("UPassword");
		
		DbUtil dbUtil = new DbUtil();	
		Connection con = dbUtil.getCon();
		
		User user = new User(name, phone, null, password, null, null,"0");
		int addResult = 0;
		try {
			addResult = userDao.addUser(request, con, user);
		}catch (SQLException e){
			e.printStackTrace();
		}finally {
			dbUtil.closed(con);
		}
		
		if(addResult == 1) {
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}else {
			request.getRequestDispatcher("register.jsp").forward(request, response);
		}
	}

	private void login(HttpServletRequest request, HttpServletResponse response)throws ServletException , IOException{
		String phone = request.getParameter("UPhone");
		String password = request.getParameter("UPassword");
		request.setAttribute("phone", phone);
		request.setAttribute("password", password);
		if(StringUtils.isEmpty(phone)) {
			request.setAttribute("error", "手机号为空！");
			request.getRequestDispatcher("login.jsp").forward(request, response);
			return;
		}else if(StringUtils.isEmpty(password)) {
			request.setAttribute("error", "密码为空！");
			request.getRequestDispatcher("login.jsp").forward(request, response);
			return;
		}
		DbUtil dbUtil = new DbUtil();
		Connection connection=dbUtil.getCon();
		User user = null;
		
		try {
			user = userDao.login(request, connection, phone, password);	
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			dbUtil.closed(connection);
		}
		
		if(user == null) {
			request.setAttribute("error", "用户名或密码错误");
			request.getRequestDispatcher("login.jsp").forward(request, response);
			return;
		}else {
			HttpSession session = request.getSession();
			session.setAttribute("currentuser", user);
			response.sendRedirect("main.jsp");
		}
		
	}

}
