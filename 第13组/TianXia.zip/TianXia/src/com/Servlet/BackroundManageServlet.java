package com.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.jasper.tagplugins.jstl.core.Out;

import com.Dao.AdminLoginDao;
import com.Dao.GroupDao;
import com.Dao.SystemPushDao;
import com.Dao.UserDao;
import com.Util.DbUtil;
import com.Util.ResponseUtil;
import com.model.Admin;
import com.model.Group;
import com.model.SystemPush;
import com.model.User;

import net.sf.json.JSONObject;

@WebServlet("/BackroundManageServlet")
public class BackroundManageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserDao userDao = new UserDao();
	GroupDao groupDao = new GroupDao();
	SystemPushDao systemPushDao = new SystemPushDao();
	AdminLoginDao adminLoginDao = new AdminLoginDao();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		String action = request.getParameter("action");
		if("getUsers".equals(action)) {
			getUsers(request,response);
		}else if("userinfomation".equals(action)) {
			UserInformation(request,response);
		}else if("modifyuserinformation".equals(action)) {
			ModifyUserInformation(request,response);
		}else if("savenotice".equals(action)) {
			saveNotice(request,response);
		}else if("getGroups".equals(action)) {
			getGroups(request,response);
		}else if("searchUser".equals(action)) {
			searchUser(request,response);
		}else if("groupinfomation".equals(action)) {
			GroupInformation(request, response);
		}else if("searchGroup".equals(action)) {
			searchGroup(request,response);
		}else if("modifygroupinformation".equals(action)) {
			ModifyGroupInformation(request,response);
		}else if("getNotices".equals(action)) {
			getNotices(request,response);
		}else if("showPush".equals(action)) {
			showPush(request,response);
		}else if("adminlogin".equals(action)) {
			adminLogin(request,response);
		}
	}
	
	

	//管理员登陆
	private void adminLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String AdminName = request.getParameter("AdminName");
		String AdminPassword = request.getParameter("AdminPassword");
		
		request.setAttribute("AdminName", AdminName);
		request.setAttribute("AdminPassword", AdminPassword);
		System.out.println(AdminName);
		System.out.println(AdminPassword);
		if(StringUtils.isEmpty(AdminName)) {
			request.setAttribute("error", "用户名为空！");
			request.getRequestDispatcher("backLogin.jsp").forward(request, response);
			return;
		}else if(StringUtils.isEmpty(AdminPassword)) {
			request.setAttribute("error", "密码为空！");
			request.getRequestDispatcher("backLogin.jsp").forward(request, response);
			return;
		}
		DbUtil dbUtil = new DbUtil();
		Connection connection=dbUtil.getCon();
		Admin admin = null;
		
		try {
			admin = adminLoginDao.login(connection, AdminName, AdminPassword);	
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			dbUtil.closed(connection);
		}
		
		if(admin == null) {
			request.setAttribute("error", "用户名或密码错误");
			request.getRequestDispatcher("backLogin.jsp").forward(request, response);
			return;
		}else {
			HttpSession session = request.getSession();
			session.setAttribute("admin", admin);
			response.sendRedirect("manage.html");
		}
		
	}

	//显示单条系统推送
	private void showPush(HttpServletRequest request, HttpServletResponse response) throws IOException{
		SystemPush systemPush = new SystemPush();
		int id =Integer.parseInt(request.getParameter("pushid"));
		DbUtil dbutil = new DbUtil();
		Connection con = dbutil.getCon();
		try {
			systemPush = systemPushDao.information(id, con);
			HttpSession session = request.getSession();
			session.setAttribute("systemPush", systemPush);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			dbutil.closed(con);
		}
		if(systemPush != null) {
			response.sendRedirect("pushShow.jsp");
		}else {
			response.sendRedirect("404.jsp");
		}
	}
	
	//查询单个群组
	private void searchGroup(HttpServletRequest request, HttpServletResponse response) throws IOException{
		Group group = new Group();
		int id =Integer.parseInt(request.getParameter("search"));
		DbUtil dbutil = new DbUtil();
		Connection con = dbutil.getCon();
		try {
			group = groupDao.information(id, con);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			dbutil.closed(con);
		}
		if(group != null) {
			ArrayList<Group> groupList = new ArrayList<Group>();
			groupList.add(group);
			HttpSession session = request.getSession();
			session.setAttribute("groupList", groupList);
			response.sendRedirect("groupmanage.jsp");
		}else {
			response.sendRedirect("404.jsp");
		}
	}

	//查询单个用户
	private void searchUser(HttpServletRequest request, HttpServletResponse response) throws IOException{
		User user=new User();
		int id =Integer.parseInt(request.getParameter("search"));
		DbUtil dbutil = new DbUtil();
		Connection con = dbutil.getCon();
		try {
			user = userDao.information(id, con);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			dbutil.closed(con);
		}
		if(user != null) {
			ArrayList<User> userList = new ArrayList<User>();
			userList.add(user);
			HttpSession session = request.getSession();
			session.setAttribute("userList", userList);
			response.sendRedirect("membermanage.jsp");
		}else {
			response.sendRedirect("404.jsp");
		}
		
	}

	//获取群组列表
	private void getGroups(HttpServletRequest request, HttpServletResponse response) {
		JSONObject result = new JSONObject();
		ArrayList<Group> groupList = new ArrayList<Group>();
		DbUtil dbutil = new DbUtil();
		Connection con = dbutil.getCon();
		result.put("success", "success");
		try {
			groupList=groupDao.getgroups(request, con);
			HttpSession session = request.getSession();
			session.setAttribute("groupList", groupList);
			ResponseUtil.write(response, result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.closed(con);
		}
		
	}
	//保存系统公告
	private void saveNotice(HttpServletRequest request, HttpServletResponse response) throws IOException{
		SystemPush systemPush = new SystemPush();
		String content =request.getParameter("content");
		String theme = request.getParameter("theme");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        String time = sdf.format(date);
        systemPush.setContent(content);
        systemPush.setTheme(theme);
        systemPush.setData(time);
        systemPush.setStatus("0");
        DbUtil dbutil = new DbUtil();
		Connection con = dbutil.getCon();
		int result =0;
		try {
			result = systemPushDao.addSystemPush(con, systemPush);
		}catch (SQLException e){
			e.printStackTrace();
		}finally {
			dbutil.closed(con);
		}
		if(String.valueOf(result) != null) {
			response.sendRedirect("successSaveSystemPush.jsp");
		}else {
			response.sendRedirect("404.jsp");
		}
	}

	//修改用户信息
	private void ModifyUserInformation(HttpServletRequest request, HttpServletResponse response) throws IOException {
		PrintWriter out = response.getWriter();
		int userID = Integer.parseInt(request.getParameter("userID"));
		String headPath = request.getParameter("headPath");
		String userName = request.getParameter("userName");
		String nickName = request.getParameter("nickName");
		String sex = request.getParameter("sex");
		String phone = request.getParameter("phone");
		String password = request.getParameter("password");
		String status = request.getParameter("status");
		
		DbUtil dbUtil = new DbUtil();	
		Connection con = dbUtil.getCon();

		User user = new User(userID, userName, phone, nickName, password, headPath, sex, status);
		int addResult = 0;
		try {
			addResult = userDao.modifInformation(user, con);
		}catch (SQLException e){
			e.printStackTrace();
		}finally {
			dbUtil.closed(con);
		}
		if(addResult == 1) {
			response.sendRedirect("successUser.jsp");
		}else {
			response.sendRedirect("404.jsp");
		}
		
	}
	//修改群组信息
	private void ModifyGroupInformation(HttpServletRequest request, HttpServletResponse response) throws IOException{
		PrintWriter out = response.getWriter();
		int groupID = Integer.parseInt(request.getParameter("groupID"));
		int groupHostID = Integer.parseInt(request.getParameter("groupHostID"));
		String headPath = request.getParameter("headPath");
		String groupName = request.getParameter("groupName");
		String groupAnnouncement = request.getParameter("groupAnnouncement");
		String groupDescribe = request.getParameter("groupDescribe");
		String status = request.getParameter("status");
		
		DbUtil dbUtil = new DbUtil();	
		Connection con = dbUtil.getCon();
		Group group = new Group(groupID, groupHostID, groupAnnouncement, groupDescribe, status, groupName, headPath);
		int addResult = 0;
		try {
			addResult = groupDao.modifInformation(group, con);
		}catch (SQLException e){
			e.printStackTrace();
		}finally {
			dbUtil.closed(con);
		}
		if(addResult == 1) {
			response.sendRedirect("successGroup.jsp");
		}else {
			response.sendRedirect("404.jsp");
		}
	}
	
	//根据id查看个人信息
	private void UserInformation(HttpServletRequest request, HttpServletResponse response) throws IOException{
		User user=new User();
		int id =Integer.parseInt(request.getParameter("userid"));
		DbUtil dbutil = new DbUtil();
		Connection con = dbutil.getCon();
		try {
			user = userDao.information(id, con);
			HttpSession session = request.getSession();
			session.setAttribute("user", user);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			dbutil.closed(con);
		}
		if(user != null) {
			response.sendRedirect("userInfo.jsp");
		}else {
			response.sendRedirect("404.jsp");
		}
	}
	//根据id查看群组信息
		private void GroupInformation(HttpServletRequest request, HttpServletResponse response) throws IOException{
			Group group=new Group();
			int id =Integer.parseInt(request.getParameter("groupid"));
			DbUtil dbutil = new DbUtil();
			Connection con = dbutil.getCon(); 
			try {
				group = groupDao.information(id, con);
				HttpSession session = request.getSession();
				session.setAttribute("group", group);
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				dbutil.closed(con);
			}
			if(group != null) {
				response.sendRedirect("groupInfo.jsp");
			}else {
				response.sendRedirect("404.jsp");
			}
		}

	//修改用户状态为禁用
/*	private void modifyStatueToforbidden(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int id =Integer.parseInt(request.getParameter("id"));
		int result=0;
		DbUtil dbutil = new DbUtil();
		Connection con = dbutil.getCon();
		try {
			 result = userDao.modifyStatueToForbidden(con, id);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			dbutil.closed(con);
		}
		if(result == 1) {
			response.sendRedirect("membermanage.jsp");
		}
		System.out.println("backround的禁用");
		
	}*/
	//修改用户状态为正常
/*	private void modifyStatueTonormal(HttpServletRequest request, HttpServletResponse response) throws IOException {		
		int id =Integer.parseInt(request.getParameter("id"));
		int result=0;
		DbUtil dbutil = new DbUtil();
		Connection con = dbutil.getCon();
		try {
			 result = userDao.modifyStatueToNormal(con, id);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			dbutil.closed(con);
		}
		if(result == 1) {
			response.sendRedirect("membermanage.jsp");
		}
		System.out.println("backround的正常");
	}*/
	//获取历史公告
		private void getNotices(HttpServletRequest request, HttpServletResponse response) {
			JSONObject result = new JSONObject();
			ArrayList<SystemPush> pushList = new ArrayList<SystemPush>();
			DbUtil dbutil = new DbUtil();
			Connection con = dbutil.getCon();
			result.put("success", "success");
			try {
				pushList=systemPushDao.getnotices(request, con);
				HttpSession session = request.getSession();
				session.setAttribute("pushList", pushList);
				ResponseUtil.write(response, result);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				dbutil.closed(con);
			}
			
		}

	//获取用户列表
	private void getUsers(HttpServletRequest request, HttpServletResponse response) {
		JSONObject result = new JSONObject();
		ArrayList<User> userList = new ArrayList<User>();
		DbUtil dbutil = new DbUtil();
		Connection con = dbutil.getCon();
		result.put("success", "success");
		try {
			userList=userDao.getusers(request, con);
			HttpSession session = request.getSession();
			session.setAttribute("userList", userList);
			ResponseUtil.write(response, result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.closed(con);
		}
	}
}
