package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import com.model.Admin;
import com.model.User;

public class AdminLoginDao {
	//登陆 
		public Admin login(Connection con,String name,String password) throws SQLException{
			Admin admin= null;
			String sql = "select * from tbladmin where AdminName = '"+name+"' and password='"+password+"'";
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			ResultSet rSet = preparedStatement.executeQuery();
			while(rSet.next()) {
				admin = new Admin();
				admin.setAdminName(rSet.getString("AdminName"));
				admin.setPassword(rSet.getString("password"));
			}
			return admin;
		}

}
