package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import com.model.Group;
import com.model.SystemPush;
import com.model.User;

public class SystemPushDao {
	//保存公告
	public int addSystemPush(Connection con, SystemPush systemPush) throws SQLException {
		String sql1="insert into tblSystemPush(userID) select userID from tblUserInfor";
		PreparedStatement preparedStatement1 = con.prepareStatement(sql1);
		preparedStatement1.execute();
		preparedStatement1.close();
		String sql = "update tblsystempush set theme=?,content=?,date=?,status=? where theme is null";
		PreparedStatement preparedStatement = con.prepareStatement(sql);
		preparedStatement.setString(1, systemPush.getTheme());
		preparedStatement.setString(2, systemPush.getContent());
		preparedStatement.setString(3, systemPush.getData());
		preparedStatement.setString(4, systemPush.getStatus());
		return preparedStatement.executeUpdate();
		
	}
	
	//获取所有公告
	public ArrayList<SystemPush> getnotices(HttpServletRequest request,Connection con)throws SQLException{
		ArrayList<SystemPush> pushList = new ArrayList<>();
		String sql ="select * from tblsystempush group by date";
		
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			SystemPush systemPush = new SystemPush();
			systemPush.setPushID(rs.getInt(1));
			systemPush.setContent(rs.getString(3));
			systemPush.setData(rs.getString(4));
			systemPush.setTheme(rs.getString(2));
			pushList.add(systemPush);
		}
		return pushList;
	}
	
	//根据公告id返回单个公告对象
	public SystemPush information(int id,Connection con) throws SQLException{
		SystemPush systemPush = null;
		String sql ="SELECT * FROM tblsystempush WHERE pushID='"+id+"'";
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			systemPush = new SystemPush();
			systemPush.setPushID(rs.getInt(1));
			systemPush.setContent(rs.getString(3));
			systemPush.setTheme(rs.getString(2));
			systemPush.setData(rs.getString(4));
		}
		return systemPush;
	}

}
