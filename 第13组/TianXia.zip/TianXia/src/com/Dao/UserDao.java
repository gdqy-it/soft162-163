package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.User;

import sun.print.resources.serviceui;

public class UserDao {
	// 注册
	public int addUser(HttpServletRequest request, Connection con, User user) throws SQLException {
		String sql = "insert into tbluserinfor(userName,phone,nickName,password,headPath,sex,status) values(?,?,?,?,?,?,?)";
		PreparedStatement preparedStatement = con.prepareStatement(sql);
		preparedStatement.setString(1, user.getUserName());
		preparedStatement.setString(2, user.getPhone());
		preparedStatement.setString(3, user.getNickName());
		preparedStatement.setString(4, user.getPassword());
		preparedStatement.setString(5, user.getHeadPath());
		preparedStatement.setString(6, user.getSex());
		preparedStatement.setString(7, "0");
		return preparedStatement.executeUpdate();
	}

	// 登陆
	public User login(HttpServletRequest request, Connection con, String phone, String password) throws SQLException {
		User user = null;
		String sql = "select * from tbluserinfor where phone = '" + phone + "' and password='" + password + "'";
		PreparedStatement preparedStatement = con.prepareStatement(sql);
		ResultSet rSet = preparedStatement.executeQuery();
		while (rSet.next()) {
			user = new User();
			user.setUserName(rSet.getString("userName"));
			user.setPhone(rSet.getString("phone"));
			user.setNickName(rSet.getString("nickName"));
			user.setPassword(rSet.getString("password"));
			user.setHeadPath(rSet.getString("headPath"));
			user.setSex(rSet.getString("sex"));
			user.setStatus(rSet.getString("status"));
		}
		return user;
	}
	//修改用户信息
	public  int modifInformation(User user,Connection con) throws SQLException{
		String sql = "update tbluserinfor set userName=?,phone=?,nickName=?,password=?,sex=?,status=? where userID='"+user.getUserID()+"'";
		PreparedStatement preparedStatement = con.prepareStatement(sql);
		preparedStatement.setString(1, user.getUserName());
		preparedStatement.setString(2, user.getPhone());
		preparedStatement.setString(3, user.getNickName());
		preparedStatement.setString(4, user.getPassword());
		preparedStatement.setString(5, user.getSex());
		preparedStatement.setString(6, user.getStatus());
		return preparedStatement.executeUpdate();
	}
	// 修改密码
	public int modifypassword(HttpServletRequest request, Connection con, User currentuser, String newpassword)
			throws SQLException {
		String sql = "update tbluserinfor SET password='" + newpassword + "' WHERE userID='" + currentuser.getUserID()
				+ "'";
		PreparedStatement preparedStatement = con.prepareStatement(sql);
		return preparedStatement.executeUpdate();
	}


	//查询所有用户并返回list
	public ArrayList<User> getusers(HttpServletRequest request,Connection con)throws SQLException{
		ArrayList<User> userList = new ArrayList<>();
		String sql ="SELECT * FROM tbluserinfor";
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			User user = new User();
			user.setUserID(rs.getInt(1));
			user.setUserName(rs.getString(2));
			user.setPhone(rs.getString(3));
			user.setNickName(rs.getString(4));
			user.setPassword(rs.getString(5));
			user.setHeadPath(rs.getString(6));
			user.setSex(rs.getString(7));
			user.setStatus(rs.getString(8));
			userList.add(user);
		}
		return userList;
	}
	
	//获取用户信息
	public User information(int id,Connection con) throws SQLException{
		User user = null;
		String sql ="SELECT * FROM tbluserinfor WHERE userID='"+id+"'";
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			user = new User();
			user.setUserID(rs.getInt(1));
			user.setUserName(rs.getString(2));
			user.setPhone(rs.getString(3));
			user.setNickName(rs.getString(4));
			user.setPassword(rs.getString(5));
			user.setHeadPath(rs.getString(6));
			user.setSex(rs.getString(7));
			user.setStatus(rs.getString(8));
		}
		return user;
		
	}
	
	//获取用户共有多少页
	public int getPageCount(Connection con,int pageSize)throws SQLException {
		String sql="select count(*) from tbluserinfor";
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		rs.next();
		int rowCount = rs.getInt(1);
		return (rowCount-1)/pageSize+1;
	}
	
	//修改用户状态为正常
	public int modifyStatueToNormal(Connection con,int id) throws SQLException{
		String sql = "update tbluserinfor SET status='" + "正常" + "' WHERE userID='" + id+ "'";
		PreparedStatement preparedStatement = con.prepareStatement(sql);
		System.out.println("userDao的正常");
		return preparedStatement.executeUpdate();
		
	}
	//修改用户状态为禁用
	public int modifyStatueToForbidden(Connection con,int id) throws SQLException{
		String sql = "update tbluserinfor SET status='" + "禁用" + "' WHERE userID='" + id+ "'";
		PreparedStatement preparedStatement = con.prepareStatement(sql);
		System.out.println("userDao的禁用");
		return preparedStatement.executeUpdate();
	}
}

	


