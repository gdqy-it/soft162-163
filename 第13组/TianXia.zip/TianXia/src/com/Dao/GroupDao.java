package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import com.model.Group;
import com.model.User;

public class GroupDao {

	//修改群组信息
	public  int modifInformation(Group group,Connection con) throws SQLException{
		String sql = "update tblgroup set groupID=?,groupHostID=?,groupAnnouncement=?,groupDescribe=?,status=?,groupName=? where groupID='"+group.getGroupID()+"'";
		PreparedStatement preparedStatement = con.prepareStatement(sql);
		preparedStatement.setInt(1, group.getGroupID());
		preparedStatement.setInt(2, group.getGroupHostID());
		preparedStatement.setString(3, group.getGroupAnnouncement());
		preparedStatement.setString(4, group.getGroupDescribe());
		preparedStatement.setString(5, group.getStatus());
		preparedStatement.setString(6, group.getGroupName());
		return preparedStatement.executeUpdate();
	}
	//查询所有群组并返回list
		public ArrayList<Group> getgroups(HttpServletRequest request,Connection con)throws SQLException{
			ArrayList<Group> groupList = new ArrayList<Group>();
			String sql ="SELECT * FROM tblgroup";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Group group = new Group();
				group.setGroupID(rs.getInt(1));
				group.setGroupAnnouncement(rs.getString(6));
				group.setGroupDescribe(rs.getString(7));
				group.setGroupHostID(rs.getInt(2));
				group.setStatus(rs.getString(8));
				group.setGroupName(rs.getString(4));
				group.setHeadPath(rs.getString(5));
				groupList.add(group);
			}
			return groupList;
		}
		
		//根据群组id返回群组对象
		public Group information(int id,Connection con) throws SQLException{
			System.out.println(id);
			Group group = null;
			String sql ="SELECT * FROM tblgroup WHERE groupID='"+id+"'";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				group = new Group();
				group.setGroupID(rs.getInt(1));
				group.setGroupAnnouncement(rs.getString(6));
				group.setGroupDescribe(rs.getString(7));
				group.setGroupHostID(rs.getInt(2));
				group.setStatus(rs.getString(8));
				group.setGroupName(rs.getString(4));
				group.setHeadPath(rs.getString(5));
			}
			return group;
		}
	
}
