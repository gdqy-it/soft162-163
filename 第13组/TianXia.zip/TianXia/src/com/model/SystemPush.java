package com.model;

import java.io.Serializable;

public class SystemPush implements Serializable{

	private int pushID;
	private String theme;
	private String content;
	private String data;
	private String status;
	public SystemPush(int pushID, String theme, String content, String data,String status) {
		super();
		this.pushID = pushID;
		this.theme = theme;
		this.content = content;
		this.data = data;
		this.status=status;
	}
	public SystemPush() {}
	public int getPushID() {
		return pushID;
	}
	public void setPushID(int pushID) {
		this.pushID = pushID;
	}
	public String getTheme() {
		return theme;
	}
	public void setTheme(String theme) {
		this.theme = theme;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
}
