package com.model;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;

import com.Util.DbUtil;


public class User implements Serializable{
	private int userID;
	private String userName;
	private String phone;
	private String nickName;
	private String password;
	private String headPath;
	private String sex;
	private String status;
	public User(int userID,String userName, String phone, String nickName, String password, String headPath,
			String sex, String status) {
		super();
		this.userID=userID;
		this.userName = userName;
		this.phone = phone;
		this.nickName = nickName;
		this.password = password;
		this.headPath = headPath;
		this.sex = sex;
		this.status = status;
	}
	public User(String userName, String phone, String nickName, String password, String headPath,
			String sex, String status) {
		super();
		this.userName = userName;
		this.phone = phone;
		this.nickName = nickName;
		this.password = password;
		this.headPath = headPath;
		this.sex = sex;
		this.status = status;
	}
	public User() {}
	
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getHeadPath() {
		return headPath;
	}
	public void setHeadPath(String headPath) {
		this.headPath = headPath;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
		

}
