package com.model;

import java.io.Serializable;

public class Admin implements Serializable{
	private int AdminID;
	private String AdminName;
	private String password;
	public Admin(String adminName, String password) {
		super();
		AdminName = adminName;
		this.password = password;
	}
	
	public Admin() {}

	public int getAdminID() {
		return AdminID;
	}

	public String getAdminName() {
		return AdminName;
	}

	public void setAdminName(String adminName) {
		AdminName = adminName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
