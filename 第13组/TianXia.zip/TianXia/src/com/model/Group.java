package com.model;

import java.io.Serializable;

public class Group implements Serializable{
	private int groupID;
	private int groupHostID;
	private String groupAnnouncement;
	private String groupDescribe;
	private String status;
	private String groupName;
	private String headPath;

	
	public Group(int groupID, int groupHostID, String groupAnnouncement, String groupDescribe, String status,
			String groupName, String headPath) {
		super();
		this.groupID = groupID;
		this.groupHostID = groupHostID;
		this.groupAnnouncement = groupAnnouncement;
		this.groupDescribe = groupDescribe;
		this.status = status;
		this.groupName = groupName;
		this.headPath = headPath;
	}
	public Group() {}
	public int getGroupID() {
		return groupID;
	}
	public void setGroupID(int groupID) {
		this.groupID = groupID;
	}
	public int getGroupHostID() {
		return groupHostID;
	}
	public void setGroupHostID(int groupHostID) {
		this.groupHostID = groupHostID;
	}
	public String getGroupAnnouncement() {
		return groupAnnouncement;
	}
	public void setGroupAnnouncement(String groupAnnouncement) {
		this.groupAnnouncement = groupAnnouncement;
	}
	public String getGroupDescribe() {
		return groupDescribe;
	}
	public void setGroupDescribe(String groupDescribe) {
		this.groupDescribe = groupDescribe;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getHeadPath() {
		return headPath;
	}
	public void setHeadPath(String headPath) {
		this.headPath = headPath;
	}
}
