﻿/**
 * @author Jayin
 * 使用时调用doAjax方法，其中参数为一个数组，有以下数据
 * type：GET/POST（请求方式），url（路径），isAsync（是否异步），param（参数），
 * callBack（回调函数，必有一个参数），error404（404时处理函数），error500（500时处理函数）
 * 这样便可以执行ajax操作
 * demo:
		window.onload = function() {
            doAjax({
                type: "POST",
                url: "/Demo/JSONDemoServlet",
                isAsync: true,
                param: "username=我是参数",
                callBack: function(str) {
                    var s = eval("(" + str + ")");
                    console.log(s);
                }
            });
        }
 * 
 */

/**
 * 执行ajax操作
 * @param option 有如下属性
 * type：GET/POST（请求方式），url（路径），isAsync（是否异步），param（参数），
 * callBack（回调函数，必有一个参数），error404（404时处理函数），error500（500时处理函数）
 */
function doAjax(option) {
    // 处理默认值
    if (!option.type) 
        option.type = "GET";
    if (!option.url)
        console.log("请指定访问路径");
    if (typeof option.isAsync != "boolean")
        option.isAsync = true;
    
    // 创建
    var xmlHttp = createXMLHttpRequest();
    // 设置响应操作
    setState(xmlHttp, option.callBack, option.error404, option.error500);
    // 打开并发送
    open(xmlHttp, option.type, option.url, option.isAsync, option.param);
}

/**
 * 这份方法用来创建XMLHttpRequest对象
 */
function createXMLHttpRequest() {
    try {
        return new XMLHttpRequest(); // Google
    } catch (e) {
        try {
            return new ActiveXObject("Msxml1.XMLHttp");
        } catch (e) {
            try {
                return new ActiveXObject("Microsoft.XMLHttp");
            } catch (e) {
                console.log("XMLHttpRequest create error");
                throw e;
            }
        }
    }
}

/**
 * 打开与服务器的链接 xmlHttp.open(type, url, isAsycn); ，并发送参数 xmlHttp.send(param);
 * @param xmlHttp 
 * @param type 类型 ["GET", "POST"]
 * @param url 路径
 * @param isAsycn 是否异步
 * @param param 参数，如果type为GET则为空，为POST则可传入参数 key=value&key=value
 */
function open(xmlHttp, type, url, isAsync, param) {
    // 打开链接
    xmlHttp.open(type, url, isAsync);
    // 如果是POST则设置Content-type
    if (type == "POST")
        xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // 发送参数，如果参数不为空则发送指定参数
    xmlHttp.send(param ? param : null);
}

/**
 * 判断xmlHttp状态
 *    >0:刚创建，并未调用open()方法
 *    >1:请求开始，调用了open()方法，并为调用send()
 *    >2:调用了send()方法
 *    >3:服务器响应了，当不表示结束了
 *    >4:服务器响应结束 
 * @param xmlHttp
 * @param callBack
 * @param error404
 * @param error500
 */
function setState(xmlHttp, callBack, error404, error500) {
    xmlHttp.onreadystatechange = function () {
        // 得到xmlHttp状态对象
        var state = xmlHttp.readyState; 
        if (state == 4) {
            // 得到响应结果 200成功，404路径错误，500服务器错误
            var status = xmlHttp.status;
            if (200 == status)
                callBack(xmlHttp.responseText); // 得到文本结果
            else if (404 == status)
                if (error404 != null)
                    error404();
            else if (500 == status)
                if (error500 != null)
                    error500();
        }
    }
}