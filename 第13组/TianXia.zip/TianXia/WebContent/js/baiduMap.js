//百度地图API功能
function loadJScript() {
	var script = document.createElement("script");
	script.type = "text/javascript";
	script.src = "http://api.map.baidu.com/api?v=2.0&ak=V4xsnZO4G2r3GH1Vowfyt1LoCOCsHfXj&callback=init";
	document.body.appendChild(script);
}
function init() {
	var map = new BMap.Map("allmap"); // 创建Map实例
	var point = new BMap.Point(116.331398, 39.897445); // 创建点坐标
	map.centerAndZoom(point, 12); //初始化地图中心位置

	var top_left_control = new BMap.ScaleControl({
		anchor : BMAP_ANCHOR_TOP_LEFT
	});// 左上角，添加比例尺
	map.addControl(top_left_control); //左上角比例尺

	var navigationControl = new BMap.NavigationControl({
		// 靠左上角位置
		anchor : BMAP_ANCHOR_TOP_LEFT,
		// LARGE类型
		type : BMAP_NAVIGATION_CONTROL_LARGE,
		// 启用显示定位
		enableGeolocation : true
	});
	map.addControl(navigationControl);

	// 添加定位控件
	var geolocationControl = new BMap.GeolocationControl();
	geolocationControl.addEventListener("locationSuccess", function(e) {
		// 定位成功事件
		var address = '';
		address += e.addressComponent.province;
		address += e.addressComponent.city;
		address += e.addressComponent.district;
		address += e.addressComponent.street;
		address += e.addressComponent.streetNumber;
		alert("当前定位地址为：" + address);
	});
	geolocationControl.addEventListener("locationError", function(e) {
		// 定位失败事件
		alert(e.message);
	});
	map.addControl(geolocationControl);

	//右上角显示切换城市
	var size = new BMap.Size(10, 20);
	map.addControl(new BMap.CityListControl({
		anchor : BMAP_ANCHOR_TOP_RIGHT,
		offset : size,
		// 切换城市之间事件
		// onChangeBefore: function(){
		//    alert('before');
		// },
		// 切换城市之后事件
		onChangeAfter : function() {
			alert('after');
		}
	}));

	/* //获取覆盖物信息
	var marker = new BMap.Marker(point);  // 创建标注
	map.addOverlay(marker);              // 将标注添加到地图中
	marker.addEventListener("click",getAttr);
	function getAttr(){
		var p = marker.getPosition();       //获取marker的位置
		alert("marker的位置是" + p.lng + "," + p.lat);   
	} */

	//在地图上显示当前位置
	var geolocation = new BMap.Geolocation();
	geolocation.getCurrentPosition(function(r) {
		if (this.getStatus() == BMAP_STATUS_SUCCESS) {
			var mk = new BMap.Marker(r.point);
			map.addOverlay(mk);
			map.panTo(r.point);
			alert('您的位置：' + r.point.lng + ',' + r.point.lat);
			mk.addEventListener("click", attribute);
		} else {
			alert('failed' + this.getStatus());
		}
	}, {
		enableHighAccuracy : true
	})

	//让所有点在视野范围内
	map.setViewport(pointArray);
	//获取覆盖物位置
	function attribute(e) {
		var p = e.target;
		alert("您当前的位置是" + p.getPosition().lng + "," + p.getPosition().lat);
	}

	map.enableScrollWheelZoom(); //启用滚轮放大缩小，默认禁用
	map.enableContinuousZoom(); //启用地图惯性拖拽，默认禁用

}
window.onload = loadJScript; //异步加载地图