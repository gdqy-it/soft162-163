package cn.gdqy.aotw.service;

import cn.gdqy.aotw.common.ResultView;
import cn.gdqy.aotw.pojo.Apk;

public interface ApkService {
	ResultView getAllApkInfo();
	ResultView addApkInfo(Apk apk);
	ResultView deleteApkInfo(Integer id);
	ResultView getApkInfo(Integer id);
	ResultView updateApkInfo(Apk apk);
	ResultView checkIsLaterVersion(String version);
}
