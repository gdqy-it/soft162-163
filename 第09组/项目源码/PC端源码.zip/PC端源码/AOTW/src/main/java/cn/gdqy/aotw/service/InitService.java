package cn.gdqy.aotw.service;

public interface InitService {
	void init();
}
