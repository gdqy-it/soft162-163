package cn.gdqy.aotw.mapper;

import cn.gdqy.aotw.pojo.Apk;
import cn.gdqy.aotw.pojo.ApkExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ApkMapper {
    int countByExample(ApkExample example);

    int deleteByExample(ApkExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Apk record);

    int insertSelective(Apk record);

    List<Apk> selectByExample(ApkExample example);

    Apk selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Apk record, @Param("example") ApkExample example);

    int updateByExample(@Param("record") Apk record, @Param("example") ApkExample example);

    int updateByPrimaryKeySelective(Apk record);

    int updateByPrimaryKey(Apk record);
}