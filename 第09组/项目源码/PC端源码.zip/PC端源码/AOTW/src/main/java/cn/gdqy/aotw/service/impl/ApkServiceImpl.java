package cn.gdqy.aotw.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.gdqy.aotw.common.ResultView;
import cn.gdqy.aotw.mapper.ApkMapper;
import cn.gdqy.aotw.pojo.Apk;
import cn.gdqy.aotw.pojo.ApkExample;
import cn.gdqy.aotw.service.ApkService;

@Service
@Transactional
public class ApkServiceImpl implements ApkService {

	@Autowired
	private ApkMapper apkMapper;
	
	@Override
	public ResultView getAllApkInfo() {
		ResultView result = new ResultView();
		List<Apk> list = apkMapper.selectByExample(new ApkExample());
		result.putData("apks", list);
		return result;
	}

	@Override
	public ResultView updateApkInfo(Apk apk) {
		ResultView result = new ResultView();
		apkMapper.updateByPrimaryKey(apk);
		return result;
	}

	@Override
	public ResultView addApkInfo(Apk apk) {
		ResultView result = new ResultView();
		apk.setReleasetime(new Date());
		apkMapper.insert(apk);
		return result;
	}

	@Override
	public ResultView deleteApkInfo(Integer id) {
		ResultView result = new ResultView();
		apkMapper.deleteByPrimaryKey(id);
		return result;
	}

	@Override
	public ResultView getApkInfo(Integer id) {
		ResultView result = new ResultView();
		Apk apk = apkMapper.selectByPrimaryKey(id);
		result.putData("apk", apk);
		return result;
	}

	@Override
	public ResultView checkIsLaterVersion(String version) {
		ResultView result = new ResultView();
		ApkExample example = new ApkExample();
		example.setOrderByClause("id desc");
		List<Apk> apks = apkMapper.selectByExample(example);
		if (apks == null || apks.isEmpty()) {
			result.putData("isLaterVersion", true);
			return result;
		}
		Apk laterApk = apks.get(0);
		if (laterApk.getVersion().equals(version)) {
			result.putData("isLaterVersion", true);
			return result;
		}
		result.putData("isLaterVersion", false);
		result.putData("newVersion", laterApk.getVersion());
		result.putData("laterVersionUrl", laterApk.getFileurl());
		return result;
	}

}
