package cn.gdqy.aotw.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import cn.gdqy.aotw.common.ResultView;
import cn.gdqy.aotw.pojo.Apk;
import cn.gdqy.aotw.service.ApkService;
import cn.gdqy.aotw.utils.UploadFileHelper;

@Controller
@RequestMapping("/versionManage/")
public class VersionManageController {

	@Autowired
	private ApkService apkService;
	
	@RequestMapping("toVersionManage")
	public String toVersionManage(Model model) {
		ResultView result = apkService.getAllApkInfo();
		model.addAttribute("apks", result.getData("apks"));
		return "/pages/admin/versionManage";
	}
	
	@RequestMapping("deleteApkInfo")
	public String deleteApkInfo(Integer id) {
		apkService.deleteApkInfo(id);
		return "redirect:toVersionManage.do";
	}
	
	@RequestMapping("editApkInfo")
	public String editApkInfo(Integer id, Model model) {
		Apk apk = (Apk) apkService.getApkInfo(id).getData("apk");
		model.addAttribute("apk", apk);
		return "/pages/admin/editApkInfo";
	}
	
	@RequestMapping("saveApkInfo")
	public String saveApkInfo(Apk apk, MultipartFile file) {
		if (file != null) {
			String fileUrl = UploadFileHelper.saveApkFile(file);
			apk.setFileurl(fileUrl);
		}
		if (apk.getId() != null) {
			apkService.updateApkInfo(apk);			
		} else {
			apkService.addApkInfo(apk);
		}
		return "redirect:toVersionManage.do";
	}
	
	//是否为最新版本
	@ResponseBody
	@RequestMapping("isLaterVersion")
	public ResultView isLaterVersion(String version) {
		return apkService.checkIsLaterVersion(version);
	}
	
}
