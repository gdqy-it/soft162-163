package com.freely.data.database.DAO;

import com.freely.data.entities.Message;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import io.reactivex.Single;

@Dao
public interface MessageDAO {

    //通过用户id来获得用户收到的所有通知
    @Query("select * from message where receiver_id = :userId")
    Single<List<Message>> queryAllMessageByUserId(long userId);

    //通过message id来获得系统通知
    @Query("select * from message where message_id = :messageId")
    Single<Message> queryMessageByMessageId(long messageId);

    //获得最新一条消息
    @Query("select * from message " +
            "where receiver_id = :userId " +
            "order by message_send_time DESC " +
            "limit 1")
    Single<Message> queryNewMessage(long userId);

    @Insert
    void insertMessage(Message... messages);

    @Insert
    void insertMessage(List<Message> messages);

    @Update
    void updateMessage(Message... messages);

    @Delete
    void deleteMessage(Message... messages);


}
