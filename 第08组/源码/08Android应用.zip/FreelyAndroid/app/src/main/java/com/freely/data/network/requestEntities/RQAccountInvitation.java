package com.freely.data.network.requestEntities;

import com.freely.data.entities.Group;
import com.freely.data.entities.Message;
import com.freely.data.entities.User;
import com.google.gson.annotations.SerializedName;

/**
 * @author DaWan
 * @time 2018/12/4 12:10
 * @dscription
 * user_id:成员id,Long类型
 * group_id:群id,Long类型
 * group_admin:群主id，Long类型
 * message_id:消息id,Long类型
 * message_result:操作结果，Integer类型
 */
public class RQAccountInvitation implements BaseRQEntity {
	@SerializedName(User.user_id)
	private long userId;
	@SerializedName(Group.group_id)
	private long groupId;
	@SerializedName("group_admin")
	private long groupAdmin;
	@SerializedName(Message.message_id)
	private long messageId;
	@SerializedName(Message.message_result)
	private int messageResult;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getGroupId() {
		return groupId;
	}

	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

	public long getGroupAdmin() {
		return groupAdmin;
	}

	public void setGroupAdmin(long groupAdmin) {
		this.groupAdmin = groupAdmin;
	}

	public long getMessageId() {
		return messageId;
	}

	public void setMessageId(long messageId) {
		this.messageId = messageId;
	}

	public int getMessageResult() {
		return messageResult;
	}

	public void setMessageResult(int messageResult) {
		this.messageResult = messageResult;
	}
}
