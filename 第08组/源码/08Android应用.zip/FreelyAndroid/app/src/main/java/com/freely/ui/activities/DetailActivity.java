package com.freely.ui.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.freely.R;
import com.freely.R2;
import com.freely.component.activity.NavigationActivity;
import com.freely.data.database.DAO.UserDAO;
import com.freely.data.database.FreelyDatabase;
import com.freely.data.entities.User;
import com.freely.data.managerUtils.FreelySharedPreferences;
import com.freely.ui.util.ErrorUtil;
import com.freely.ui.viewModel.DetailViewModel;
import com.freely.ui.viewModel.HomeViewModel;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProviders;
import butterknife.BindView;
import butterknife.OnClick;
import io.reactivex.Single;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okio.ByteString;

public class DetailActivity extends NavigationActivity {
    @BindView(R2.id.user_head_icon)
    ImageView useHeadIcon;
    @BindView(R.id.user_nick_content)
    TextView UserNickContent;
    @BindView(R.id.user_phone_content)
    TextView UserPhotoContent;
    @BindView(R.id.user_email_content)
    TextView UserEmailContent;
    @BindView(R.id.exit_login)
    Button exitLogin;
    DetailViewModel detailViewModel;
    private static final String TAG = "DetailActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        initDetail();
    }

    @Override
    protected void onCreateToolbar(Toolbar toolbar, TextView title, ImageButton logo) {
        super.onCreateToolbar(toolbar, title, logo);
        toolbar.inflateMenu(R.menu.detail);
        toolbar.setOnMenuItemClickListener(item -> {
            boolean result = false;
            switch (item.getItemId()) {
                case R.id.edit:
                    DetailEditActivity.startActivity(this);
                    result = true;
                    break;
            }
            return result;
        });
    }

    public static void startActivity(@NonNull Context context){
        Intent intent = new Intent(context, DetailActivity.class);
        context.startActivity(intent);
    }
    public void initDetail(){
        detailViewModel = ViewModelProviders.of(this).get(DetailViewModel.class);

        detailViewModel.loadUser();

        detailViewModel.getUser().observe(this,user -> {

            UserNickContent.setText(user.getUserName());

            if (user.getUserPhone()!=null)
                UserPhotoContent.setText(user.getUserPhone());
            else
                UserPhotoContent.setText("暂未填写手机号");

            UserEmailContent.setText(user.getUserEmail());

            byte[] headIconByte = Base64.decode(user.getUserImage(), Base64.DEFAULT);
            Glide.with(this)
                    .load(headIconByte)
                    .apply(RequestOptions.circleCropTransform())
                    .into(useHeadIcon);
        });
    }
    @Override
     public void onResume() {
        super.onResume();
        Log.e(TAG, "onResume: " );
        initDetail();
    }

    @OnClick(R.id.exit_login)
    void exitLogin(){
        Log.e("button", "exitLogin: ");
        Single<User> userSingle=FreelyDatabase.getInstance().userDAO().queryUserByUserId(FreelySharedPreferences.getInstance().getUserId());

        Disposable disposable = userSingle.subscribeOn(Schedulers.io())
                .subscribe(user -> {
                    Log.e("disposable", "loadUser: "+user.toString() );
                    FreelyDatabase.getInstance().groupDAO();
                    FreelyDatabase.getInstance().userDAO().deleteUser(user);
                    detailViewModel.exitLogin();
                    MainActivity.startActivity(this);
                }, throwable -> {
                    ErrorUtil.dataReadErrorHint("读取用户信息错误", throwable);
                });
        register(disposable);
    }
}
