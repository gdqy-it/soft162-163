package com.freely.ui.viewModel;

import android.util.Log;

import com.freely.component.BaseViewModel;
import com.freely.data.database.FreelyDatabase;
import com.freely.data.entities.ChatRecord;
import com.freely.data.entities.Group;
import com.freely.data.entities.User;
import com.freely.data.network.FreelyClient;
import com.freely.data.repository.entities.GroupChatMessage;
import com.freely.data.rxBus.RxBus;
import com.freely.data.services.FreelyServiceKt;
import com.freely.ui.util.ErrorUtil;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.lifecycle.MutableLiveData;
import io.reactivex.Completable;
import io.reactivex.Single;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class GroupChatMessageViewModel extends BaseViewModel {
	private static final String TAG = "GroupChatMessageViewMod";
	private MutableLiveData<List<GroupChatMessage>> groupMessageList = new MutableLiveData<>();
	private MutableLiveData<GroupChatMessage> newMessage = new MutableLiveData<>();

    public GroupChatMessageViewModel() {
		messageOnListener();
    }

    public void loadGroupChatMessage(long groupId, long start,long number) {
        Single<List<GroupChatMessage>> single = FreelyDatabase.getInstance()
                .chatRecordDAO()
                .getFiftyGroupChatMessage(groupId, start, number);
        Disposable disposable = single.subscribeOn(Schedulers.io())
                .subscribe(groupChatMessages -> {
                    //成功获取群聊消息
					groupMessageList.postValue(groupChatMessages);
				}, ErrorUtil::errorHint);
        register(disposable);
    }

	public void sendMessage(long userId, long groupId, Date sendTime, String sendContent) {
		Disposable disposable = Completable.complete()
				.subscribeOn(Schedulers.io())
				.subscribe(() -> {
					Log.d(TAG, "sendMessage: "+Thread.currentThread().getName());
					Log.d(TAG, "accept: 数据库写入");
					ChatRecord record = new ChatRecord();
					record.setGroupId(groupId);
					record.setRecordContent(sendContent);
					record.setRecordSendTime(sendTime);
					record.setUserId(userId);
					FreelyDatabase.getInstance().chatRecordDAO().insertChatRecord(record);
					//发送到服务器
					Map<String, Object> sendMessage = new HashMap<>();
					sendMessage.put("data_type", 2);
					sendMessage.put(User.user_id, userId);
					sendMessage.put(Group.group_id, groupId);
					sendMessage.put("send_time", sendTime.getTime());
					sendMessage.put("record_content", sendContent);
					Log.d(TAG, "accept: 网络发送");
					FreelyClient.send(FreelyClient.getGson().toJson(sendMessage));
					Log.d(TAG, "accept: ----------消息发送完成----------");
				});
		register(disposable);
	}

	private void messageOnListener() {
		Disposable disposable = RxBus.Companion.getInstance()
				.toObservable(FreelyServiceKt.GROUP_CHAT_MESSAGE, GroupChatMessage.class)
				.subscribe(message -> {
					getNewMessage().postValue(message);
				});
		register(disposable);
	}

	public MutableLiveData<List<GroupChatMessage>> getGroupMessageList() {
        return groupMessageList;
    }

	public MutableLiveData<GroupChatMessage> getNewMessage() {
		return newMessage;
	}
}
