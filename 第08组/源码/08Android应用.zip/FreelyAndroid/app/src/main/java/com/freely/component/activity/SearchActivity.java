package com.freely.component.activity;

import android.widget.ImageButton;

import com.freely.R2;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * @author DaWan
 * @time 2018/11/27 14:11
 * @dscription
 */
public class SearchActivity extends FreelyBaseActivity {
	@BindView(R2.id.back)
	ImageButton back;
	@BindView(R2.id.search_input)
	SearchView searchView;

	@Override
	public void setContentView(int layoutResID) {
		super.setContentView(layoutResID);
		ButterKnife.bind(this);
		onCreateSearchBar(back, searchView);
	}

	protected void onCreateSearchBar(@NonNull ImageButton back, @NonNull SearchView searchView) {
		back.setOnClickListener(v -> finish());
		searchView.onActionViewExpanded();
		searchView.setSubmitButtonEnabled(true);
	}
}
