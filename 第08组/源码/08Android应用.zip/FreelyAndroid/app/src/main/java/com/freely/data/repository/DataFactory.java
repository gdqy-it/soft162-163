package com.freely.data.repository;

public class DataFactory {
}
