package com.freely.ui.viewModel;

import android.location.Location;
import android.util.Log;

import com.baidu.location.BDLocation;
import com.freely.component.BaseViewModel;
import com.freely.data.entities.User;
import com.freely.data.managerUtils.FreelySharedPreferences;
import com.freely.data.network.FreelyClient;
import com.freely.data.network.requestEntities.RQGroupInfomation;
import com.freely.data.network.requestEntities.RQQueryMemberInformation;
import com.freely.data.network.requestEntities.RQUserLocation;
import com.freely.data.network.responseEntities.RSResult;
import com.freely.data.network.responseEntities.RSUserLocation;
import com.freely.ui.util.ErrorUtil;

import java.util.List;

import androidx.lifecycle.MutableLiveData;
import io.reactivex.Single;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class GroupChatMapViewModel extends BaseViewModel {

    private static final String TAG ="GroupChatMapViewModel" ;
    private MutableLiveData<List<RSUserLocation>> rsUserLocationMutableLiveData;
    private MutableLiveData<User> rsUserInfomationMutableLiveData;

    public GroupChatMapViewModel() {
        rsUserLocationMutableLiveData = new MutableLiveData<>();
        rsUserInfomationMutableLiveData = new MutableLiveData<>();
    }


    public void applyForUserLocation(Location location){
        RQUserLocation rqUserLocation = new RQUserLocation(FreelySharedPreferences.getInstance().getUserId(),location.getLatitude(),location.getLongitude());
        FreelyClient.getWebSocket().send(FreelyClient.getGson().toJson(rqUserLocation));
    }


    public void applyForUserLocation(BDLocation location){
        BDLocation l = new BDLocation();
        RQUserLocation rqUserLocation = new RQUserLocation(FreelySharedPreferences.getInstance().getUserId(),location.getLatitude(),location.getLongitude());
        FreelyClient.send(FreelyClient.getGson().toJson(rqUserLocation));
    }

    public void loadMemberInfo(long userId,long groupId){
        RQQueryMemberInformation memberInformation = new RQQueryMemberInformation();
        memberInformation.setUserId(userId);
        memberInformation.setGroupId(groupId);
        Single<RSResult<User,String>>  rsResultSingle = FreelyClient
                .getFreelyService()
                .queryMemberInformation(memberInformation);

        Disposable disposable = rsResultSingle
                .subscribeOn(Schedulers.io())
                .subscribe(rsResult -> {
                    if(null!=rsResult.getSuccess());{
                        Log.e(TAG, "setPhone: "+"aaa" );
                    }
                    rsUserInfomationMutableLiveData.postValue(rsResult.getSuccess());
                    Log.e(TAG, "loadMemberInfo: "+rsResult.getSuccess().toString() );

                }, throwable -> {
                    ErrorUtil.dataReadErrorHint("读取群组信息错误", throwable);
                });
            register(disposable);
    }

    public void loadMemberLocation(long groupId){
        Single<RSResult<List<RSUserLocation>,String>> rsResultSingle = FreelyClient
                    .getFreelyService()
                    .getMemberLocation(new RQGroupInfomation(groupId));
        Disposable disposable = rsResultSingle
                .subscribeOn(Schedulers.io())
                .subscribe(rsResult -> {
                    if(null!=rsResult.getSuccess());{
                        Log.e(TAG, "setPhone: "+"无数据" );
                    }
                    rsUserLocationMutableLiveData.postValue(rsResult.getSuccess());

                    Log.e(TAG, "getMemberLocation: "+rsResult.toString());

                }, throwable -> {
                    ErrorUtil.dataReadErrorHint("读取群组信息错误", throwable);
                });
        register(disposable);
    }

    public MutableLiveData<List<RSUserLocation>> getUserLocation() {
        return rsUserLocationMutableLiveData;
    }

    public MutableLiveData<User> getUserInfo() {
        return rsUserInfomationMutableLiveData;
    }
}
