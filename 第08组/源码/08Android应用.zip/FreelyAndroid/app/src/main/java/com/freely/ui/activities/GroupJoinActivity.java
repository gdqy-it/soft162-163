package com.freely.ui.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.freely.R;
import com.freely.R2;
import com.freely.component.activity.SearchActivity;
import com.freely.data.network.responseEntities.RSGroup;
import com.freely.ui.adapter.recyclerView.SingleViewAdapter;
import com.freely.ui.viewModel.GroupJoinViewModel;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import okio.ByteString;

public class GroupJoinActivity extends SearchActivity {
	private static final String TAG = "GroupJoinActivity";
	@BindView(R2.id.recycler_view)
	RecyclerView recyclerView;

	private SingleViewAdapter<RSGroup> adapter;
	private GroupJoinViewModel viewModel;
	private String searchText;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_group_join);
		init();
	}

	@Override
	protected void onCreateSearchBar(@NonNull ImageButton back, @NonNull SearchView searchView) {
		super.onCreateSearchBar(back, searchView);
		searchView.setQueryHint("请输入群账号...");
		searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
			@Override
			public boolean onQueryTextSubmit(String query) {
				if (query.equals(searchText)) {
					return false;
				}
				searchText = query;
				viewModel.loadGroupList(query);
				return true;
			}

			@Override
			public boolean onQueryTextChange(String newText) {
				return false;
			}
		});
	}

	private void init() {
		adapter = new SingleViewAdapter<>(
				null,
				R.layout.item_search_joined
		).onBindView((holder, position) -> {
			ImageView groupHeadIcon = holder.getView(R.id.head_icon);
			TextView groupName = holder.getView(R.id.group_name);

			RSGroup group = viewModel.getGroupList().getValue().get(position);
			groupName.setText(group.getGroup_name());
			Glide.with(this)
					.load(ByteString.decodeBase64(group.getGroup_image()).toByteArray())
					.apply(RequestOptions.circleCropTransform())
					.into(groupHeadIcon);

			Log.d(TAG, "init: 设置群列表item监听");
			if (!holder.itemView.hasOnClickListeners()) {
				holder.itemView.setOnClickListener(view -> {
					GroupChatInformationActivity.startActivity(this,group.getGroup_id(),true);
				});
			}
		});
		recyclerView.setAdapter(adapter);
		recyclerView.setLayoutManager(new LinearLayoutManager(this));

		//view model 初始化
		viewModel = ViewModelProviders.of(this).get(GroupJoinViewModel.class);
		viewModel.getGroupList().observe(this,groups -> {
			adapter.setDataList(groups);
			adapter.notifyDataSetChanged();
		});
	}


	public static void startActivity(Context context) {
		Intent intent = new Intent(context, GroupJoinActivity.class);
		context.startActivity(intent);
	}
}
