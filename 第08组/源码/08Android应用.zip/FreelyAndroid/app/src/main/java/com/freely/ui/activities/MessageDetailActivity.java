package com.freely.ui.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.freely.R;
import com.freely.R2;
import com.freely.component.activity.NavigationActivity;
import com.freely.data.entities.Group;
import com.freely.data.entities.Message;
import com.freely.data.network.requestEntities.RQAccountInvitation;
import com.freely.data.network.requestEntities.RQAccountJoinGround;
import com.freely.ui.viewModel.MessageDetailViewModel;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProviders;
import butterknife.BindView;
import butterknife.OnClick;

public class MessageDetailActivity extends NavigationActivity {
	private static final String TAG = "MessageDetailActivity";

	@BindView(R2.id.message_content)
	TextView messageContent;
	@BindView(R2.id.account)
	Button account;

	private long messageId;
	private MessageDetailViewModel viewModel;

	public static void startActivity(@NonNull Context context, long messageId) {
		Intent intent = new Intent(context, MessageDetailActivity.class);
		intent.putExtra(Message.message_id, messageId);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_message_detail);
		messageId = getIntent().getLongExtra(Message.message_id, -1);

		viewModel = ViewModelProviders.of(this).get(MessageDetailViewModel.class);
		viewModel.getMessage().observe(this, message ->{
			messageContent.setText(message.getMessageContent());
			int messageType = message.getMessageType();
			if (messageType == 0) {
				account.setVisibility(View.GONE);
				return;
			}
			String showResult=null;
			boolean actionResult = false;
			switch (message.getResult()) {
				case Message.RESULT_NO_OPERATION:
					return;
				case Message.RESULT_ACCOUNT:
					showResult = "已接受";
					actionResult = true;
					break;
				case Message.RESULT_REFUSE:
					showResult = "已拒绝";
					actionResult = true;
					break;
			}
			account.setText(showResult);
			account.setClickable(false);
			account.setFocusable(false);
		});
		viewModel.getGroup().observe(this,group -> {
			Intent intent = new Intent();
			intent.putExtra(Group.group_id, group.getGroupId());
			setResult(RESULT_OK, intent);
		});
		viewModel.loadMessage(messageId);
	}

	@OnClick(R2.id.account)
	void accountOnClick(View view) {
		Message message = viewModel.getMessage().getValue();
		int result = message.getResult();
		if (result == Message.RESULT_ACCOUNT || result == Message.RESULT_REFUSE) {
			account.setClickable(false);
			return;
		}
		if (message.getMessageType() == 1) {
			//接受入群邀请
			RQAccountJoinGround joinGround = new RQAccountJoinGround();
			joinGround.setGroundId(message.getGroupId());
			joinGround.setMessageId(message.getMessageId());
			joinGround.setMessageResult(Message.RESULT_ACCOUNT);
			joinGround.setUserId(message.getReceiverId());
			viewModel.accountInvite(joinGround);
			return;
		}
		if (message.getMessageType() == 2) {
			//接受入群申请
			RQAccountInvitation invitation = new RQAccountInvitation();
			invitation.setGroupId(message.getGroupId());
			invitation.setUserId(message.getSenderId());
			invitation.setMessageId(message.getMessageId());
			invitation.setGroupAdmin(message.getReceiverId());
			invitation.setMessageResult(Message.RESULT_ACCOUNT);
			viewModel.accountApply(invitation);
		}
	}

}
