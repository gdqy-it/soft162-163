package com.freely.data.network.webSocket;

import okhttp3.WebSocket;

/**
 * @author DaWan
 * @time 2018/11/29 0:13
 * @dscription
 */
@FunctionalInterface
public interface ClosingListener {
	boolean onClosing(WebSocket webSocket, int code, String reason);
}
