package com.freely.data.entities;

import java.util.Date;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

/*
        字段	                类型	        键	            是否为空    	备注
        message_id  	    bigint	    primary key 	not null	消息通知id
        receiver_id 	    bigint	    foreign key 	not null	接收人id
        sender_id	        bigint	    foreign key 	not null	发送人id
        message_type	    int		                    not null	消息类型
        message_title	    varchar(20)		            not null	消息标题
        message_content 	varchar(50)		            not null	消息内容
        message_send_time	timestamp		            not null	发送时间
*/
@Entity(tableName = "message")
public class Message {
    @Ignore
    public static final String message_id = "message_id";
    @Ignore
    public static final String receiver_id = "receiver_id";
    @Ignore
    public static final String sender_id = "sender_id";
    @Ignore
    public static final String message_result = "message_result";
    @Ignore
    public static final String message_type = "message_type";
    @Ignore
    public static final String message_title = "message_title";
    @Ignore
    public static final String message_content = "message_content";
    @Ignore
    public static final String message_send_time = "message_send_time";
    @Ignore
    public static final String message_read = "message_read";
    @Ignore
    public static final int RESULT_NO_OPERATION = 0;
    @Ignore
    public static final int RESULT_ACCOUNT=1;
    @Ignore
    public static final int RESULT_REFUSE = 2;

    @PrimaryKey
    @ColumnInfo(name = Message.message_id)
    private long messageId;//消息通知id

    @ColumnInfo(name = Message.receiver_id)
    private long receiverId;//接收人id

    @ColumnInfo(name = Message.sender_id)
    private long senderId;//发送人id

    @ColumnInfo(name = Message.message_type)
    private int messageType;//消息类型

    @ColumnInfo(name = Message.message_title)
    private String messageTitle;//消息标题

    @ColumnInfo(name = Message.message_content)
    private String messageContent;//消息内容

    @ColumnInfo(name = Message.message_send_time)
    private Date messageSendTime;//发送时间

    @ColumnInfo(name = "group_id")
    private long groupId;

    @ColumnInfo(name = Message.message_read)
    private boolean read;

    @ColumnInfo(name = "message_result")
    private int result;

    public long getMessageId() {
        return messageId;
    }

    public void setMessageId(long messageId) {
        this.messageId = messageId;
    }

    public long getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(long receiverId) {
        this.receiverId = receiverId;
    }

    public long getSenderId() {
        return senderId;
    }

    public void setSenderId(long senderId) {
        this.senderId = senderId;
    }

    public int getMessageType() {
        return messageType;
    }

    public void setMessageType(int messageType) {
        this.messageType = messageType;
    }

    public String getMessageTitle() {
        return messageTitle;
    }

    public void setMessageTitle(String messageTitle) {
        this.messageTitle = messageTitle;
    }

    public String getMessageContent() {
        return messageContent;
    }

    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }

    public Date getMessageSendTime() {
        return messageSendTime;
    }

    public void setMessageSendTime(Date messageSendTime) {
        this.messageSendTime = messageSendTime;
    }

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }

    public boolean isRead() {
        return read;
    }

    public void setRead(boolean read) {
        this.read = read;
    }

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }
}
