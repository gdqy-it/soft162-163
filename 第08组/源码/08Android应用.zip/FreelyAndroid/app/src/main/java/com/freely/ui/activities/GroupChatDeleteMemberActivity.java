package com.freely.ui.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import okio.ByteString;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.freely.R;
import com.freely.component.activity.NavigationActivity;
import com.freely.data.DateTest;
import com.freely.data.entities.Group;
import com.freely.data.managerUtils.FreelySharedPreferences;
import com.freely.data.network.FreelyClient;
import com.freely.data.network.requestEntities.RQDeleteMember;
import com.freely.data.network.responseEntities.RSGroupInfomation;
import com.freely.data.network.responseEntities.RSUserLocation;
import com.freely.ui.adapter.recyclerView.SingleViewAdapter;
import com.freely.ui.viewModel.GroupChatDeleteMemberViewModel;
import com.freely.ui.viewModel.GroupChatInfomationViewModel;
import com.freely.ui.viewModel.MessageDetailViewModel;

import java.security.Provider;
import java.util.List;

public class GroupChatDeleteMemberActivity extends NavigationActivity {
    private static final String TAG = "GroupChatDeleteMemberAc";
    @BindView(R.id.recycler_view)
    RecyclerView recyclerView;
    private GroupChatDeleteMemberViewModel groupChatDeleteMemberViewModel;
    private SingleViewAdapter<RSGroupInfomation.UsersBean> adapter;
    private long groupId;
    private List<RSGroupInfomation.UsersBean> usersBeans;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_chat_delete_group_member);
       // recyclerView=findViewById(R.id.recycler_view);
        groupId=getIntent().getLongExtra(Group.group_id,0);
        init();
    }

    @SuppressLint("WrongConstant")
    public void init(){
        groupChatDeleteMemberViewModel =ViewModelProviders.of(this).get(GroupChatDeleteMemberViewModel.class);
        GroupChatInfomationViewModel groupChatInformationViewModel  =ViewModelProviders.of(this).get(GroupChatInfomationViewModel.class);

        groupChatInformationViewModel.getGroupInfo(groupId);

        groupChatInformationViewModel.getGroup().observe(this,
                group -> {
                    usersBeans=group.getUsers();
                    adapter.setDataList(group.getUsers());
                    adapter.notifyDataSetChanged();
                });


        LinearLayoutManager ms = new LinearLayoutManager(this);
        ms.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(ms);

        adapter = new SingleViewAdapter<>(
                null,
                R.layout.delete_group_member_recycler
        ).onBindView((holder, position) -> {
            long id = usersBeans.get(position).getUser_id();
            ImageView headIcon = holder.getView(R.id.head_icon);
            Log.e(TAG, "init: ");
            Glide.with(this)
                    .load(ByteString.decodeBase64(usersBeans.get(position).getUser_image()).toByteArray())
                    .apply(RequestOptions.circleCropTransform())
                    .into(headIcon);
            TextView tv = holder.getView(R.id.tv_user_nick);
            tv.setText(usersBeans.get(position).getUser_name());
            Button button = holder.getView(R.id.action_button);
            if (id==FreelySharedPreferences.getInstance().getUserId()){
                button.setVisibility(View.GONE);
            }else {
                button.setOnClickListener(view -> {
                    deleteMember(groupId, id);
                    init();
                });
            }
        });


       // adapter.setDataList(DateTest.getLiss());
      //  adapter.notifyDataSetChanged();
        recyclerView.setAdapter(adapter);
    }
    public static void startActivity(Context context,long groupId){
        Intent intent = new Intent(context, GroupChatDeleteMemberActivity.class);
        intent.putExtra(Group.group_id,groupId);
        context.startActivity(intent);
    }

    public void deleteMember(long groupId,long memberId){
        RQDeleteMember rqDeleteMember = new RQDeleteMember(groupId,memberId,FreelySharedPreferences.getInstance().getUserId());
        groupChatDeleteMemberViewModel.deleteMember(rqDeleteMember);

    }
}
