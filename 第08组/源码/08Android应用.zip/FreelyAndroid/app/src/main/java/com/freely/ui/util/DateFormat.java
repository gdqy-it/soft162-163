package com.freely.ui.util;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author DaWan
 * @time 2018/12/2 13:10
 * @dscription
 */
public final class DateFormat {
	public static final String TIME_FORMAT = "HH:mm";
	private static SimpleDateFormat dateFormat;
	static {
		dateFormat = new SimpleDateFormat();
	}
	private DateFormat() {

	}

	public static String format(String format, Date date) {
		dateFormat.applyPattern(format);
		return dateFormat.format(date);
	}
}
