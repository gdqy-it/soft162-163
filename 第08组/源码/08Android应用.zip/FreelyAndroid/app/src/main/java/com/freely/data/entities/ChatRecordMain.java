package com.freely.data.entities;

import java.util.Date;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;


/*
        字段              	类型	            键           	是否为空    	备注
        chatRecordMainId    bigint              primary key         not null        记录主要id
        groupId             bigint              foreign key         not null        群id
        messageContent      varchar(200)        foreign key         not null        消息内容
        userId              bigint              foreign key         not null        发送人ID
        userImage           varchar(50)         foreign key         not null        发送人头像
        recordSendTime      Timestamp           foreign key         not null        发送时间
        userName            varchar(16)         foreign key         not null        发送人姓名
*/


@Entity(tableName = "chat_record_main")
public class ChatRecordMain {
    @Ignore
    public static final String chat_record_main_id="chat_record_main_id";

    @Ignore
    public static final String chat_record_user_id="chat_record_user_id";

    @PrimaryKey
    @ColumnInfo(name=ChatRecordMain.chat_record_main_id)
    @NonNull
    private long chatRecordMainId;

    @NonNull
    @ColumnInfo(name=Group.group_id)
    private long groupId;//群id

    @NonNull
    @ColumnInfo(name=Message.message_content)
    private String messageContent;//消息内容

    @NonNull
    @ColumnInfo(name=User.user_id)
    private long userId;//发送人ID

    @NonNull
    @ColumnInfo(name = User.user_image)
    private String userImage;//发送人头像

    @NonNull
    @ColumnInfo(name = ChatRecord.record_send_time)
    private Date recordSendTime;//发送时间

    @NonNull
    @ColumnInfo(name=User.user_name)
    private String userName;//发送人姓名

    public long getChatRecordMainId() {
        return chatRecordMainId;
    }

    public void setChatRecordMainId(long chatRecordMainId) {
        this.chatRecordMainId = chatRecordMainId;
    }

    @NonNull
    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(@NonNull long groupId) {
        this.groupId = groupId;
    }

    @NonNull
    public String getMessageContent() {
        return messageContent;
    }

    public void setMessageContent(@NonNull String messageContent) {
        this.messageContent = messageContent;
    }

    @NonNull
    public long getUserId() {
        return userId;
    }

    public void setUserId(@NonNull long userId) {
        this.userId = userId;
    }

    @NonNull
    public String getUserImage() {
        return userImage;
    }

    public void setUserImage(@NonNull String userImage) {
        this.userImage = userImage;
    }

    @NonNull
    public Date getRecordSendTime() {
        return recordSendTime;
    }

    public void setRecordSendTime(@NonNull Date recordSendTime) {
        this.recordSendTime = recordSendTime;
    }

    @NonNull
    public String getUserName() {
        return userName;
    }

    public void setUserName(@NonNull String userName) {
        this.userName = userName;
    }
}
