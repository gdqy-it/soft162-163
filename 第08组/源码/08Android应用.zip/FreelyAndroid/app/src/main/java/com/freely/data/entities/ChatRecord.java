package com.freely.data.entities;

import java.util.Date;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

/*
        字段	                类型	            键	            是否为空    	备注
        record_id       	bigint        	primary key	    not null	记录id
        group_id        	bigint      	foreign key 	not null	群id
        user_id         	bigint      	foreign key 	not null	发送人id
        record_content  	varchar(50)	                	not null	发送内容
        record_send_time	timestamp		                not null	发送时间
*/

@Entity(tableName = "chat_record")
public class ChatRecord {
    @Ignore
    public static final String record_id = "record_id";
    @Ignore
    public static final String record_content = "record_content";
    @Ignore
    public static final String record_send_time = "record_send_time";

    @NonNull
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = ChatRecord.record_id)
    private long recordId;//记录id

    //TODO 设外键 更新时间
    @NonNull
    @ColumnInfo(name = Group.group_id)
    private long groupId;//群id

    @NonNull
    @ColumnInfo(name = User.user_id)
    private long userId;//发送人id

    @NonNull
    @ColumnInfo(name = ChatRecord.record_content)
    private String recordContent;//发送内容

    @NonNull
    @ColumnInfo(name = ChatRecord.record_send_time)
    private Date recordSendTime;//发送时间

    @NonNull
    public long getRecordId() {
        return recordId;
    }

    public void setRecordId(@NonNull long recordId) {
        this.recordId = recordId;
    }

    @NonNull
    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(@NonNull long groupId) {
        this.groupId = groupId;
    }

    @NonNull
    public long getUserId() {
        return userId;
    }

    public void setUserId(@NonNull long userId) {
        this.userId = userId;
    }

    @NonNull
    public String getRecordContent() {
        return recordContent;
    }

    public void setRecordContent(@NonNull String recordContent) {
        this.recordContent = recordContent;
    }

    @NonNull
    public Date getRecordSendTime() {
        return recordSendTime;
    }

    public void setRecordSendTime(@NonNull Date recordSendTime) {
        this.recordSendTime = recordSendTime;
    }
}
