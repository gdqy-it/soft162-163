package com.freely.data.regexUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginValidate {
    public static boolean validateUserAccount(String userAccount){
        int length=userAccount.length();
        if(length>7&&length<17){
            return true;
        }else {
            return false;
        }
    }
    public static boolean validatePassword(String password){
        int length=password.length();
        if(length>8&&length<16){
            return true;
        }else {
            return false;
        }
    }

    public static boolean validateIdentifyingCode(String dentifyingCode){
        int length=dentifyingCode.length();
        if(length==4){
            return true;
        }else {
            return false;
        }
    }

    public static boolean validateEmail(String email){

        int length=email.length();
        //if(length<4)
        String strPattern = "^[a-zA-Z][\\w\\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\\w\\.-]*[a-zA-Z0-9]\\.[a-zA-Z][a-zA-Z\\.]*[a-zA-Z]$";
        Pattern p = Pattern.compile(strPattern);
        Matcher m = p.matcher(email.trim());
        return m.matches();

    }

}
