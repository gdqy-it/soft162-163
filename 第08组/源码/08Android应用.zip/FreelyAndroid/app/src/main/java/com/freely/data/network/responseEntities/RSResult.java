package com.freely.data.network.responseEntities;

public class RSResult<T,V> {
    private boolean result;

    private T success;

    private V failure;

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public T getSuccess() {
        return success;
    }

    public void setSuccess(T success) {
        this.success = success;
    }

    public V getFailure() {
        return failure;
    }

    public void setFailure(V failure) {
        this.failure = failure;
    }

    @Override
    public String toString() {
        return "RSResult{" +
                "result=" + result +
                ", success=" + success +
                ", failure=" + failure +
                '}';
    }

}
