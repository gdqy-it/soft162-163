package com.freely.data


/**
 * @author DaWan
 * @time 2018/12/13 8:59
 * @description
 */
class Node<V>(var parentNode: Node<*>? = null) {
    var value: V? = null
    var childNode = mutableListOf<Node<*>>()
}
