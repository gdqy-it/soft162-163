package com.freely.ui.viewModel;


import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.freely.component.BaseViewModel;
import com.freely.component.activity.FreelyApplication;
import com.freely.component.activity.NavigationActivity;
import com.freely.data.database.FreelyDatabase;
import com.freely.data.entities.User;
import com.freely.data.managerUtils.FreelySharedPreferences;
import com.freely.data.network.FreelyClient;

import com.freely.data.network.requestEntities.RQUserId;
import com.freely.data.network.responseEntities.RSResult;
import com.freely.ui.activities.MainActivity;
import com.freely.ui.util.ErrorUtil;

import androidx.lifecycle.MutableLiveData;
import io.reactivex.Single;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class DetailViewModel extends BaseViewModel {
    private static final String TAG = "DetailViewModel";
    private MutableLiveData<User> user;
    private Context context;
    public DetailViewModel(){
        user=new MutableLiveData<User>();
    }

    public DetailViewModel(Context context){

        user=new MutableLiveData<User>();
        this.context = context;
    }

    public void loadUser(){

        Single<User> userSingle=FreelyDatabase.getInstance().userDAO()
                .queryUserByUserId(FreelySharedPreferences.getInstance().getUserId());

        Disposable disposable = userSingle.subscribeOn(Schedulers.io())
                .subscribe(user -> {
                    Log.e("disposable", "loadUser: "+user.getUserName() );
                    this.user.postValue(user);
                }, throwable -> {
                    ErrorUtil.dataReadErrorHint("读取用户信息错误", throwable);
                });
        this.register(disposable);
    }

    public void updateDetail(User updateUser) {

        Single<RSResult<String, String>> resultSingle = FreelyClient
                .getFreelyService()
                .updateUserInformation(updateUser);

        Disposable disposable = resultSingle
                .subscribeOn(Schedulers.io())
                .subscribe(
                        userStringRSResult -> {
                            //应答成功
                            //服务器处理失败
                            if (!userStringRSResult.isResult()) {
                                Log.e("aaa", "updateDetail: "+"failed");
                                return;
                            }
                            //服务器处理成功
                            userStringRSResult.getSuccess();
                            User localUser = user.getValue();
                            Log.e(TAG, "updateDetail: "+localUser.getUserImage() );
                            if(updateUser.getUserName() != null){
                                localUser.setUserName(updateUser.getUserName());
                            }
                            if(updateUser.getUserPhone() != null){
                                localUser.setUserPhone(updateUser.getUserPhone());
                            }
                            if(updateUser.getUserEmail() != null){
                                localUser.setUserEmail(updateUser.getUserEmail());
                            }
                            if(updateUser.getUserImage() != null){
                                localUser.setUserImage(updateUser.getUserImage());
                            }

                            FreelyDatabase.getInstance().userDAO().updateUserById(localUser.getUserId()
                                    ,localUser.getUserImage()
                                    ,localUser.getUserName()
                                    ,localUser.getUserEmail()
                                    ,localUser.getUserPhone());
                           ((NavigationActivity)context).finish();
                            this.user.postValue(localUser);
                        }, throwable -> {
                            //应答失败
                            ErrorUtil.errorHint(throwable);
                        }
                );

        register(disposable);
    }


    public MutableLiveData<User> getUser(){
        return this.user;
    }


    public void exitLogin(){
        RQUserId rqUserId = new RQUserId(FreelySharedPreferences.getInstance().getUserId());
        Single<RSResult<String,String>> a = FreelyClient.getFreelyService().exitLogin(rqUserId);

        Disposable disposable = a.subscribeOn(Schedulers.io())
                .subscribe(stringRSResult -> {
                    Log.e(TAG, "exitLogin: "+"退出成功" );
                    FreelyDatabase.getInstance().clearAllTables();
                    FreelySharedPreferences.getInstance().setUserId(FreelySharedPreferences.RESULT_NULL);
                        },throwable -> {

                        }

                );
        register(disposable);
    }
}
