package com.freely.component.repository;

public abstract class BaseRepository<T> implements DataGet<T> {

}
