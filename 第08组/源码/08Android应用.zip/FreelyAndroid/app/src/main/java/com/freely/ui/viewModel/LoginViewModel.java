package com.freely.ui.viewModel;

import android.util.Base64;
import android.util.Log;

import com.freely.component.BaseViewModel;
import com.freely.data.database.FreelyDatabase;
import com.freely.data.entities.User;
import com.freely.data.managerUtils.FreelySharedPreferences;
import com.freely.data.network.FreelyClient;
import com.freely.data.network.ServerException;
import com.freely.data.network.requestEntities.RQDeviceCode;
import com.freely.data.network.requestEntities.RQUserLogin;
import com.freely.data.network.requestEntities.RQVerificationCheck;
import com.freely.data.network.responseEntities.RSResult;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import io.reactivex.Single;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class LoginViewModel extends BaseViewModel {
    private static final String TAG = "LoginViewModel";
    private MutableLiveData<Single<User>> login;
    private MutableLiveData<Single<byte[]>> verificationCodeImage;
    private MutableLiveData<Single<Boolean>> verificationCodeCheckResult;

    public LoginViewModel() {
        login = new MutableLiveData<>();
        verificationCodeImage = new MutableLiveData<>();
        verificationCodeCheckResult = new MutableLiveData<>();
    }

    public void userLogin(@NonNull RQUserLogin userLogin){
        Single<RSResult<User,String>> resultSingle = FreelyClient.getFreelyService()
                .userLogin(userLogin);
        Disposable disposable = resultSingle.subscribeOn(Schedulers.io())
                .subscribe(userStringRSResult -> {
                    //响应成功
                    if (!userStringRSResult.isResult()) {
                        //服务端处理失败
                        login.postValue(Single.error(
                                new ServerException(userStringRSResult.getFailure())
                        ));
                        return;
                    }
                    //服务端处理成功
                    User user = userStringRSResult.getSuccess();
                    Log.d(TAG, "userLogin: "+user.toString());
                    //写入sharePreferences
                    FreelySharedPreferences.getInstance().setUserId(user.getUserId());
                    //写入数据库
                    FreelyDatabase.getInstance().userDAO().insertUser(user);
                    login.postValue(Single.just(user));
                }, throwable -> {
                    //响应失败
                    login.postValue(Single.error(throwable));
                });

        register(disposable);
    }

    public void loadVerificationCodeImage(@NonNull RQDeviceCode deviceCode) {
        Single<RSResult<String,String>> single = FreelyClient.getFreelyService()
                .verificationRequest(deviceCode);
        Disposable disposable = single.subscribeOn(Schedulers.io())
                .subscribe(rsResult -> {
                    //响应成功
                    if (!rsResult.isResult()) {
                        //服务端处理失败
                        verificationCodeImage.postValue(Single.error(
                                new ServerException(rsResult.getFailure())
                        ));
                        return;
                    }
                    //服务端处理成功
                    //base64解码
                    byte[] bitmap = Base64.decode(rsResult.getSuccess(), Base64.DEFAULT);
                    verificationCodeImage.postValue(Single.just(bitmap));
                }, throwable -> {
                    //响应失败
                    verificationCodeImage.postValue(Single.error(throwable));
                });

        register(disposable);

    }

    public void checkVerificationCode(@NonNull RQVerificationCheck verificationCheck){
        Single<RSResult<String,String>> single = FreelyClient.getFreelyService()
                .verificationCheck(verificationCheck);
        //响应成功
        Disposable disposable = single.subscribeOn(Schedulers.io())
                .subscribe(rsResult -> {
                    if (!rsResult.isResult()) {
                        //请求处理失败
                        verificationCodeCheckResult.postValue(Single.error(
                                new ServerException(rsResult.getFailure())
                        ));
                        return;
                    }
                    //请求处理成功
                    verificationCodeCheckResult.postValue(Single.just(true));
                }, throwable -> {
                    //响应失败
                    verificationCodeCheckResult.postValue(Single.error(throwable));
                });
        register(disposable);
    }

    public MutableLiveData<Single<User>> getLogin() {
        return login;
    }

    public MutableLiveData<Single<byte[]>> getVerificationCodeImage() {
        return verificationCodeImage;
    }

    public MutableLiveData<Single<Boolean>> getVerificationCodeCheckResult() {
        return verificationCodeCheckResult;
    }
}
