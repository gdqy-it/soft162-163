package com.freely.data.network.webSocket.entities;

import com.google.gson.annotations.SerializedName;

import androidx.annotation.NonNull;

/**
 * @author DaWan
 * @time 2018/11/28 23:40
 * @dscription
 */
public class DataType {
	public static final int SEND_MESSAGE = 2;
	public static final int RESPONSE_SUCCESS = 200;


	@SerializedName("data_type")
	private int dataType;

	public int getDataType() {
		return dataType;
	}

	public void setDataType(int dataType) {
		this.dataType = dataType;
	}

	@NonNull
	@Override
	public String toString() {
		return "DataType{" +
				"dataType=" + dataType +
				'}';
	}
}
