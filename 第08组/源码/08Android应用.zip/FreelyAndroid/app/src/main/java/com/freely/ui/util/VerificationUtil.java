package com.freely.ui.util;

import android.content.Context;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.freely.R;
import com.google.android.material.textfield.TextInputLayout;

import androidx.annotation.NonNull;

public final class VerificationUtil {
    private static final String TAG = "VerificationUtil";
    private VerificationUtil() {
    }

    public static void errorAnimation(Context context, TextInputLayout view,String errorHint) {
        Animation shake = AnimationUtils.loadAnimation(context, R.anim.shake);
        view.startAnimation(shake);
        view.setErrorEnabled(true);
        view.setError(errorHint);
    }
    /**
     * @param text 用户账号
     * @param inputLayout TextInputLayout 实例
     * @param formatErrorHint 用户账号格式错误提示
     * @param lengthErrorHint 用户账号长度错误提示
     */
    public static void accountVerificationHint(
            @NonNull String text,
            @NonNull TextInputLayout inputLayout,
            @NonNull String formatErrorHint,
            @NonNull String lengthErrorHint) {
        if (DataVerification.userAccountFormatVerification(text)
                && DataVerification.userAccountLengthVerification(text)) {
            inputLayout.setErrorEnabled(false);
        }
        if (!DataVerification.userAccountFormatVerification(text)) {
            inputLayout.setErrorEnabled(true);
            inputLayout.setError(formatErrorHint);
        }
        if (!DataVerification.userAccountLengthVerification(text)) {
            inputLayout.setErrorEnabled(true);
            inputLayout.setError(lengthErrorHint);
        }
    }

    public static void passwordVerificationHint(
            @NonNull String text,
            @NonNull TextInputLayout inputLayout,
            @NonNull String formatErrorHint,
            @NonNull String lengthErrorHint) {
        if (DataVerification.userPasswordFormatVerification(text)
                && DataVerification.userPasswordLengthVerification(text)) {
            inputLayout.setErrorEnabled(false);
        }
        if (!DataVerification.userPasswordFormatVerification(text)) {
            inputLayout.setErrorEnabled(true);
            inputLayout.setError(formatErrorHint);
        }
        if (!DataVerification.userPasswordLengthVerification(text)) {
            inputLayout.setErrorEnabled(true);
            inputLayout.setError(lengthErrorHint);
        }
    }

    public static void checkPasswordVerificationHint(
            @NonNull String password,
            @NonNull String checkPassword,
            @NonNull TextInputLayout inputLayout,
            @NonNull String errorHint
    ) {
        if (DataVerification.userCheckPasswordFormatVerification(password, checkPassword)) {
            inputLayout.setErrorEnabled(false);
        }else {
            inputLayout.setErrorEnabled(true);
            inputLayout.setError(errorHint);
        }
    }

  public static void emailVerificationHint(
            @NonNull String text,
            @NonNull TextInputLayout inputLayout,
            @NonNull String formatErrorHint) {
        if (DataVerification.userEmailFormatVerification(text)) {
            inputLayout.setErrorEnabled(false);
        }
        if (!DataVerification.userEmailFormatVerification(text)) {
            inputLayout.setErrorEnabled(true);
            inputLayout.setError(formatErrorHint);
        }
    }

    public static void verificationCodeVerificationHint(
            String text,
            @NonNull TextInputLayout inputLayout,
            @NonNull String nullErrorHint) {
        if (!DataVerification.verificationCodeFormatVerification(text)) {
            inputLayout.setErrorEnabled(false);
        }
        if (DataVerification.userEmailFormatVerification(text)) {
            inputLayout.setErrorEnabled(true);
            inputLayout.setError(nullErrorHint);
        }
    }

    /**
     * @param text 群名称
     * @param inputLayout TextInputLayout 实例
     * @param lengthErrorHint 群名称长度错误提示
     */
    public static void groupNameVerificationHint(
            String text,
            @NonNull TextInputLayout inputLayout,
            @NonNull String lengthErrorHint){
        boolean result = DataVerification.groupNameLengthVerification(text);
        //正确
        Log.d(TAG, "groupNameVerificationHint: 正确");
        if (result) {
            inputLayout.setErrorEnabled(false);
            return;
        }
        //错误
        Log.d(TAG, "groupNameVerificationHint: 错误");
        inputLayout.setErrorEnabled(true);
        inputLayout.setError(lengthErrorHint);
    }

    /**
     * @param groupIntro 群公告
     * @param inputLayout Text Input Layout 实例
     * @param lengthErrorHint 群公告长度错误提示
     */
    public static void groupIntroVerificationHint(
            String groupIntro,
            @NonNull TextInputLayout inputLayout,
            @NonNull String lengthErrorHint){
        boolean result = DataVerification.groupIntroLengthVerification(groupIntro);
        //正确
        if (result) {
            inputLayout.setErrorEnabled(false);
            return;
        }
        //错误
        inputLayout.setErrorEnabled(true);
        inputLayout.setError(lengthErrorHint);
    }

    /**
     * @param userNick 用户昵称
     * @param inputLayout Text Input Layout 实例
     * @param lengthErrorHint 用户昵称长度错误提示
     */
    public static void userNickVerificationHint(
            String userNick,
            @NonNull TextInputLayout inputLayout,
            @NonNull String lengthErrorHint){
        boolean result = DataVerification.userNickLengthVerification(userNick);

        //正确
        if (result) {
            inputLayout.setErrorEnabled(false);
            return;
        }
        //错误
        inputLayout.setErrorEnabled(true);
        inputLayout.setError(lengthErrorHint);
    }

    /**
     * @param userPhone 用户手机号码
     * @param inputLayout Text Input Layout 实例
     * @param lengthErrorHint 用户昵称长度错误提示
     */
    public static void userPhoneVerificationHint(
            @NonNull  String userPhone,
            @NonNull TextInputLayout inputLayout,
            @NonNull String lengthErrorHint){
        boolean result = DataVerification.userPhoneLengthVerification(userPhone);

        //正确
        if (result) {
            inputLayout.setErrorEnabled(false);
            return;
        }
        //错误
        inputLayout.setErrorEnabled(true);
        inputLayout.setError(lengthErrorHint);
    }

}
