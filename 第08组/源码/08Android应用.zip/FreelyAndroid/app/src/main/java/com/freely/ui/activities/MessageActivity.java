package com.freely.ui.activities;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.freely.R;
import com.freely.R2;
import com.freely.component.BaseRecyclerViewAdapter;
import com.freely.component.activity.NavigationActivity;
import com.freely.data.entities.Group;
import com.freely.data.entities.Message;
import com.freely.data.entities.User;
import com.freely.ui.util.DateFormat;
import com.freely.ui.viewModel.MessageViewModel;

import java.util.List;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;

public class MessageActivity extends NavigationActivity {
    private static final String TAG = "MessageActivity";
    private static final int REQUEST_CODE_MESSAGE_DETAIL = 1;
    @BindView(R2.id.recycler_view)
    RecyclerView recyclerView;
    @BindView(R2.id.default_message_background)
    ImageView messageBackground;

    private BaseRecyclerViewAdapter adapter;
    private MessageViewModel viewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        init();
    }

    private void init() {
        viewModel = ViewModelProviders.of(this).get(MessageViewModel.class);
        viewModel.setUserId(getIntent().getLongExtra(User.user_id, -1));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new BaseRecyclerViewAdapter() {
            @Override
            public int getItemCount() {
                List<Message> list = viewModel.getMessageList().getValue();
                return list == null ? 0 : list.size();
            }
        };
        adapter.getView(position -> R.layout.item_message);
        adapter.onBindView((holder, position) -> {
            ImageView headIcon = holder.getView(R.id.head_icon);
            TextView title = holder.getView(R.id.title);
            TextView content = holder.getView(R.id.content);
            TextView time = holder.getView(R.id.time);
            Message message = viewModel.getMessageList().getValue().get(position);

            title.setText(message.getMessageTitle());
            content.setText(message.getMessageContent());
            time.setText(DateFormat.format(DateFormat.TIME_FORMAT, message.getMessageSendTime()));

            if (!holder.itemView.hasOnClickListeners()) {
                holder.itemView.setOnClickListener(v -> {
                    MessageDetailActivity.startActivity(this,message.getMessageId());
                });
            }
        });
        recyclerView.setAdapter(adapter);

        viewModel.getMessageList().observe(this, messages -> {
            messageBackground.setVisibility(messages.isEmpty() ? View.VISIBLE : View.GONE);
            adapter.notifyDataSetChanged();
        });
        viewModel.loadMessageList(viewModel.getUserId());
    }

    public static void startActivity(Activity activity,int requestCode, long userId) {
        Intent intent = new Intent(activity, MessageActivity.class);
        intent.putExtra(User.user_id, userId);
        activity.startActivityForResult(intent,requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode != RESULT_OK) {
            return;
        }
        switch (requestCode) {
            case REQUEST_CODE_MESSAGE_DETAIL:
                long groupId = data.getLongExtra(Group.group_id, -1);
                if (groupId == -1) {
                    return;
                }
                viewModel.getGroupIds().add(groupId);
                break;
        }
    }

    @Override
    public void finish() {
        List<Long> groupIds = viewModel.getGroupIds();
        if (!groupIds.isEmpty()) {
            Intent intent = new Intent();
            intent.putExtra(Group.group_id, groupIds.toArray(new Long[groupIds.size()]));
            setResult(RESULT_OK,intent);
        }
        super.finish();
    }
}
