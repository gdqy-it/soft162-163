package com.freely.component.activity;

import android.os.Bundle;

import com.freely.data.database.FreelyDatabase;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;

public class FreelyBaseActivity extends AppCompatActivity {
    private CompositeDisposable disposables = new CompositeDisposable();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onDestroy() {
        FreelyActivityManager.remove(this);
        disposables.clear();
        FreelyDatabase database = FreelyDatabase.getInstance();
        if (database.isOpen()) {
            database.close();
        }
        super.onDestroy();
    }

    protected boolean register(Disposable disposable){
        return this.disposables.add(disposable);
    }

}
