package com.freely.ui.viewModel;

import android.nfc.Tag;
import android.util.Log;

import com.freely.component.BaseViewModel;
import com.freely.data.database.FreelyDatabase;
import com.freely.data.managerUtils.FreelySharedPreferences;
import com.freely.data.network.FreelyClient;
import com.freely.data.network.ServerException;
import com.freely.data.network.requestEntities.RQApplyAndExitGroup;
import com.freely.data.network.requestEntities.RQDeleteGroup;
import com.freely.data.network.requestEntities.RQGroupInfomation;
import com.freely.data.network.responseEntities.RSGroupInfomation;
import com.freely.data.network.responseEntities.RSResult;
import com.freely.ui.util.ErrorUtil;

import androidx.lifecycle.MutableLiveData;
import io.reactivex.Scheduler;
import io.reactivex.Single;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;


public class GroupChatInfomationViewModel extends BaseViewModel {

    private static final String TAG = "GroupChatInfomationView";
    private MutableLiveData<RSGroupInfomation> group;
    public static final String IS_DONE = "IS_DONE";
    private MutableLiveData<String> isDone;
    private MutableLiveData<Single<Boolean>> appylResult;
    public GroupChatInfomationViewModel(){
        group = new MutableLiveData<RSGroupInfomation>();
        isDone = new MutableLiveData<String>();
        appylResult=new MutableLiveData<Single<Boolean>>();
    }

    public MutableLiveData<Single<Boolean>> getAppylResult() {
        return appylResult;
    }

    //获得群信息
    public void getGroupInfo(long groupId){

        RQGroupInfomation rqGroupInfomation = new RQGroupInfomation(groupId);
        rqGroupInfomation.setGroup_id(groupId);

        Single<RSResult<RSGroupInfomation, String>> groupSingle=FreelyClient.getFreelyService().queryGroupInformation(rqGroupInfomation);

        Disposable disposable = groupSingle.subscribeOn(Schedulers.io())
                .subscribe(rsResult -> {
                 RSGroupInfomation rsGroupInfomation=rsResult.getSuccess();
                 group.postValue(rsGroupInfomation);
                }, throwable -> {
                    ErrorUtil.dataReadErrorHint("读取群组信息错误", throwable);
                });

        register(disposable);
    }
    public MutableLiveData<RSGroupInfomation> getGroup(){
        return this.group;
    }

//申请加入群
    public void applyForGroup(long groupId){
        Single<RSResult<String, String>> joinGroupSingle = FreelyClient.getFreelyService().
                applyForGroup(new RQApplyAndExitGroup(FreelySharedPreferences.getInstance().getUserId(),groupId));

        Disposable disposable = joinGroupSingle
                .subscribeOn(Schedulers.io())
                .subscribe(
                        stringRSResult -> {
                            //应答成功
                            //服务器处理失败
                            if (!stringRSResult.isResult()) {
                                Log.e(TAG, "applyForGroup: "+"failed");
                                appylResult.postValue(Single.error(
                                        new ServerException(stringRSResult.getFailure().toString())
                                ));
                                return;
                            }
                            appylResult.postValue(Single.just(true));
                            //服务器处理成功
                            Log.e(TAG, "applyForGroup: "+"申请成功" );
                        }, throwable -> {
                            //应答失败
                            ErrorUtil.errorHint(throwable);
                            appylResult.postValue(Single.error(throwable));
                        }
                );

        register(disposable);
    }
//退出群
    public void exitGroup(long groupId){
        isDone.postValue(null);
        Single<RSResult<String, String>> exitGroupSingle = FreelyClient.getFreelyService().
                exitGroup(new RQApplyAndExitGroup(FreelySharedPreferences.getInstance().getUserId(),groupId));
        Disposable disposable = exitGroupSingle
                .subscribeOn(Schedulers.io())
                .subscribe(
                        stringRSResult -> {
                            //应答成功
                            //服务器处理失败
                            if (!stringRSResult.isResult()) {
                                Log.e(TAG, "exitGroup: "+"failed");
                                return;
                            }
                            //服务器处理成功
                            FreelyDatabase.getInstance().groupDAO().deleteGroupById(groupId);
                            deleteFromDatabase(groupId);
                        }, throwable -> {
                            //应答失败
                            ErrorUtil.errorHint(throwable);
                        }
                );
        register(disposable);
    }

    public MutableLiveData<String> getIsDone() {
        return isDone;
    }

    //解散群
    public void deleteGroup(long groupId){
        isDone.postValue(null);
        Single<RSResult<String, String>> deleteGroupSingle = FreelyClient.getFreelyService().
                deleteGroup(new RQDeleteGroup(groupId,FreelySharedPreferences.getInstance().getUserId()));
        Disposable disposable = deleteGroupSingle.
                subscribeOn(Schedulers.io())
                .subscribe(

                        stringRSResult -> {
                            if (!stringRSResult.isResult()) {
                                Log.e(TAG, "deleteGroup: "+"failed");
                                return;
                            }
                            deleteFromDatabase(groupId);
                            Log.e(TAG, "deleteGroup: "+"删除成功" );
                        }, throwable -> {
                            //应答失败
                            ErrorUtil.errorHint(throwable);
                        }
                );
        register(disposable);
    }

    public void deleteFromDatabase(long groupId){
        Log.e(TAG, "deleteFromDatabase: " );
        FreelyDatabase.getInstance().groupDAO().deleteGroupById(groupId);
        isDone.postValue(IS_DONE);
    }
}
