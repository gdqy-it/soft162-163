package com.freely.component.repository;

public interface NetworkDataGet<T> {
    T getNetworkData();
}
