package com.freely.data.adapter;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;
import java.util.Date;

/**
 * @author DaWan
 * @time 2018/12/3 8:41
 * @dscription
 */
public class GsonDateAdapter implements JsonDeserializer<Date> {
	private static final String TAG = "GsonDateAdapter";
	@Override
	public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
		return new Date(json.getAsJsonPrimitive().getAsLong());
	}
}
