package com.freely.data.network.requestEntities;

import com.freely.FR;
import com.google.gson.annotations.SerializedName;

public class RQUserRegister implements BaseRQEntity {
    @SerializedName(FR.DEVICE_CODE)
    private String deviceCode;
    @SerializedName(FR.USER_ACCOUNT)
    private String userAccount;
    @SerializedName(FR.USER_PASSWORD)
    private String userPassword;
    @SerializedName(FR.USER_EMAIL)
    private String userEmail;

    public RQUserRegister(String deviceCode, String userAccount, String userPassword, String userEmail) {
        this.deviceCode = deviceCode;
        this.userAccount = userAccount;
        this.userPassword = userPassword;
        this.userEmail = userEmail;
    }

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public String getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(String userAccount) {
        this.userAccount = userAccount;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
}
