package com.freely.component;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public abstract class BaseRecyclerViewAdapter extends RecyclerView.Adapter<BaseViewHolder> {
    private BindView<BaseViewHolder> bindView;
    private GetView getView;

    @FunctionalInterface
    public interface BindView<H> {
        void bindView(H holder, int position);
    }

    @FunctionalInterface
    public interface GetView {
        @LayoutRes
        int getView(int position);
    }

    @NonNull
    @Override
    public final BaseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false);
        return BaseViewHolder.getInstance(view);
    }

    @Override
    public final void onBindViewHolder(@NonNull BaseViewHolder holder, int position) {
        bindView.bindView(holder, position);
    }

    public <A extends BaseRecyclerViewAdapter> A onBindView(
            @NonNull BindView<BaseViewHolder>  bindView) {
        this.bindView = bindView;
        return (A) this;
    }

    @Override
    public int getItemViewType(int position) {
        return getView.getView(position);
    }

    public BaseRecyclerViewAdapter getView(@NonNull GetView getView) {
        this.getView = getView;
        return this;
    }
}
