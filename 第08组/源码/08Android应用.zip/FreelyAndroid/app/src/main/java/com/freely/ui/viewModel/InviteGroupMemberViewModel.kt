package com.freely.ui.viewModel

import androidx.lifecycle.MutableLiveData
import com.freely.component.BaseViewModel
import com.freely.data.Node
import com.freely.data.database.FreelyDatabase
import com.freely.data.entities.Group
import com.freely.data.entities.User
import com.freely.data.network.FreelyClient
import com.freely.data.network.ServerException
import com.freely.ui.util.ErrorUtil
import io.reactivex.schedulers.Schedulers

/**
 * @author DaWan
 * @time 2018/12/11 11:10
 * @description
 */
class InviteGroupMemberViewModel : BaseViewModel() {
    private val TAG = "InviteGroupMemberViewMo"
    val list = MutableLiveData<MutableList<Node<*>>>()
    init {
        list.value = mutableListOf()
    }

    val inviteResult = MutableLiveData<Boolean>()
    val changeList = MutableLiveData<Int>()
    var userId = -1L
    var groupId = -1L

    fun loadGroupList(userId: Long) {
        val single = FreelyDatabase.getInstance().groupDAO().queryJoinedChatGroupList(userId)
        val disposable = single.subscribeOn(Schedulers.io()).subscribe({
            val temp = list.value
            for (item in it) {
                if (groupId == item.groupId) continue
                val node = Node<Group>()
                node.value = item
                temp?.add(node)
            }
            list.postValue(temp)
        }, { ErrorUtil.errorHint(it) })
        register(disposable)
    }

    fun loadMemberList(groupId: Long, position: Int) {
        val tempList = list.value
        val node = tempList?.get(position)
        val childNode = node?.childNode
        if (childNode != null && childNode.isNotEmpty()) {
            tempList.addAll(position + 1, childNode)
            changeList.postValue(position)
            return
        }
/*        val single = FreelyDatabase.getInstance().userDAO().queryUsersByGroupId(groupId)
        val disposable = single.subscribeOn(Schedulers.io()).subscribe({
            for (item in it) {
                Log.d(TAG, "loadMemberList: $item")
                val userNode = Node<User>(node)
                userNode.value = item
                childNode?.add(userNode)
            }
            if (childNode != null) {
                tempList.addAll(position + 1, childNode)
            }
            changeList.postValue(position)
        }, { ErrorUtil.errorHint(it) })*/
        val arg = mapOf<Any, Any>(Group.group_id to groupId)
        val disposable = FreelyClient.getFreelyService().queryAllMember(arg)
                .subscribeOn(Schedulers.io())
                .map {
                    if (!it.isResult) throw ServerException(it.failure)
                    return@map it.success
                }
                .subscribe({
                    for (item in it) {
                        val user = User()
                        user.userId = item.user_id
                        user.userName = item.user_name
                        user.userImage = item.user_image
                        val userNode = Node<User>(node)
                        userNode.value = user
                        childNode?.add(userNode)
                    }
                    if (childNode != null) {
                        tempList.addAll(position + 1, childNode)
                    }
                    changeList.postValue(position)
                }, { ErrorUtil.errorHint(it) })

        register(disposable)
    }

    fun inviteMember(groupId: Long, inviteeId: Long) {
        val args = mutableMapOf<Any, Any>()
        args[Group.group_id] = groupId
        args["inviter_id"] = userId
        args["invitee_id"] = inviteeId

        val single = FreelyClient.getFreelyService().inviteMember(args)
        val disposable = single.subscribeOn(Schedulers.io()).subscribe({
            inviteResult.postValue(it.isResult)
        }, { ErrorUtil.errorHint(it) })

        register(disposable)
    }
}