package com.freely.data.network.requestEntities;

import com.google.gson.annotations.SerializedName;

public class RQDeleteGroup {
    @SerializedName("group_id")
    private long groupId;
    @SerializedName("group_admin")
    private long groupAdmin;

    public RQDeleteGroup(long groupId, long groupAdmin) {
        this.groupId = groupId;
        this.groupAdmin = groupAdmin;
    }

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }

    public long getGroupAdmin() {
        return groupAdmin;
    }

    public void setGroupAdmin(long groupAdmin) {
        this.groupAdmin = groupAdmin;
    }
}
