package com.freely.data.network.webSocket;

import com.google.gson.JsonElement;

/**
 * @author DaWan
 * @time 2018/11/28 21:08
 * @dscription
 */
@FunctionalInterface
public interface MessageListener {
	boolean onMessage(int type, JsonElement data);
}
