package com.freely.ui.viewModel;

import android.util.Base64;
import android.util.Log;

import com.freely.component.BaseViewModel;
import com.freely.data.entities.User;
import com.freely.data.network.FreelyClient;
import com.freely.data.network.ServerException;
import com.freely.data.network.requestEntities.RQDeviceCode;
import com.freely.data.network.requestEntities.RQUserRegister;
import com.freely.data.network.requestEntities.RQVerificationCheck;
import com.freely.data.network.responseEntities.RSResult;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import io.reactivex.Single;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class RegisterViewModel extends BaseViewModel {
    private static final String TAG = "RegisterViewModel";
    private MutableLiveData<Single<byte[]>> verificationCodeImage;
    private MutableLiveData<Single<Boolean>> verificationCodeCheckResult;
    private MutableLiveData<Single<Boolean>> registerResult;

    public RegisterViewModel() {
        verificationCodeImage = new MutableLiveData<>();
        verificationCodeCheckResult = new MutableLiveData<>();
        registerResult = new MutableLiveData<>();
    }

    public void loadVerificationCodeImage(@NonNull RQDeviceCode deviceCode) {
        Single<RSResult<String,String>> single = FreelyClient.getFreelyService()
                .verificationRequest(deviceCode);
        Disposable disposable = single.subscribeOn(Schedulers.io())
                .subscribe(rsResult -> {
                    //响应成功
                    if (!rsResult.isResult()) {
                        //服务端处理失败
                        verificationCodeImage.postValue(Single.error(
                                new ServerException(rsResult.getFailure())
                        ));
                        return;
                    }
                    //服务端处理成功
                    //base64解码
                    byte[] bitmap = Base64.decode(rsResult.getSuccess(), Base64.DEFAULT);
                    verificationCodeImage.postValue(Single.just(bitmap));
                }, throwable -> {
                    //响应失败
                    verificationCodeImage.postValue(Single.error(throwable));
                });

        register(disposable);

    }

    public void checkVerificationCode(@NonNull RQVerificationCheck verificationCheck){
        Single<RSResult<String,String>> single = FreelyClient.getFreelyService()
                .verificationCheck(verificationCheck);
        //响应成功
        Disposable disposable = single.subscribeOn(Schedulers.io())
                .subscribe(rsResult -> {
                    if (!rsResult.isResult()) {
                        //请求处理失败
                        verificationCodeCheckResult.postValue(Single.error(
                                new ServerException(rsResult.getFailure())
                        ));
                        return;
                    }
                    //请求处理成功
                    verificationCodeCheckResult.postValue(Single.just(true));
                }, throwable -> {
                    //响应失败
                    verificationCodeCheckResult.postValue(Single.error(throwable));
                });
        register(disposable);
    }

    public void userRegister(@NonNull RQUserRegister user) {
        Single<RSResult<String, String>> single = FreelyClient.getFreelyService()
                .userRegister(user);

        Disposable disposable = single.subscribeOn(Schedulers.io())
                .subscribe(result -> {
                    //响应成功
                    if (!result.isResult()) {
                        //请求处理失败
                        registerResult.postValue(Single.error(
                                new ServerException(result.getFailure().toString())
                        ));
                        return;
                    }
                    //请求处理成功
                    registerResult.postValue(Single.just(result.isResult()));
                }, throwable -> {
                    //请求失败
                    Log.e(TAG, "userRegister: "+throwable.getMessage() );
                    registerResult.postValue(Single.error(throwable));
                });
        //解除绑定
        register(disposable);
    }

    public MutableLiveData<Single<byte[]>> getVerificationCodeImage() {
        return verificationCodeImage;
    }

    public MutableLiveData<Single<Boolean>> getVerificationCodeCheckResult() {
        return verificationCodeCheckResult;
    }

    public MutableLiveData<Single<Boolean>> getRegisterResult() {
        return registerResult;
    }
}
