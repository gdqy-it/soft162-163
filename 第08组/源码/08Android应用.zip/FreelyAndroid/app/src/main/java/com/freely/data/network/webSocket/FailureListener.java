package com.freely.data.network.webSocket;

import androidx.annotation.Nullable;
import okhttp3.Response;
import okhttp3.WebSocket;

/**
 * @author DaWan
 * @time 2018/11/29 0:16
 * @dscription
 */
@FunctionalInterface
public interface FailureListener {
	boolean onFailure(WebSocket webSocket, Throwable t, @Nullable Response response);
}
