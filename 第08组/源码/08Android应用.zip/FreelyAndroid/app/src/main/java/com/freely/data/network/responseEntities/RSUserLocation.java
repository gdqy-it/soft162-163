package com.freely.data.network.responseEntities;

import com.freely.data.entities.User;
import com.freely.data.network.requestAPI.FreelyAPI;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import androidx.annotation.NonNull;

public class RSUserLocation implements Serializable {
    @SerializedName(User.user_id)
    private long userId;//用户id

    @SerializedName(User.user_account)
    private String userAccount;//用户帐号

    @SerializedName(User.user_name)
    private String userName;//用户昵称

    @SerializedName(User.user_image)
    private String userImage;//用户头像

    @SerializedName(FreelyAPI.location_longitude)
    private double locationLongitude;//经度

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(String userAccount) {
        this.userAccount = userAccount;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserImage() {
        return userImage;
    }

    public void setUserImage(String userImage) {
        this.userImage = userImage;
    }

    public double getLocationLongitude() {
        return locationLongitude;
    }

    public void setLocationLongitude(double locationLongitude) {
        this.locationLongitude = locationLongitude;
    }

    public double getLocationLatitude() {
        return locationLatitude;
    }

    public void setLocationLatitude(double locationLatitude) {
        this.locationLatitude = locationLatitude;
    }

    @SerializedName(FreelyAPI.location_latitude)
    private double locationLatitude;//纬度

    @Override
    public String toString() {
        return "RSUserLocation{" +
                "userId=" + userId +
                ", userAccount='" + userAccount + '\'' +
                ", userName='" + userName + '\'' +
                ", userImage='" + userImage + '\'' +
                ", locationLongitude=" + locationLongitude +
                ", locationLatitude=" + locationLatitude +
                '}';
    }
}
