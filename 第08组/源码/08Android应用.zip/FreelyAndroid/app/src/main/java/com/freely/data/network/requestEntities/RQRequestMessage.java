package com.freely.data.network.requestEntities;

import com.freely.data.entities.User;
import com.google.gson.annotations.SerializedName;

/**
 * @author DaWan
 * @time 2018/12/6 11:37
 * @dscription
 */
public class RQRequestMessage implements BaseRQEntity {
	@SerializedName("data_type")
	private int dataType;
	@SerializedName(User.user_id)
	private long userId;

	public int getDataType() {
		return dataType;
	}

	public void setDataType(int dataType) {
		this.dataType = dataType;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}
}
