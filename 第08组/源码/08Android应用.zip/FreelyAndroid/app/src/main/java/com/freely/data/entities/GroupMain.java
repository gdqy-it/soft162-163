package com.freely.data.entities;

import java.util.Date;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import io.reactivex.annotations.NonNull;

/*
        字段              	类型	            键           	是否为空    	备注
        group_id        	bigint      	primary key 	not null	群id
        group_image     	varchar(50)             		not null	群头像
        group_last_time 	timestamp                                   本地最后一条信息时间
        group_last_message  varchar(50)                                 本地最后一条信息内容
        */

@Entity(tableName = "group_Main")
public class GroupMain {
    @Ignore
    public static final String group_main_id="group_main_id";
    @Ignore
    public static final String group_last_time="group_last_time";
    @Ignore
    public static final String group_last_message = "group_last_message";


    @PrimaryKey
    @ColumnInfo(name = GroupMain.group_main_id)
    @NonNull
    private long groupMainId;

    @NonNull
    @ColumnInfo(name = Group.group_id)
    private long groupId;//群id

    @NonNull
    @ColumnInfo(name=GroupMain.group_last_time)
    private Date lastMessageTime;//本地最后一条信息时间

    @ColumnInfo(name = Group.group_image)
    private String groupImage;//群头像

    @NonNull
    @ColumnInfo(name=GroupMain.group_last_message)
    private String lastMessageContent;//本地最后一条信息的内容


    public long getGroupMainId() {
        return groupMainId;
    }

    public void setGroupMainId(long groupMainId) {
        this.groupMainId = groupMainId;
    }

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }

    public Date getLastMessageTime() {
        return lastMessageTime;
    }

    public void setLastMessageTime(@NonNull Date lastMessageTime) {
        this.lastMessageTime = lastMessageTime;
    }

    public String getGroupImage() {
        return groupImage;
    }

    public void setGroupImage(String groupImage) {
        this.groupImage = groupImage;
    }

    public String getLastMessageContent() {
        return lastMessageContent;
    }
    @NonNull
    public void setLastMessageContent(@NonNull String lastMessageContent) {
        this.lastMessageContent = lastMessageContent;
    }

}

