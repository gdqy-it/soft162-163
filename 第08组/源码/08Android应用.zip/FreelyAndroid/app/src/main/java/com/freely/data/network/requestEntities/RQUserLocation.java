package com.freely.data.network.requestEntities;

public class RQUserLocation {
    //用户id,long类型
    private long user_id;
    //纬度
    private double location_latitude;
    //经度
    private double location_longitude;

    private Integer data_type=6;

    public RQUserLocation(long user_id, double location_latitude, double location_longitude) {
        this.user_id = user_id;
        this.location_latitude = location_latitude;
        this.location_longitude = location_longitude;
    }

    public long getUser_id() {
        return user_id;
    }

    public void setUser_id(long user_id) {
        this.user_id = user_id;
    }

    public double getLocation_latitude() {
        return location_latitude;
    }

    public void setLocation_latitude(double location_latitude) {
        this.location_latitude = location_latitude;
    }

    public double getLocation_longitude() {
        return location_longitude;
    }

    public void setLocation_longitude(double location_longitude) {
        this.location_longitude = location_longitude;
    }
}
