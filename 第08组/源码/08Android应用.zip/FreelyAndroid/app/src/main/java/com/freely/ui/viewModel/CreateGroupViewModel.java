package com.freely.ui.viewModel;

import android.util.Log;

import com.freely.component.BaseViewModel;
import com.freely.data.database.FreelyDatabase;
import com.freely.data.entities.Group;
import com.freely.data.entities.UserGroupRelation;
import com.freely.data.network.FreelyClient;
import com.freely.data.network.ServerException;
import com.freely.data.network.requestEntities.RQCreateGroupChat;
import com.freely.data.network.responseEntities.RSResult;

import androidx.lifecycle.MutableLiveData;
import io.reactivex.Single;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * @author DaWan
 * @time 2018/11/23 13:45
 * @dscription
 */
public class CreateGroupViewModel extends BaseViewModel {
    private static final String TAG = "CreateGroupViewModel";
    private MutableLiveData<Single<Group>> createGroupChat;

    public CreateGroupViewModel() {
        createGroupChat = new MutableLiveData<>();
    }


    /**
     * @param createGroupChat 参数
     * @description 创建群聊
     */
    public void createGroupChat(RQCreateGroupChat createGroupChat) {
        Single<RSResult<Group, String>> resultSingle = FreelyClient
                .getFreelyService()
                .createGroupChat(createGroupChat);

        Disposable disposable = resultSingle
                .subscribeOn(Schedulers.io())
                .subscribe(
                        groupStringRSResult -> {
                            //应答成功
                            //服务器处理失败
                            if (!groupStringRSResult.isResult()) {
                                this.createGroupChat.postValue(Single.error(
                                        new ServerException(groupStringRSResult.getFailure())
                                ));
                                return;
                            }
                            //服务器处理成功
                            Group group = groupStringRSResult.getSuccess();
                            Log.d(TAG, "createGroupChat: group:"+group.toString());
                            FreelyDatabase.getInstance().groupDAO().insertGroup(group);
                            UserGroupRelation relation = new UserGroupRelation();
                            relation.setUserId(createGroupChat.getGroupAdmin());
                            relation.setGroupId(group.getGroupId());
                            FreelyDatabase.getInstance()
									.userGroupRelationDAO()
									.insertUserGroupRelation(relation);
                            this.createGroupChat.postValue(Single.just(group));
                        }, throwable -> {
                            //应答失败
                            this.createGroupChat.postValue(Single.error(throwable));
                        }
                );

        register(disposable);
    }

    public MutableLiveData<Single<Group>> getCreateGroupChat() {
        return createGroupChat;
    }
}
