package com.freely.data.network.requestEntities;

import com.freely.FR;
import com.freely.data.entities.User;
import com.google.gson.annotations.SerializedName;

public class RQUserLogin implements BaseRQEntity {
    @SerializedName(FR.DEVICE_CODE)
    private String deviceCode;
    @SerializedName(User.user_account)
    private String userAccount;
    @SerializedName(User.user_password)
    private String userPassword;

    public RQUserLogin(String deviceCode, String userAccount, String userPassword) {
        this.deviceCode = deviceCode;
        this.userAccount = userAccount;
        this.userPassword = userPassword;
    }

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public String getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(String userAccount) {
        this.userAccount = userAccount;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }
}
