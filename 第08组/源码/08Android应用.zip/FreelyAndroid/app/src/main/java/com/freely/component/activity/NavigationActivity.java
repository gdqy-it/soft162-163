package com.freely.component.activity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.freely.R;
import com.freely.R2;

import androidx.annotation.DrawableRes;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.widget.Toolbar;
import butterknife.BindView;
import butterknife.ButterKnife;

public class NavigationActivity extends FreelyBaseActivity {
    @BindView(R2.id.logo)
    ImageButton logo;
    @BindView(R2.id.title)
    TextView title;
    @BindView(R2.id.toolbar)
    Toolbar toolbar;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void setContentView(int layoutResID) {
        super.setContentView(layoutResID);
        ButterKnife.bind(this);
        onCreateToolbar(this.toolbar,this.title,this.logo);
    }

    protected void onCreateToolbar(Toolbar toolbar,TextView title,ImageButton logo){
        toolbar.setNavigationIcon(navigationIcon());
        toolbar.setNavigationOnClickListener(this::navigationOnClick);
        title.setText(navigationTitle());
        logo.setOnClickListener(this::logoOnClick);
    }

    protected void setNavigationOnClick(View.OnClickListener onClick){
        toolbar.setNavigationOnClickListener(onClick);
    }

    protected void setNavigationIcon(@DrawableRes int resId) {
        toolbar.setNavigationIcon(resId);
    }

    protected void setNavigationIcon(Drawable drawable) {
        toolbar.setNavigationIcon(drawable);
    }

    protected void setLogo(Drawable icon) {
        logo.setImageDrawable(icon);
    }

    protected void setLogo(@DrawableRes int resId) {
        logo.setImageResource(resId);
    }

    protected void setLogoOnClick(View.OnClickListener onClick){
        logo.setOnClickListener(onClick);
    }

    protected void setNavigationTitle(CharSequence title) {
        this.title.setText(title);
    }

    protected void setNavigationTitle(@StringRes int titleId) {
        this.title.setText(titleId);
    }

    protected void navigationOnClick(View view) {
        finish();
    }

    protected void logoOnClick(View view) {

    }

    @DrawableRes
    protected int navigationIcon() {
        return R.drawable.ic_back;
    }

    protected CharSequence navigationTitle(){
        return getTitle();
    }

    protected void setLogoEnable(boolean enable){
        if (enable) {
            logo.setVisibility(View.VISIBLE);
        }else {
            logo.setVisibility(View.GONE);
        }
    }

    protected boolean isLogoEnable() {
        return logo.getVisibility() == View.VISIBLE;
    }

    public ImageButton getLogo() {
        return logo;
    }

    public Toolbar getToolbar() {
        return toolbar;
    }
}
