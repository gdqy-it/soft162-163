package com.freely.data.repository.entities;

import com.freely.data.entities.ChatRecord;
import com.freely.data.entities.Group;
import com.google.gson.annotations.SerializedName;

import java.util.Date;

import androidx.room.ColumnInfo;

public class HomeGroupItem {
/*    @ColumnInfo(name = Group.group_id)
    @SerializedName(Group.group_id)
    private long groupId;//群id*/
    @ColumnInfo(name = Group.group_account)
    @SerializedName(Group.group_account)
    private String groupAccount;//群帐号id
    @ColumnInfo(name = Group.group_name)
    @SerializedName(Group.group_name)
    private String groupName;//群名称
    @ColumnInfo(name = Group.group_image)
    @SerializedName(Group.group_id)
    private String groupImage;//群头像
    @ColumnInfo(name = Group.group_forbidden)
    @SerializedName(Group.group_forbidden)
    private boolean groupForbidden;//是否禁用
    @ColumnInfo(name = ChatRecord.record_content)
    private String newRecordContent;//最新聊天消息
    @ColumnInfo(name = ChatRecord.record_send_time)
    private Date sendDate;//最新聊天消息发送时间

    public String getGroupAccount() {
        return groupAccount;
    }

    public void setGroupAccount(String groupAccount) {
        this.groupAccount = groupAccount;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupImage() {
        return groupImage;
    }

    public void setGroupImage(String groupImage) {
        this.groupImage = groupImage;
    }

    public boolean isGroupForbidden() {
        return groupForbidden;
    }

    public void setGroupForbidden(boolean groupForbidden) {
        this.groupForbidden = groupForbidden;
    }

    public String getNewRecordContent() {
        return newRecordContent;
    }

    public void setNewRecordContent(String newRecordContent) {
        this.newRecordContent = newRecordContent;
    }

    public Date getSendDate() {
        return sendDate;
    }

    public void setSendDate(Date sendDate) {
        this.sendDate = sendDate;
    }
}
