package com.freely.component;

import android.util.SparseArray;
import android.view.View;

import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class BaseViewHolder extends RecyclerView.ViewHolder {
    private SparseArray<View> viewSparseArray;

    public BaseViewHolder(@NonNull View itemView) {
        super(itemView);
        viewSparseArray = new SparseArray<>();
    }

    public <T extends View> T getView(@IdRes int viewId){
        View view = viewSparseArray.get(viewId);
        if (view != null) {
            return (T) view;
        }

        view = itemView.findViewById(viewId);
        if (view != null) {
            viewSparseArray.put(viewId,view);
            return (T) view;
        }

        return null;
    }

    public static BaseViewHolder getInstance(@NonNull View itemView){
        return new BaseViewHolder(itemView);
    }

}
