package com.freely.data.network.requestEntities;

import com.google.gson.annotations.SerializedName;

public class RQApplyAndExitGroup {

    @SerializedName("user_id")
    private long userId;
    @SerializedName("group_id")
    private long groupId;

    public RQApplyAndExitGroup(long userId, long groupId) {
        this.userId = userId;
        this.groupId = groupId;
    }

    public long getUserId() {

        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }
}
