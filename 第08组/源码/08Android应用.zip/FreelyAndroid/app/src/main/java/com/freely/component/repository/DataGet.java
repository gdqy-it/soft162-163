package com.freely.component.repository;

public interface DataGet<T> {
    T getData();
}
