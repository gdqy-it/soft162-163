package com.freely.component.rxjava;

import android.util.Log;

import io.reactivex.Observer;

public abstract class DefaultObserver<T> implements Observer<T> {
    private static final String TAG = "DefaultObserver";

    @Override
    public void onError(Throwable e) {
        Log.d(TAG, "onError: 网络错误！" + e.toString());
/*        Completable.complete()
                .subscribeOn(AndroidSchedulers.mainThread())
                .subscribe(() -> {
                    Toast.makeText(
                            FreelyApplication.getContext(),
                            "网络错误!" + e,
                            Toast.LENGTH_SHORT
                    ).show();
                }).dispose();*/
    }

    @Override
    public void onComplete() {
        Log.d(TAG, "onComplete: 网络请求完成");
    }
}
