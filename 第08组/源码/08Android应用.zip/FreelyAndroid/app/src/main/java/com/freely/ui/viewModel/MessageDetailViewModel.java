package com.freely.ui.viewModel;

import com.freely.component.BaseViewModel;
import com.freely.data.database.FreelyDatabase;
import com.freely.data.entities.Group;
import com.freely.data.entities.Message;
import com.freely.data.network.FreelyClient;
import com.freely.data.network.ServerException;
import com.freely.data.network.requestEntities.RQAccountInvitation;
import com.freely.data.network.requestEntities.RQAccountJoinGround;
import com.freely.data.network.responseEntities.RSResult;
import com.freely.ui.util.ErrorUtil;

import androidx.lifecycle.MutableLiveData;
import io.reactivex.Single;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * @author DaWan
 * @time 2018/12/3 9:47
 * @dscription
 */
public class MessageDetailViewModel extends BaseViewModel {
	private MutableLiveData<Message> message = new MutableLiveData<>();
	private MutableLiveData<Group> group = new MutableLiveData<>();

	public void loadMessage(long messageId) {
		Single<Message> single = FreelyDatabase.getInstance()
				.messageDAO()
				.queryMessageByMessageId(messageId);

		Disposable disposable = single.subscribeOn(Schedulers.io())
				.subscribe(message -> {
					message.setRead(true);
					getMessage().postValue(message);
					FreelyDatabase.getInstance().messageDAO().updateMessage(message);
				}, ErrorUtil::errorHint);

		register(disposable);
	}

	/**
	 * @param groundInvite
	 * @dscription 接受入群邀请
	 */
	public void accountInvite(RQAccountJoinGround groundInvite) {
		Single<RSResult<Group, String>> single = FreelyClient.getFreelyService()
				.accountGroupInvite(groundInvite);
		Disposable disposable = single.subscribeOn(Schedulers.io())
				.subscribe(result -> {
					if (!result.isResult()) {
						ErrorUtil.errorHint(new ServerException(result.getFailure()));
						return;
					}
					Group group = result.getSuccess();
					Message message = getMessage().getValue();
					message.setResult(Message.RESULT_ACCOUNT);

					getGroup().postValue(group);
					getMessage().postValue(message);

					FreelyDatabase.getInstance().groupDAO().insertGroup(group);
					FreelyDatabase.getInstance().messageDAO().updateMessage(message);
				}, ErrorUtil::errorHint);
		register(disposable);
	}

	/**
	 * @param invitation
	 * @dscription 接受入群申请
	 */
	public void accountApply(RQAccountInvitation invitation) {
		Single<RSResult<String, String>> single = FreelyClient.getFreelyService()
				.accountJoinInvitation(invitation);
		Disposable disposable = single.subscribeOn(Schedulers.io())
				.subscribe(result -> {
					if (!result.isResult()) {
						ErrorUtil.errorHint(new ServerException(result.getFailure()));
						return;
					}
					Message message = getMessage().getValue();
					message.setResult(Message.RESULT_ACCOUNT);
					getMessage().postValue(message);
					FreelyDatabase.getInstance().messageDAO().updateMessage(message);
				}, ErrorUtil::errorHint);
		register(disposable);
	}

	public MutableLiveData<Message> getMessage() {
		return message;
	}

	public MutableLiveData<Group> getGroup() {
		return group;
	}
}
