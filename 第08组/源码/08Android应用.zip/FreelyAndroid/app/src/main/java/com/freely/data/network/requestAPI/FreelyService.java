package com.freely.data.network.requestAPI;

import com.freely.data.entities.Group;
import com.freely.data.entities.Message;
import com.freely.data.entities.User;
import com.freely.data.network.requestEntities.RQAccountInvitation;
import com.freely.data.network.requestEntities.RQAccountJoinGround;
import com.freely.data.network.requestEntities.RQApplyAndExitGroup;
import com.freely.data.network.requestEntities.RQCreateGroupChat;
import com.freely.data.network.requestEntities.RQDeleteGroup;
import com.freely.data.network.requestEntities.RQDeleteMember;
import com.freely.data.network.requestEntities.RQDeviceCode;
import com.freely.data.network.requestEntities.RQGroupAccount;
import com.freely.data.network.requestEntities.RQGroupInfomation;
import com.freely.data.network.requestEntities.RQMemberInfomation;
import com.freely.data.network.requestEntities.RQQueryMemberInformation;
import com.freely.data.network.requestEntities.RQUserId;
import com.freely.data.network.requestEntities.RQUserLocation;
import com.freely.data.network.requestEntities.RQUserLogin;
import com.freely.data.network.requestEntities.RQUserRegister;
import com.freely.data.network.requestEntities.RQVerificationCheck;
import com.freely.data.network.responseEntities.RSGroup;
import com.freely.data.network.responseEntities.RSGroupInfomation;
import com.freely.data.network.responseEntities.RSResult;
import com.freely.data.network.responseEntities.RSUserInfomation;
import com.freely.data.network.responseEntities.RSUserLocation;

import java.util.List;
import java.util.Map;

import io.reactivex.Single;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface FreelyService {

    //1．图片验证码请求
    @POST("verification_request.action")
    Single<RSResult<String, String>> verificationRequest(@Body RQDeviceCode deviceCode);

    //3．图片验证码验证请求
    @POST("verification_check.action")
    Single<RSResult<String, String>> verificationCheck(@Body RQVerificationCheck verificationCheck);

    //5．注册请求
    @POST("user_register.action")
    Single<RSResult<String, String>> userRegister(@Body RQUserRegister userRegister);

    //用户登录
    @POST("user_login.action")
    Single<RSResult<User, String>> userLogin(@Body RQUserLogin userLogin);

    //获取已加入群列表
    @POST("group_queryAllAddedGroup.action")
    Single<RSResult<List<Group>,String>> getJoinedGroupList(@Body RQUserId userId);

    //搜索想要加入的群
	@POST("group_searchGroup.action")
    Single<RSResult<RSGroup,String>> searchThinkJoinGroup(@Body RQGroupAccount groupAccount);

    //创建群聊
    @POST("group_createGroup.action")
    Single<RSResult<Group, String>> createGroupChat(@Body RQCreateGroupChat createGroupChat);

    //查看所有消息通知
    @POST("message_queryAllMessage.action")
    Single<RSResult<List<Message>, String>> allMessage(@Body RQUserId userId);

    //同意或拒绝群邀请
    @POST("message_dealGroupInvite.action")
    Single<RSResult<Group, String>> accountGroupInvite(@Body RQAccountJoinGround groundInvite);

    //同意或拒绝群加入申请
    @POST("message_dealJoinGroupInvite.action")
    Single<RSResult<String, String>> accountJoinInvitation(@Body RQAccountInvitation invitation);

    //更新个人信息
    @POST("user_updatePersonInformation.action")
    Single<RSResult<String, String>> updateUserInformation(@Body User user);

    //更新群相关信息
    @POST("group_updateGroupInformation.action")
    Single<RSResult<String,String>> updateGroupInformation(@Body Group group);

    //查询特定群信息
    @POST("group_queryGroupInformation.action")
    Single<RSResult<RSGroupInfomation, String>>queryGroupInformation(@Body RQGroupInfomation rqGroupInfomation);

    //查看特定成员信息
    @POST("group_queryMemberInformation.action")
    Single<RSResult<User, String>> queryMemberInformation(@Body RQQueryMemberInformation queryMember);

    //申请加群
    @POST("group_addGroup.action")
    Single<RSResult<String, String>> applyForGroup(@Body RQApplyAndExitGroup rqApplyAndExitGroup);

    //退出群
    @POST("group_exitGroup.action")
    Single<RSResult<String, String>> exitGroup(@Body RQApplyAndExitGroup rqApplyAndExitGroup);

    //删除群
    @POST("group_deleteGroup.action")
    Single<RSResult<String, String>> deleteGroup(@Body RQDeleteGroup rqDeleteGroup);

    //8.更新GPS信息
    @POST("user_updateLocation.action")
    Single<RSResult<String, String>> updateUserLocation(@Body RQUserLocation rqUserLocation);

    //查询特定群成员信息
    @POST("group_queryMemberInformation.action")
    Single<RSResult<RSUserInfomation,String>> queryMemberInformation(@Body RQMemberInfomation rqMemberInfomation);

    //（六）查看群成员位置信息
    @POST("group_getMemberLocation.action")
    Single<RSResult<List<RSUserLocation>,String>>getMemberLocation(@Body RQGroupInfomation rqGroupInfomation);

    //15.移除指定群成员
    @POST("group_deleteMember.action")
    Single<RSResult<String, String>> deleteMember(@Body RQDeleteMember rqDeleteMember);

    //邮箱验证码请求
    @POST("verification_getBackPasswordRequest.action")
    Single<RSResult<String, String>> requestEmailVerificationCode(@Body Map<Object, Object> emailVerification);

    //3．邮箱验证码验证请求
    @POST("verification_getBackPasswordResponse.action")
    Single<RSResult<String, String>> requestVerificationVerificationCode(@Body Map<Object, Object>
                                                                                 verification);

    //5．重置密码请求
    @POST("user_getBackPassword.action")
    Single<RSResult<String, String>> requestResetPassword(@Body Map<Object, Object> resetPassword);

    //（七）邀请群成员
    @POST("group_inviteMember.action")
    Single<RSResult<String, String>> inviteMember(@Body Map<Object, Object> inviteMember);


    @POST("user_exit.action")
    Single<RSResult<String,String>> exitLogin(@Body RQUserId rqUserId);

    @POST("group_queryAllMember.action")
    Single<RSResult<List<RSUserInfomation>, String>> queryAllMember(@Body Map<Object, Object> groupId);

}
