package com.freely.ui.adapter;

import android.os.Bundle;

import com.freely.data.entities.Group;
import com.freely.ui.fragments.GroupChatMapFragment;
import com.freely.ui.fragments.GroupChatMessageFragment;
import com.freely.component.activity.TitleFragment;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

public class ChatViewPagerAdapter extends FragmentStatePagerAdapter {
    private List<TitleFragment> fragments;
    private long groupId;

    public ChatViewPagerAdapter(FragmentManager fm,long groupId) {
        super(fm);
        this.groupId = groupId;
        fragments = new ArrayList<>();
        GroupChatMessageFragment messageFragment = new GroupChatMessageFragment();
        GroupChatMapFragment mapFragment = new GroupChatMapFragment();
        Bundle bundle = new Bundle();
        bundle.putLong(Group.group_id,groupId);
        messageFragment.setArguments(bundle);
        mapFragment.setArguments(bundle);
        fragments.add(messageFragment);
        fragments.add(mapFragment);
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments == null ? 0 : fragments.size();
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return fragments.get(position).getTitle();
    }
}
