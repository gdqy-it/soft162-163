package com.freely.data.network.webSocket;

import okhttp3.WebSocket;

/**
 * @author DaWan
 * @time 2018/11/29 0:15
 * @dscription
 */
@FunctionalInterface
public interface ClosedListener {
	boolean onClosed(WebSocket webSocket, int code, String reason);
}
