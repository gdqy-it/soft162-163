package com.freely.ui.util;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.freely.component.activity.FreelyApplication;

/**
 * @author DaWan
 * @time 2018/12/8 15:21
 * @dscription
 */
public class AppHint {
	private static final String TAG = "AppHint";
	private static final Handler HANDLER = new Handler(Looper.getMainLooper());

	private AppHint() {

	}

	public static void showToast(String hint) {
		Log.d(TAG, "showToast: " + hint);
		HANDLER.post(() -> {
			Toast.makeText(FreelyApplication.getContext(), hint, Toast.LENGTH_SHORT).show();
		});
	}
}
