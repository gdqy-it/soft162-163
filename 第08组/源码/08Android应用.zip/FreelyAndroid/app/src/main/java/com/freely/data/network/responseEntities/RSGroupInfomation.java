package com.freely.data.network.responseEntities;


import java.util.List;

public class RSGroupInfomation {


    /**
     * group_account : 6110472710
     * group_admin : {"user_id":9,"user_name":"用户13670117","user_phone":"13682686665"}
     * group_forbidden : false
     * group_id : 33
     * group_image : /9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCADgAOADASIAAhEBAxEB/8QAHgABAAICAwEBAQAAAAAAAAAAAAUGAQcDBAgCCQv/xAA8EAABAwMCAwUEBwcFAQAAAAABAAIDBAURBiESEzEHIkFRYQgUMnEjQlKBkbHwM0NicoOTwRUkktHxof/EABoBAQACAwEAAAAAAAAAAAAAAAABBwIDBQb/xAAuEQEAAQMDAwIFAgcAAAAAAAAAAQIDBAUGERIhMUFRBxNhgfCRsRQVJDJCocH/2gAMAwEAAhEDEQA/AP5/6IiAiIgIiICLIBcQ1oLnOIDWgEkknAAA3JJ2AG5KuFr0hV1QbNXPNHCcERAB1S9vq092HPhx8TwQQ6IbEhTwCSAASSQAAMkk7AADcknoFOUWm7vW4c2mMEZ/e1RMLceYYQZXA+BbGWnzW0aC0W+2txS07Wvxh0z/AKSd3zkdkgH7LOFnk0KSQUKm0PGMGsrnu82U0YZj5Sy8ef7TVOw6XskIH+05zh9aeWV5Pzbxtj/BgVgRB04rdQQjEVFSRj+CniaT8yGZPzJK7LY42fDGxv8AKxrfyAX2iD4dHG/4o2O/mY135grrS26gmGJaKkkH8dPE4j5EsyPmCF3EQV+fS9kmB/2nJcfrQyysI+TeN0f4sKgqnQ8ZyaOue3yZUxh+fnLFwY/tOV9RBpyt03d6LLnUxnjH72lJmbjzLABK0DxLow0eagyCCQQQQSCCMEEbEEHcEHqFv9RtfaLfcm4qqdrn4w2Zn0c7flI3BIH2X8TPNpQaRRXC6aQq6UPmoXmshbkmLHDVMb12aO7Njx5fC8nHDEd8VAgtJa4EOBIIIIIIOCCDuCDsQdwUGEREBERAREQEREBERAUlbLVWXWblU0fdaRzZ35EMIPi92Dlx+qxoL3dQOEOIkrFp6e6vE0vFDQsd3pcYdMQd44MjB8nSbtYdhxOBaNq01NBRwsp6aJkMMYw1jBgepJ3LnOO7nuJc47uJO6CKtNgobU1r2ME9Vjv1UoBdnxETd2wt6gcOXkbPe5TiIgIiICIiAiIgIiICIiAiIgKCu1gobq1z3sEFVjuVMQAcTjYTN2EzemeLDwBhj27qdRBpG5WqstU3KqY+64nlTsyYZgPFjsDDgPiY4B7fEYIJjVvmppoKyF9PUxMmhkGHMeMj0IOxa5p3a9pDmndpB3Wqb7p+a1PM0XFNQvdhsmMvhJJAjnwMDphsgw152PC4gEcTPiPHefpHuriIiAiIgIiICsmnrC+6zc6YOZQwuHNcMtMzxvyYyNx4GV43Y04aQ9wIjrRbJbrWMpo8tjHfnlxtFED3j5cbvhjb4uIz3Q4jc9PTw0sMdPAwRxRMDGNHgB4k+LnHLnOO7nEuJJJKD7jjZExkcbGsjY0MYxgDWta0YDWgbAAbABfaIgIiICIiAiIgIiICIiAiIgLBOPAn5brKwc7Y+/GPI+frhD9Pv2j7z6QA58D9/wD7+vDKw5xa3i4SWcRbxZAAcMd3Jx3+oLPiYQWvDX4atrdiPZbX9svaXpzQVJVe4U1ynlqrvcSx8jqCy2+KSruc8bGxua6ofFGKWjErmQe+TU7ZpGMeCfUOse37sa7KLpV6H7GuxDs61NQ2GqltdfrPtBtzNS3DUFZRSGmr6iHhDawQPlbUthqjceRI53OgttDRyUtMX5+frC0to/DrC1fbl7eG6NzYu09t06hGlYmVew7+oZuqZ8Wqb1+1gYONNNddGHbroqy7tyqim31UxHNU8PA/MGcEFpyBh2AdwTvvsQBnB72O8AWgkSFpsVz1Rc6LT1ltlTeLneamKgorZSQGpqK6oqHNiZBFC0OLwQ/jcS3hZE2Sd5bDFM+P35Waf7H/AGo+zHW2puzzQ9H2W9rvZ3an326acsXJFk1FYoIKiWWWit9PRUcbqiQ080cJp6SKWmrORS1klbFX09XFAeyaKDs47OO3P2haulhqLxom0U+mNFSyQQzGhvt9e6knkkjAk5kU0tz03SzzNkDDb5rvBG4R1VVHLrm5HeInv5+378PT4PwXs390bWsRuLF1PZO4cXUdYt7owbFduqnTNBxruXrlirByqeuzqWJas10RYu9UTVcouczRxMeHe3r2b9bdgUmnHatqNPE6oon1sdqtd8pbjd7BI0tLrffKOMiSJ/C/ENbSurLdLJHUUornVdNLGvO69F6kuVw1fcLnd9S11TerreqiWruldXzy1NTWVc2edUSTykSmQvL3x90clnLbC8xhjWaHu1sltVY+mky5hy+CXG0sRJDXeQe0gtkb4PBxlpa450zzETKpNz3tv3te1Gra+Fm4Gh03/l4OPn5VGZkxbtUU0VXa79FFEc36qar82uKotTcm3RXXbpplGIiKXBFlrXOcGtBc5xDWtaCXOcTgAAbkk7ADcnYLCuOj7YKqsfXSt4oaPAiBGzql27T5Hksy/Hg90bh0QXSw2ptqoWRua33mUCWqeMZMhG0fF4siB4G+BdxPABeVNoiAiIgIiICIiAiIgIiICIiAiIgIf/M+fgiwen4eXXO3XbqiJ44nntHE8z7R6vZvsI6httn7cJ7Rcar3GXWuiNQaStNZmKPkXWoq7Ne4eXLM+IMlmgsdVDAGOdNLUPhhjjPMcHeXdc6J1F2f6svuktTUU9DdLNcamjmE0TohUMZK4wV1M57WmopKyMCpp6kBolhljIDmhrlWqSrrLfV0lfQ1M9HW0NVT1VFV00slPU0lVSyiaCpp5oZIZopoZ2RTwvilie2SGMh+ASvaVu9tjUNdaqKg7Uey/s17WK22RiKivuo7JSR3d4HBj3tz6Kvt7jxNaT7nbaNriHyhonmlldjNPM0zz/bz9+eP+xH+12bZ1nZO4tjYuxd56rnbWyNH1rUNZ0bcONp1Wp4Nf82tWKMvG1HEtVRetz/TWK8e/R1xTV1U1UTFXNNk9hy21+iqjtQ7dr9A+i0PpLQF3ts1XPHyobxXy1dvujbdQ893LrnRx2kwzRMyf9QuFvhYJHVnJji/ZJrbZ2haY7cPZ6udZT0lT2k2Rt+0THUzNgp36lsgnr3RtqM5fO11LaK8wPbHzaO1VUjSAcHT/bB7TGvu1u10ml56ey6P0Hb5I5qTRmkqI2y0maJzpIJa7L5pq11O+Rxgh4qe3wuYyeOgFT9M3QFDcK611lHcrZWVVur6CpiraK4UE8tJW0lXBNBPT1VPUwuZLDNDJA18boXxStc5x5oaTG7X8qernq/xmPHjx389/wA9+3qrnxa25tLK2Lt7aFvL3BtjaM61GrZeo40Y1/cVO47VOHrNu3Z5uTg49eBH8NiW6q6rnVTTfq6ZmZiU1PpbUGi79c9N6mtlXabva6iSmq6Krhkhma6N20jTIG82KVhbJDNGDFJE9j4nva5rjN6H7BdddvFXW2PRdqFTVWy3110fdKoijtNE6lo56inpK25yH3aCS7SQNoKaN7mnnysqXtbT00z2eoaH2177dLZS0Hap2U9mXaxWUMTIoL3qOwUEd3kja5z+GpfJQXC3HhdI7PultpWS9x8zHTmSeSr9oHtf681VpubRGjtP6U7JdIVMc8VZadA28W6ruMVTwsmhrLlEKYQU8sIdDJHbKKhkfDI6nllm 2018-11-28 20:28:23.728 2854-2886/com.freely D/OkHttp: pn8oZU0100xTNUTx5q8T5ifH3n17/T0406L8CbeXd165u7cWbp96m5et7Os6RXi631VU9dODe1a5dq0y1aszMUVZlPXXc4iqnHiY4fmlJG+KR8UrHRyRPdHJG8Fr2PY4texzTuHNcCHA7gggr4Vu1bbRS1TK2JpEVYXCUbHhqW7uJIDQOa08QDWMaXskIa0YaKitihJmiZqm3MzR1T0zM0zV089oq6JmnqiOOrpmYieeJACSAASScADcknoAPElbss1ALbbqelwOYG8ycj608mHSb+IacMafstatY6bovfbtTtcMxU5NVLnpwwkFgPmHTGNpB2LSc5GQtxIgREQEREBERAREQEREBERAREQEREBERBjAAwP19/VCAev66f8AX/SyiI4jnniOffjv7fsxj1P44/LH/wATA39dz+v8dFlETxHHHHbzx6c+/DGB+t/z/X4JgFZREcRzzxHM+Z47zx47/RF3i3tuVuqKXA5hbzICfqzx5dGcnOA45Y49eF7lpMggkEEEHBB2II6gjwIXoBad1JRe5Xapa0YjqD71F5YmJLwPABsokaAOjQ1ErPoimxDW1ZH7SSOnYceEbeZJj0JkZn1ar2oDTEPJslGMYdIJZnbdeZK8tJ/p8Az5BT6AiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAqJremzDRVYH7OSSneceEjeZHn0Bjfj1cr2oDU8ImslZtl0QimbtnBjlYXEf0y8Z8ASgk7dGIbfQxDpHSU7PvbEwEn1JyT6kruLjibwRRt+zGxv8AxaB/hciAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAuncYxNb66I/vKSoZ54LoXgH5g4I9Qu4uOVvHFKz7Ub24/maR/lAidxRRu+1Gx34tB/yuRdO3SCa30Mo6SUlO/wC90TCQfUHIPqCu4gIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgLjldwRSO+zG93/ABaT/hci6dxkENvrpT0jpKh/3tieQB6k4A9SgjNMTc6yUZzl0Ylhdv05crw0H+nwHHkVPqiaIqcw1tIT+zkjqGDPhI3lyY9AY2Z9XK9oCIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICgNTzcmyVhzh0gihbvjPMlYHAef0fGceIBU+qHrepxFRUYPxySVEg9I28uPPoTJJ6Zb6BBWNN1vuV2pnOOI6g+6y+XDMQGE+QbKI3E+DQVuNefwSCCCQQcgjYgjoQfAhbss1eLlbqeqyOYW8ucD6s8eGybeAccPaPsuaglEREBERAREQEREBERAREQEREBERAREQEREBERAREQFpzUlb77d6lzTmOnPusXlwwkh5HgQ6YyOBHVpatn3m4C226oqsjmBvLgB+tPJlse22Q3eRwG/Ax3ktJkkkkkkk5JO5JPUk+JKArhpC5ilrH0Ur8Q1mOXk91tS3Zg9Oc3LD5vEQVPWWuc1wc0lrmkOa5pIc1wOQQRuCDuCNwdwg3+ihLDdW3WhZI5zfeYcRVTBsQ8DuyAeDZW94Ed0O42AksKm0BERAREQEREBERAREQEREBERAREQEREBERARFCX66ttVC+Rrm+8zZipWHc8ZHekxvlsLTxkkcJdwMJ74QUrV9zFVWMoon5ho88zB7rql2zx68luGDyeZQqesklxLnEuc4kucSSSSckkncknck7krCAiIgk7Rc5bVWMqY8ujPcniztLET3h5cbfijd4OAz3S4Hc1NUQ1cEVTA8SQzMD2OHkeoI6hzTlrmndrgWkAgrQysmnr6+0zcqYufQzOHMaMudC/pzox+AlYN3tAIBc1oIbcRfEcjJWMkje18b2h7HsIc1zXDIc0jYgjcEL7QEREBERAREQEREBERAREQEREBERARF8SSMiY+SR7WRsaXve8hrWtaMlzidgANySg46mohpIJamd4jhhYXvcfIdAB1LnHDWtG7nENAJIWmbvc5brWPqZMtjHcgiztFECeEeXG74pHeLicd0NAkdQ3192m5UJcyhhceU05BmeNudIPUbRsO7GkkgOc4CtoCIiAiIgIiILJYdQzWp4hm4pqF7sujzl8JPWSHP4vj+F25HC8lx2tT1ENVCyenkZLFIMtew5B8wfEOHRzSA5pyHAEELQqk7Zd6y1S8ymfljj9LA/LoZR/E0EFrgOj2lrh0yW5aQ3aigrVqCgujWsY8QVRHepZSA8nx5TtmzN2JHDh4G72NyFOoCIiAiIgIiICIiAiIgIiICIoO66goLU1zHv59UB3aWIgvBIyOa7dsLdwe9l5ByxjkEtUVENLC+eokZFFGMue84A8gPEuPRrQC5xwGgkgLVN91DNdXmGHihoWO7sWcPmIO0k+Dg77sj3azYnieA4R1zu1ZdZeZUydxpPKgZlsMQ3+FuTl2DgyOJeemQ0BojEBERAREQEREBERAREQZBLSHNJDgQQQSCCDkEEbgg7gjcFW616vrKQNirWmthGAJC7hqWDp8Zy2bA8JMPJ6yqoIg3bQXi33JoNLUNc/GXQP8Ao52+eY3buA8XM42Z6OKk1oAEgggkEEEEHBBG4II3BB6FT1FqW70WGio94jH7uqBmGPISEiYAeAEgaPJBuFFQqbXERwKuhezpl9PI2TPmRHII8fLmuz+c5DqmySgZqzE4/VmhmaR83Bjo/wAHlBYUXQjutslGY7hRu9BUwhw+bS8OH3hdpk8MnwTRPz04JGO/IlByouJ88MfxzRMx145GN/MhdWS62yIZkuFG30NTCXH5NDy4/cEHfRV6bVNkiBxVmVw+rDDM4n5OLGx/i8KDqdcRjIpKF7/J9RK2PHzijEmf7rUF9UZX3i321pNVUNbJjLYGfSTu8sRt3aD4OfwMz1cFrGt1Ld63LTUe7xn93SgwjHkZATMQfEGQtPkoEkkkkkkkkknJJO5JJ3JJ6lBbrpq6rqw6GiaaKE5Bk4uKpeDkfGO7CDnpHl4I2lxkKokkkkkkkkkk5JJ3JJO5JO5J6rCICIiAiIgIiIP/2Q==
     * group_name : asdsadsa
     * group_notice : asdasdasdsadsad
     * group_sum : 1
     * users : [{"user_id":9,"user_image":"/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCADgAOADASIAAhEBAxEB/8QAHAABAAMBAQEBAQAAAAAAAAAAAAUGBwQDCAEL/8QAKxAAAgICAgICAwABBAMBAAAAAQIAAwQRBRITIQYiFCMxMhUkQVIlNWFx/8QAFAEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/AP5/8REBERAREQERLNxXxbP5JUvsKYeLYqutto7WWI/cK9dAZT12qkm56Q1ViW1eVSNhWZKYXC8ryADYmFdZWyNYtz9aKHVH8beO+9qqbGVwylEdn+lh66rcrqvH8BxnGaOPji28H1lZIS68H9nUoxAqocByo8NdZYKpcuy9pLwM8xfg9rdWzM5E/aO1eLU1vekaLdbrTV47T9lAOPaqfVz32Uk5j/EOFqVjbXkZPYjRvyGBrK77Bfxhight+y4b+fXXuWeIEXVwvEUoqDjcIogI3bj1XOR7/wArblexiP8AuzH17H/GvZON46qxXr4/Bqsr062Ji49bKVOgyutYZWUkMWHsD+Gd0QI9+M4yx2sswMKyy2wszWYuOzO7ElmZynd2dlZiSSzlixJBJHnbwvEXo1Z43DCuF91Y9VDgAjXW2lUtUt/3Vh2AJbsCdyk 2018-11-28 20:28:23.728 2854-2886/com.freely D/OkHttp: QKxkfEOEtVDXXkYwBJY497sW7ddKRlfk+lGwhUISSS5I0BBZXwi1ezYWdW+7G6VZVZqK1fYqGuqNosuG61IFFaNtn3WAqtokQMSzOG5TAUvlYV9daqHe5VF1CBrDUve+g2UoWs0oV3DHshA1YhaMn0BIfP+P8XyIJvxVpsLM7ZWIqUX9mas2s7AGq93Knt50tYFnZGR3ZiGLxLNynxbkOOV7qyuZjV1m2yyodLaq1Ffd7aCzHorO22pe8JWjWXGkAgVmAiIgIiICIiAiIgIiICd3H8dl8nkpi4lZexvbOdiqlACWtufRCVqAT/CznSVq9jIjdnD8FmcwzGrVONUwFuTYrFd7UvVSqj9161t5PGWrQDqLbavJWW1vCwMbjaVxMRAlVZJZiFsstYgK72vos72BQzsFVB1VK0rqWsIELwvxrD40Jfci5uYAne11D41FqP5d4oNf6yCqL53JuPjZk/GD21iyxEBERAREQEREBERAREQEREBKxzHxrD5JXyKVXDzAjsj1BBj32M72H8pRWjM7t33eNOgc7GSlK1rZ4gYZyHH5XGZT4mXX0sT2rDZrtr7Mq20uQO9bFWG9BldXrsVLUdF4puudhUclj2Y2VUttTEEFj1aqzTdLKnVSa7FYsUbYVgXrsV63tqbJeY4LM4d1NurcaxmWrJrVgpIewIlysP03OlZsCdnRl7eK20V2FQhIiICIiAiIgJPcBwdvNZLr28eJj9Gy7VK+QK/cpXUrevJb43AsYGqoKzv2bpVbG4GBk8lkpi4qdnb7O7bFdNQID3XMAxSpNjZCszMVrrV7XRG2fC43GwKUw8aoIiDZLdWstsA62W22dCrWv9lZuoVEIrULUiqgdOPRRiY9ePj1JXRUoRa0HX0u2I7HbsWPZnYsz2WE2N3sPZvSIgIiICIiAiIgIiICIiAiIgIiICIiAnnk0UZWPZj5FS2UWqUatx22GAYDsNOrA9XRg6vXYBYvRxtfSIGOc9wdvDZAAY24lxY49p13HXRam4DQFqAghgAlyEWIFPkqqgpuufx+LnY5xMqvvVZsVuOqtVYQOttVmiqWIXBDDuHDN5t12P5cXz8DJ43JfFyk6uv2Rx7ruqJIS6l/49T9SAR7VlatwtiOihxREQERLP8V4peSz2tvrWzEwlW21HXsltr9vBSyh1YghLbz9bK2XHau1CtmiF0+M8OvGYfnvSs5mUqWWOyOr41FldbpjubQGRqyxe9UrTtcVQm0UUvLLEQEREBERAREQEREBERAREQEREBERAREQEREBKz8l4deTw2yKVT83FVrUcVuXyaFRmfGHQEtYx01C9bALQa0KC651s0QPn+JZ/lXFLx2eLqK1qxM0PZSiqEVLaiq5FaVly4r7MlyHx1VAXeGpAKWVaxATY/jvGvxvFUpaGS/I75VynsGR7VrC1FHWoqa6q60srdbHryBkaLVleuYcLgnkeSxcYp3p8gtyQfIF/GqIe4M9Y7V+RR4a3JRfNbWpsr7dxtkBERAREQEREBERAREQEREBERAREQEREBERAREQERECC+SYFnJcXZVWzvdjkZVNXss9tSurVBVSxrWep7UqSsLu/wAILKpJsxyfQExLmcMYHKZuKqqtdd7NSqszhKLQLqE7vtmK02IrFix7A/d/8iFp+D427s7MYWqFrrxUcDVLeRvPcrORrvX4KD6JCrZp13ZWw0SVj4hjrTwqW9yzZN2RkgGtgKijjFCg9tWbOMHNg6qA71EfRnFngIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgJnfzjGAtwcxVs21dmLadfqQ1MLaV2B9bLPNedFtOtR6KPG5OiSsfLscXcLbZ5Ov4l+PeAE9Wsz/AIpUH119ZDWFiPbVldbYkhJ8LXVTxHGpWvRDh49jDZceS+sX2vptns9ru6jsFTZCALoCUnBxOzxPGDegePxB/wAH7fjVaGj/APn2Pv8A4A6+53wEREBERAREQEREBERAREQEREBERAREQEREBERAREQEi+ZRLOJ5JLqw/wDsciwDTEK9NT3VsNEH6XIrqdaHQlwFB3KSP5YN/pXJDY/9dms+uq/b8e0bC6IA3v0OpPoDQHsP3id/6VxeyB/4/D/yJbZONUQSG0FGmA1777OvQ0e+RfC2VXcRxr1t3QYePWx0UHkorFFqbbR7Jajop6lX0ShK6JlICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICcHL6PF8noAhuPzWBBJGjjWsCCdkgaIUE7G/fud8jebsrx+I5JrSADhX1b07r5MilsekfUP7a2xVD76gt9iFVmARPxG8W8LWgrIOLdkY5YknuXcZJZQvXSgZKVtWSR6azsO3SWiZ38HyQLc7DZrNtXXlVDf6kNTGq5tE/WyzzUDYXTrUO7DxoDokBERAREQEREBERAREQEREBERAREQEREBERAREQEREBKv8vyBVwzV9S/5V2Pjg9goqKv8AllgvQ91JoZOoKDs5sB0Ar2iZ383yvvg4Cm5QiWZdqFv0ubW8VDdQ2mtqFeQOxQdFuIrYh3ACrcNmDA5PDymKqldvW1nVnVKblai6zogLMa6rHdVCttlA6ONqdtnz/Nj+O8k/JcVS9pZ78fvi3MexZ3qWsraXdrSxsqsreyx2rezIORoLWF7BOxEQEREBERAREQEREBERAREQEREBERAREQEREBERATEuZzBncnm5KsrVvcUpZA6q9FIFND9bPuC9NaOwIT7s2krGkXUPknIvxvF3PUSLshvxKmVmHjssS0PcCllb1tXSlhpZC4W9ajpqiwmOQEs/xXlBx/IGm2xasXOVabbHIVarkJbGtZwjMqh2apvslai43WnVQIrEQPoCJWvjPMLyeGuPe4/MxUFV6m2w25GMqdVyR3V2LWMVov6u5Fp8zlFvSsWWAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiVj5Jy44vDail0GZmIyIgdxZRVYrrblKFHZGrYeKhjZV2uZrK1dMdkAU75Xyg5DkBRS6vi4AaqpkA6va5U5NisUVivdVpUbasikW1aFrE1eIgIiIHZgZ+TxuSmViv1dfq6Ns13VEgvTcoKl6n0NgMrKwWytktRHXaMLPo5HHqycWzvU4AI11spsAPZLkDaWxGAV1Z9MPHZUz0vW7YXJ7gecu4bIJ01mJcVGRUvUWDWwLqGb0tqAnakhLl+jlWFdtQbFE8sfIoyqasjHsSym1Q6Wp7DBgwcop06spUq6MqvXYjqwVwQPWAiIgIiICIiAiIgIiICIiAiIgIiICInnk5FWLTbkZNi1U1qXsezWlAAAYqPbNYWCIqKXsd1rVWciB4ZvIY/G0W5OVYUoQED6oLrnYDrVQoYM9tmz9A3QIWttZK0sdcXz8/J5LJfKyn7O31RB6rpqBJSmlP4lSdiQB7Zmaxy1ju7SHPc3bzWSrlTXjUGwY1bdTbqzoHtucb3ZYKqx41Y10oiVp2YPbbBQEREBERAREQJ7g+dyOHtK6a7Ctbd+N219tdfNSTsJaF0rAjpcgCWe1qsq1bB5CjksevJxnVkt7F/S+SmwgBq71GzW6M6grsqylHT9bpYcLnbx/IZPGZSZeI4WxPTKwLVXVkgtVamx2rYgH0VdHVLanrurrsQNziVfiPlGFyIoxsgjFzG6IaypFN9zO5Pgt26jfUMtV61sbbvAr5J00tEBERAREQEREBERAREQEREBESscv8pwuP82PR2yc2sdBWpLY1VoUL0ybG6EmvYZ6qFcmyt6LHocl0Cb5HPo46izKyHFdVfUIo6l7rOo1VUP7Y7tWSo7Bdd3tIqVyuUc3z+VzViBwaMWrRrxVsaxfJohrrXYKbbT2ZUZlHjrPRRtrHsj8/kMnksmzKyn7O7Eqi7FVSk7FdKEt0Rf8A6Wdjt7HexnduKAiIgIiICIiAiIgIiICWXiflGfxmq7N5uMCpWu61xbUEr6KmPews8VZ1X2raq1AqaqWpndzWogb 2018-11-28 20:28:23.728 2854-2886/com.freely D/OkHttp: Ngc/xnI68OQKruyhcbIKUXuzM6Iqo7NTcxALAU2XOqlEdkLBJNT5/kvx/O8nxoCY2QTQGUnHuVbqSod3atQ4L0JabH8v4z0u5bsXDqjKG0xM8xfnFo6Lm4KN+xe9uLY1ZWr6glaLRb5LFHZgDk1I56L+vRczmP8u4W1XNluRjFCoUZOOxNwbuSV/E/JAFfUB/I1Z/YvjVwHKBZ4kVTzvEZKl6+Sw1+xQeawYr7ADklco1WFRsdX6+MsOinakD2/1XizoDk+PBb0NZuMSCTrWvMf6PY/v90R61A74ke3L8WT2PJ4Hb+EHMxdkAddMDZ/f7/dMPW/YnhfznEYwFj8liMCwQ+C4ZL7I2f14vmcIQp07L0VuqltuIEvEq+R8u4WpVNdt+SXJBXHx2U1AdTt/yhjqe+yB0ez/E91X0Xg8r5xaey4eBUmrW8dmTY9m6fYXdFRq6Wn6kk5FyoCyff62ANEkNyHP8Xx6uL8hLbQ31x8YJdkBq2rUK4VlShqwws1c1Ibq/jFj7WZfyHO8pyQZMnJbwszMcelVpp0zI4R1rCtctbVoavyGuZCvYN3Z2aIgWTlfk+fySmmr/AGOKewNNFthexHq8T133bU2VFWtHiVK6mWwrYlnRCtbiICIiAiIgIiIH/9k=","user_name":"用户13670117","user_phone":"13682686665"}]
     */

    private String group_account;
    private GroupAdminBean group_admin;
    private boolean group_forbidden;
    private int group_id;
    private String group_image;
    private String group_name;
    private String group_notice;
    private int group_sum;
    private List<UsersBean> users;

    public String getGroup_account() {
        return group_account;
    }

    public void setGroup_account(String group_account) {
        this.group_account = group_account;
    }

    public GroupAdminBean getGroup_admin() {
        return group_admin;
    }

    public void setGroup_admin(GroupAdminBean group_admin) {
        this.group_admin = group_admin;
    }

    public boolean isGroup_forbidden() {
        return group_forbidden;
    }

    public void setGroup_forbidden(boolean group_forbidden) {
        this.group_forbidden = group_forbidden;
    }

    public int getGroup_id() {
        return group_id;
    }

    public void setGroup_id(int group_id) {
        this.group_id = group_id;
    }

    public String getGroup_image() {
        return group_image;
    }

    public void setGroup_image(String group_image) {
        this.group_image = group_image;
    }

    public String getGroup_name() {
        return group_name;
    }

    public void setGroup_name(String group_name) {
        this.group_name = group_name;
    }

    public String getGroup_notice() {
        return group_notice;
    }

    public void setGroup_notice(String group_notice) {
        this.group_notice = group_notice;
    }

    public int getGroup_sum() {
        return group_sum;
    }

    public void setGroup_sum(int group_sum) {
        this.group_sum = group_sum;
    }

    public List<UsersBean> getUsers() {
        return users;
    }

    public void setUsers(List<UsersBean> users) {
        this.users = users;
    }

    public static class GroupAdminBean {
        /**
         * user_id : 9
         * user_name : 用户13670117
         * user_phone : 13682686665
         */

        private int user_id;
        private String user_name;
        private String user_phone;

        public int getUser_id() {
            return user_id;
        }

        public void setUser_id(int user_id) {
            this.user_id = user_id;
        }

        public String getUser_name() {
            return user_name;
        }

        public void setUser_name(String user_name) {
            this.user_name = user_name;
        }

        public String getUser_phone() {
            return user_phone;
        }

        public void setUser_phone(String user_phone) {
            this.user_phone = user_phone;
        }
    }

    public static class UsersBean {
        /**
         * user_id : 9
         * user_image : /9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCADgAOADASIAAhEBAxEB/8QAHAABAAMBAQEBAQAAAAAAAAAAAAUGBwQDCAEL/8QAKxAAAgICAgICAwABBAMBAAAAAQIAAwQRBRITIQYiFCMxMhUkQVIlNWFx/8QAFAEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/AP5/8REBERAREQERLNxXxbP5JUvsKYeLYqutto7WWI/cK9dAZT12qkm56Q1ViW1eVSNhWZKYXC8ryADYmFdZWyNYtz9aKHVH8beO+9qqbGVwylEdn+lh66rcrqvH8BxnGaOPji28H1lZIS68H9nUoxAqocByo8NdZYKpcuy9pLwM8xfg9rdWzM5E/aO1eLU1vekaLdbrTV47T9lAOPaqfVz32Uk5j/EOFqVjbXkZPYjRvyGBrK77Bfxhight+y4b+fXXuWeIEXVwvEUoqDjcIogI3bj1XOR7/wArblexiP8AuzH17H/GvZON46qxXr4/Bqsr062Ji49bKVOgyutYZWUkMWHsD+Gd0QI9+M4yx2sswMKyy2wszWYuOzO7ElmZynd2dlZiSSzlixJBJHnbwvEXo1Z43DCuF91Y9VDgAjXW2lUtUt/3Vh2AJbsCdyk 2018-11-28 20:28:23.728 2854-2886/com.freely D/OkHttp: QKxkfEOEtVDXXkYwBJY497sW7ddKRlfk+lGwhUISSS5I0BBZXwi1ezYWdW+7G6VZVZqK1fYqGuqNosuG61IFFaNtn3WAqtokQMSzOG5TAUvlYV9daqHe5VF1CBrDUve+g2UoWs0oV3DHshA1YhaMn0BIfP+P8XyIJvxVpsLM7ZWIqUX9mas2s7AGq93Knt50tYFnZGR3ZiGLxLNynxbkOOV7qyuZjV1m2yyodLaq1Ffd7aCzHorO22pe8JWjWXGkAgVmAiIgIiICIiAiIgIiICd3H8dl8nkpi4lZexvbOdiqlACWtufRCVqAT/CznSVq9jIjdnD8FmcwzGrVONUwFuTYrFd7UvVSqj9161t5PGWrQDqLbavJWW1vCwMbjaVxMRAlVZJZiFsstYgK72vos72BQzsFVB1VK0rqWsIELwvxrD40Jfci5uYAne11D41FqP5d4oNf6yCqL53JuPjZk/GD21iyxEBERAREQEREBERAREQEREBKxzHxrD5JXyKVXDzAjsj1BBj32M72H8pRWjM7t33eNOgc7GSlK1rZ4gYZyHH5XGZT4mXX0sT2rDZrtr7Mq20uQO9bFWG9BldXrsVLUdF4puudhUclj2Y2VUttTEEFj1aqzTdLKnVSa7FYsUbYVgXrsV63tqbJeY4LM4d1NurcaxmWrJrVgpIewIlysP03OlZsCdnRl7eK20V2FQhIiICIiAiIgJPcBwdvNZLr28eJj9Gy7VK+QK/cpXUrevJb43AsYGqoKzv2bpVbG4GBk8lkpi4qdnb7O7bFdNQID3XMAxSpNjZCszMVrrV7XRG2fC43GwKUw8aoIiDZLdWstsA62W22dCrWv9lZuoVEIrULUiqgdOPRRiY9ePj1JXRUoRa0HX0u2I7HbsWPZnYsz2WE2N3sPZvSIgIiICIiAiIgIiICIiAiIgIiICIiAnnk0UZWPZj5FS2UWqUatx22GAYDsNOrA9XRg6vXYBYvRxtfSIGOc9wdvDZAAY24lxY49p13HXRam4DQFqAghgAlyEWIFPkqqgpuufx+LnY5xMqvvVZsVuOqtVYQOttVmiqWIXBDDuHDN5t12P5cXz8DJ43JfFyk6uv2Rx7ruqJIS6l/49T9SAR7VlatwtiOihxREQERLP8V4peSz2tvrWzEwlW21HXsltr9vBSyh1YghLbz9bK2XHau1CtmiF0+M8OvGYfnvSs5mUqWWOyOr41FldbpjubQGRqyxe9UrTtcVQm0UUvLLEQEREBERAREQEREBERAREQEREBERAREQEREBKz8l4deTw2yKVT83FVrUcVuXyaFRmfGHQEtYx01C9bALQa0KC651s0QPn+JZ/lXFLx2eLqK1qxM0PZSiqEVLaiq5FaVly4r7MlyHx1VAXeGpAKWVaxATY/jvGvxvFUpaGS/I75VynsGR7VrC1FHWoqa6q60srdbHryBkaLVleuYcLgnkeSxcYp3p8gtyQfIF/GqIe4M9Y7V+RR4a3JRfNbWpsr7dxtkBERAREQEREBERAREQEREBERAREQEREBERAREQERECC+SYFnJcXZVWzvdjkZVNXss9tSurVBVSxrWep7UqSsLu/wAILKpJsxyfQExLmcMYHKZuKqqtdd7NSqszhKLQLqE7vtmK02IrFix7A/d/8iFp+D427s7MYWqFrrxUcDVLeRvPcrORrvX4KD6JCrZp13ZWw0SVj4hjrTwqW9yzZN2RkgGtgKijjFCg9tWbOMHNg6qA71EfRnFngIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgJnfzjGAtwcxVs21dmLadfqQ1MLaV2B9bLPNedFtOtR6KPG5OiSsfLscXcLbZ5Ov4l+PeAE9Wsz/AIpUH119ZDWFiPbVldbYkhJ8LXVTxHGpWvRDh49jDZceS+sX2vptns9ru6jsFTZCALoCUnBxOzxPGDegePxB/wAH7fjVaGj/APn2Pv8A4A6+53wEREBERAREQEREBERAREQEREBERAREQEREBERAREQEi+ZRLOJ5JLqw/wDsciwDTEK9NT3VsNEH6XIrqdaHQlwFB3KSP5YN/pXJDY/9dms+uq/b8e0bC6IA3v0OpPoDQHsP3id/6VxeyB/4/D/yJbZONUQSG0FGmA1777OvQ0e+RfC2VXcRxr1t3QYePWx0UHkorFFqbbR7Jajop6lX0ShK6JlICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICcHL6PF8noAhuPzWBBJGjjWsCCdkgaIUE7G/fud8jebsrx+I5JrSADhX1b07r5MilsekfUP7a2xVD76gt9iFVmARPxG8W8LWgrIOLdkY5YknuXcZJZQvXSgZKVtWSR6azsO3SWiZ38HyQLc7DZrNtXXlVDf6kNTGq5tE/WyzzUDYXTrUO7DxoDokBERAREQEREBERAREQEREBERAREQEREBERAREQEREBKv8vyBVwzV9S/5V2Pjg9goqKv8AllgvQ91JoZOoKDs5sB0Ar2iZ383yvvg4Cm5QiWZdqFv0ubW8VDdQ2mtqFeQOxQdFuIrYh3ACrcNmDA5PDymKqldvW1nVnVKblai6zogLMa6rHdVCttlA6ONqdtnz/Nj+O8k/JcVS9pZ78fvi3MexZ3qWsraXdrSxsqsreyx2rezIORoLWF7BOxEQEREBERAREQEREBERAREQEREBERAREQEREBERATEuZzBncnm5KsrVvcUpZA6q9FIFND9bPuC9NaOwIT7s2krGkXUPknIvxvF3PUSLshvxKmVmHjssS0PcCllb1tXSlhpZC4W9ajpqiwmOQEs/xXlBx/IGm2xasXOVabbHIVarkJbGtZwjMqh2apvslai43WnVQIrEQPoCJWvjPMLyeGuPe4/MxUFV6m2w25GMqdVyR3V2LWMVov6u5Fp8zlFvSsWWAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiVj5Jy44vDail0GZmIyIgdxZRVYrrblKFHZGrYeKhjZV2uZrK1dMdkAU75Xyg5DkBRS6vi4AaqpkA6va5U5NisUVivdVpUbasikW1aFrE1eIgIiIHZgZ+TxuSmViv1dfq6Ns13VEgvTcoKl6n0NgMrKwWytktRHXaMLPo5HHqycWzvU4AI11spsAPZLkDaWxGAV1Z9MPHZUz0vW7YXJ7gecu4bIJ01mJcVGRUvUWDWwLqGb0tqAnakhLl+jlWFdtQbFE8sfIoyqasjHsSym1Q6Wp7DBgwcop06spUq6MqvXYjqwVwQPWAiIgIiICIiAiIgIiICIiAiIgIiICInnk5FWLTbkZNi1U1qXsezWlAAAYqPbNYWCIqKXsd1rVWciB4ZvIY/G0W5OVYUoQED6oLrnYDrVQoYM9tmz9A3QIWttZK0sdcXz8/J5LJfKyn7O31RB6rpqBJSmlP4lSdiQB7Zmaxy1ju7SHPc3bzWSrlTXjUGwY1bdTbqzoHtucb3ZYKqx41Y10oiVp2YPbbBQEREBERAREQJ7g+dyOHtK6a7Ctbd+N219tdfNSTsJaF0rAjpcgCWe1qsq1bB5CjksevJxnVkt7F/S+SmwgBq71GzW6M6grsqylHT9bpYcLnbx/IZPGZSZeI4WxPTKwLVXVkgtVamx2rYgH0VdHVLanrurrsQNziVfiPlGFyIoxsgjFzG6IaypFN9zO5Pgt26jfUMtV61sbbvAr5J00tEBERAREQEREBERAREQEREBESscv8pwuP82PR2yc2sdBWpLY1VoUL0ybG6EmvYZ6qFcmyt6LHocl0Cb5HPo46izKyHFdVfUIo6l7rOo1VUP7Y7tWSo7Bdd3tIqVyuUc3z+VzViBwaMWrRrxVsaxfJohrrXYKbbT2ZUZlHjrPRRtrHsj8/kMnksmzKyn7O7Eqi7FVSk7FdKEt0Rf8A6Wdjt7HexnduKAiIgIiICIiAiIgIiICWXiflGfxmq7N5uMCpWu61xbUEr6KmPews8VZ1X2raq1AqaqWpndzWogb 2018-11-28 20:28:23.728 2854-2886/com.freely D/OkHttp: Ngc/xnI68OQKruyhcbIKUXuzM6Iqo7NTcxALAU2XOqlEdkLBJNT5/kvx/O8nxoCY2QTQGUnHuVbqSod3atQ4L0JabH8v4z0u5bsXDqjKG0xM8xfnFo6Lm4KN+xe9uLY1ZWr6glaLRb5LFHZgDk1I56L+vRczmP8u4W1XNluRjFCoUZOOxNwbuSV/E/JAFfUB/I1Z/YvjVwHKBZ4kVTzvEZKl6+Sw1+xQeawYr7ADklco1WFRsdX6+MsOinakD2/1XizoDk+PBb0NZuMSCTrWvMf6PY/v90R61A74ke3L8WT2PJ4Hb+EHMxdkAddMDZ/f7/dMPW/YnhfznEYwFj8liMCwQ+C4ZL7I2f14vmcIQp07L0VuqltuIEvEq+R8u4WpVNdt+SXJBXHx2U1AdTt/yhjqe+yB0ez/E91X0Xg8r5xaey4eBUmrW8dmTY9m6fYXdFRq6Wn6kk5FyoCyff62ANEkNyHP8Xx6uL8hLbQ31x8YJdkBq2rUK4VlShqwws1c1Ibq/jFj7WZfyHO8pyQZMnJbwszMcelVpp0zI4R1rCtctbVoavyGuZCvYN3Z2aIgWTlfk+fySmmr/AGOKewNNFthexHq8T133bU2VFWtHiVK6mWwrYlnRCtbiICIiAiIgIiIH/9k=
         * user_name : 用户13670117
         * user_phone : 13682686665
         */

        private int user_id;
        private String user_image;
        private String user_name;
        private String user_phone;

        public int getUser_id() {
            return user_id;
        }

        public void setUser_id(int user_id) {
            this.user_id = user_id;
        }

        public String getUser_image() {
            return user_image;
        }

        public void setUser_image(String user_image) {
            this.user_image = user_image;
        }

        public String getUser_name() {
            return user_name;
        }

        public void setUser_name(String user_name) {
            this.user_name = user_name;
        }

        public String getUser_phone() {
            return user_phone;
        }

        public void setUser_phone(String user_phone) {
            this.user_phone = user_phone;
        }
    }
}
