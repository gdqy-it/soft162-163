package com.freely.data.repository.entities;

import com.freely.data.entities.ChatRecord;
import com.freely.data.entities.User;

import java.util.Date;

import androidx.room.ColumnInfo;

/**
 * @author DaWan
 * @time 2018/11/24 12:21
 * @dscription 群聊界面消息项
 */
public class GroupChatMessage {
    @ColumnInfo(name = ChatRecord.record_id)
    private long recordId;
    @ColumnInfo(name = User.user_id)
    private long userId;
    @ColumnInfo(name = User.user_name)
    private String userName;
    @ColumnInfo(name = User.user_image)
    private String userHeadIcon;
    @ColumnInfo(name = ChatRecord.record_content)
    private String message;
    @ColumnInfo(name = ChatRecord.record_send_time)
    private Date time;

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserHeadIcon() {
        return userHeadIcon;
    }

    public void setUserHeadIcon(String userHeadIcon) {
        this.userHeadIcon = userHeadIcon;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getRecordId() {
        return recordId;
    }

    public void setRecordId(long recordId) {
        this.recordId = recordId;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }
}
