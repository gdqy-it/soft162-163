package com.freely.ui.adapter

import android.text.Editable
import android.text.TextWatcher

/**
 * @author DaWan
 * @time 2018/12/10 19:52
 * @description
 */
open class TextWatcher :TextWatcher {
    override fun afterTextChanged(s: Editable?) {
    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
    }
}