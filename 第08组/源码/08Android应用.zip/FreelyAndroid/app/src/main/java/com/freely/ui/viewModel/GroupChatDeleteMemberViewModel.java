package com.freely.ui.viewModel;

import android.util.Log;

import com.freely.component.BaseViewModel;
import com.freely.data.network.FreelyClient;
import com.freely.data.network.requestEntities.RQDeleteMember;
import com.freely.data.network.responseEntities.RSResult;
import com.freely.ui.util.ErrorUtil;


import io.reactivex.Single;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class GroupChatDeleteMemberViewModel extends BaseViewModel {

    private static final String TAG = "GroupChatDeleteMemberVi";
    
    public void deleteMember(RQDeleteMember rqDeleteMember){
        Single<RSResult<String, String>> single = FreelyClient.getFreelyService().deleteMember(rqDeleteMember);
        Disposable disposable = single
                .subscribeOn(Schedulers.io())
                .subscribe(
                        stringRSResult -> {
                            if (!stringRSResult.isResult()) {
                                Log.e(TAG, "deleteMember: "+"failed");
                                return;
                            }
                            Log.e(TAG, "deleteMember: "+stringRSResult.getSuccess() );
                            //服务器处理成功
                            Log.e(TAG, "deleteMember: "+"移除" );
                        }, throwable -> {
                            //应答失败
                            ErrorUtil.errorHint(throwable);
                        }
                );
        register(disposable);
    }
}
