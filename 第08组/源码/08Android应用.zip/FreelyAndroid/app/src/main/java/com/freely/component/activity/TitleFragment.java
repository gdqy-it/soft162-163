package com.freely.component.activity;

public abstract class TitleFragment extends FreelyBaseFragment {

    public abstract CharSequence getTitle();

}
