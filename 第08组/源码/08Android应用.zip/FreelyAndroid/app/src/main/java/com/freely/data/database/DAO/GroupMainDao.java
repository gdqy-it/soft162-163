package com.freely.data.database.DAO;


import com.freely.data.entities.GroupMain;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Update;

@Dao
public interface GroupMainDao {

/*
    @Query("SELECT * FROM group_Main " +
            "INNER JOIN user_group_relation ON user_group_relation.group_id = group_id"  +
            " WHERE user_group_relation.user_id LIKE :userId")
    List<GroupMain> getGroupDetailByUserId(long userId);
*/

    @Insert
    void insertGroup(GroupMain... groupMains);

    @Update
    void updateGroup(GroupMain... groupMains);

    @Delete
    void deleteGroup(GroupMain... groupMains);


}
