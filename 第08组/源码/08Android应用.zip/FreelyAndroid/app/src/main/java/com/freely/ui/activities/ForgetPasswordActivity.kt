package com.freely.ui.activities

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProviders
import com.freely.R
import com.freely.component.activity.NavigationActivity
import com.freely.ui.util.DataVerification
import com.freely.ui.util.VerificationUtil

import android.util.Log
import com.freely.ui.viewModel.ForgetPasswordViewModel
import kotlinx.android.synthetic.main.activity_reset_password.*

class ForgetPasswordActivity : NavigationActivity() {
    val TAG = "ForgetPasswordActivity"
    lateinit var viewModel : ForgetPasswordViewModel;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reset_password)
        viewModel = ViewModelProviders.of(this).get(ForgetPasswordViewModel::class.java)

        Log.d(TAG, "onCreate:viewModel = $viewModel")
        get_verification_code.setOnClickListener {
            val a = 10
            val b = a
        }


    }

    companion object {
        fun startActivity(context: Context) {
            val intent = Intent(context, ForgetPasswordActivity::class.java)
            context.startActivity(intent)
        }
    }
}
