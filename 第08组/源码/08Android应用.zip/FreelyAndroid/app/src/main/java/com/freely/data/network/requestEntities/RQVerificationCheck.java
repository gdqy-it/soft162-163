package com.freely.data.network.requestEntities;

import com.freely.FR;
import com.google.gson.annotations.SerializedName;

public class RQVerificationCheck implements BaseRQEntity {
    @SerializedName(FR.DEVICE_CODE)
    private String deviceCode;
    @SerializedName(FR.VERIFICATION_CODE)
    private String verificationCode;

    public RQVerificationCheck(String deviceCode, String verificationCode) {
        this.deviceCode = deviceCode;
        this.verificationCode = verificationCode;
    }

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public String getVerificationCode() {
        return verificationCode;
    }

    public void setVerificationCode(String verificationCode) {
        this.verificationCode = verificationCode;
    }
}
