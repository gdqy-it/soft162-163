package com.freely.ui.viewModel;

import android.content.Context;
import android.util.Log;

import com.freely.component.BaseViewModel;
import com.freely.component.activity.NavigationActivity;
import com.freely.data.database.FreelyDatabase;
import com.freely.data.entities.Group;
import com.freely.data.entities.User;
import com.freely.data.network.FreelyClient;
import com.freely.data.network.responseEntities.RSResult;
import com.freely.ui.activities.GroupInformationEditActivity;
import com.freely.ui.util.ErrorUtil;

import androidx.lifecycle.MutableLiveData;
import io.reactivex.Single;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class GroupEditViewModel extends BaseViewModel {
    private MutableLiveData<Group> groupInformation;
    private Context context;

    public GroupEditViewModel(Context context){
        this.context=context;
        groupInformation = new MutableLiveData<>();
    }
    public GroupEditViewModel() {
        groupInformation = new MutableLiveData<>();
    }
    public void loadGroupInformation(long groupId){
        Single<Group> groupSingle = FreelyDatabase.getInstance()
                .groupDAO()
                .getGroupByGroupId(groupId);
        Disposable disposable = groupSingle.subscribeOn(Schedulers.io())
                .subscribe(group -> {
                    groupInformation.postValue(group);
                },ErrorUtil::errorHint);
        register(disposable);
    }

    public MutableLiveData<Group> getGroupInformation() {
        return groupInformation;
    }

    public void updateGroupInformation(Group updateGroup) {
        Single<RSResult<String, String>> resultSingle = FreelyClient
                .getFreelyService()
                .updateGroupInformation(updateGroup);
        Disposable disposable = resultSingle
                .subscribeOn(Schedulers.io())
                .subscribe(
                        groupStringRSResult -> {
                            //应答成功
                            //服务器处理失败
                            if (!groupStringRSResult.isResult()) {
                                return;
                            }
                            //服务器处理成功
                            groupStringRSResult.getSuccess();
                            Group localGroup = groupInformation.getValue();
                           if(updateGroup.getGroupName() != null){
                               localGroup.setGroupName(updateGroup.getGroupName());
                           }
                           if(updateGroup.getGroupNotice() != null){
                               localGroup.setGroupNotice(updateGroup.getGroupNotice());
                           }
                           if(updateGroup.getGroupImage() != null){
                               localGroup.setGroupImage(updateGroup.getGroupImage());
                           }

                            FreelyDatabase.getInstance().groupDAO().updateGroupInformation(localGroup.getGroupId(),
                                    localGroup.getGroupName(),localGroup.getGroupNotice(),localGroup.getGroupImage());
                            this.groupInformation.postValue(localGroup);
                            ((NavigationActivity)context).finish();
                        }, throwable -> {
                            //应答失败
                            ErrorUtil.errorHint(throwable);
                        }
                );

        register(disposable);
    }
}
