package com.freely.data.database.DAO;

import com.freely.data.entities.UserGroupRelation;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface UserGroupRelationDAO {

    @Insert
    void insertUserGroupRelation(UserGroupRelation... relation);

    @Insert
    void insertUserGroupRelation(List<UserGroupRelation> relations);

    @Update
    void updateUserGroupRelation(UserGroupRelation... relations);

    @Update
    void updateUserGroupRelation(List<UserGroupRelation> relations);

    @Delete
    void deleteUserGroupRelation(UserGroupRelation... relations);

    @Delete
    void deleteUserGroupRelation(List<UserGroupRelation> relations);

    @Query("delete from user_group_relation")
    void clearAllRelation();
}
