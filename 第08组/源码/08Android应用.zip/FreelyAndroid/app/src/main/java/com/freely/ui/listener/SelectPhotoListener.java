package com.freely.ui.listener;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class SelectPhotoListener implements View.OnClickListener {
    private final static int SELECT_PIC=888;
    private Context context;
    public SelectPhotoListener(Context context){
        this.context = context;
    }
    @Override
    public void onClick(View view) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        ((AppCompatActivity)context).startActivityForResult(intent, SELECT_PIC);
    }
}
