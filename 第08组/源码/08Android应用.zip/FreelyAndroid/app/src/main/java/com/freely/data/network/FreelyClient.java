package com.freely.data.network;

import android.util.Log;

import com.freely.data.adapter.GsonDateAdapter;
import com.freely.data.adapter.GsonGroupAdapter;
import com.freely.data.adapter.GsonGroupChatMessageAdapter;
import com.freely.data.adapter.GsonMessageAdapter;
import com.freely.data.entities.ChatRecord;
import com.freely.data.entities.Group;
import com.freely.data.entities.Message;
import com.freely.data.managerUtils.FreelySharedPreferences;
import com.freely.data.network.requestAPI.FreelyService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.Date;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.WebSocket;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class FreelyClient {

    private static final String TAG = "FreelyClient";
    private static final String FREELY_HOST = "http://172.17.147.200:8080/Freely/";
    private static final String WEB_SOCKET_HOST = "ws://172.17.147.200:8080/Freely/myWebSocket";
    private static OkHttpClient freelyOkHttp;
    private static Retrofit freelyRetrofit;
    private static FreelyService freelyService;
    private static Gson gson;
    private static WebSocket webSocket;
    private static FreelyWebSocketManager webSocketManager;

    static {
        OkHttpClient.Builder okBuilder = new OkHttpClient.Builder();
        freelyOkHttp = okBuilder
                .addInterceptor(new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
                .build();


        webSocketManager = new FreelyWebSocketManager();

        gson = new GsonBuilder()
                .registerTypeAdapter(Date.class, new GsonDateAdapter())
                .registerTypeAdapter(Message.class, new GsonMessageAdapter())
                .registerTypeAdapter(ChatRecord.class, new GsonGroupChatMessageAdapter())
                .registerTypeAdapter(Group.class, new GsonGroupAdapter())
                .create();

        Retrofit.Builder retrofitBuilder = new Retrofit.Builder()
                .client(freelyOkHttp)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .baseUrl(FREELY_HOST);
        freelyRetrofit = retrofitBuilder.build();

        freelyService = freelyRetrofit.create(FreelyService.class);
    }

    private FreelyClient() { }

    public static OkHttpClient getFreelyOkHttp() {
        return freelyOkHttp;
    }

    public static Retrofit getFreelyRetrofit() {
        return freelyRetrofit;
    }

    public static FreelyService getFreelyService() {
        return freelyService;
    }

    public static void connectionWebSocket() {
        String webSocketURL = WEB_SOCKET_HOST + "?user_id=" + FreelySharedPreferences.getInstance()
                .getUserId();
        webSocket = freelyOkHttp.newWebSocket(
                new Request.Builder().url(webSocketURL).build(),
                webSocketManager
        );

    }

    public static void send(String text) {
        Log.d(TAG, "send: " + text);
        if (webSocket == null) {
            throw new RuntimeException("webSocket is null");
        }
        webSocket.send(text);
    }

    public static FreelyWebSocketManager getWebSocketManager() {
        return webSocketManager;
    }

    public static WebSocket getWebSocket() {
        return webSocket;
    }

    public static Gson getGson() {
        return gson;
    }
}
