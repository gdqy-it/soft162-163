package com.freely.data.network.requestEntities;

public class RQDeleteMember {
    private long group_id;
    private long user_id;
    private long 	group_admin;

    public RQDeleteMember(long group_id, long user_id, long group_admin) {
        this.group_id = group_id;
        this.user_id = user_id;
        this.group_admin = group_admin;
    }

    public long getGroup_id() {
        return group_id;
    }

    public void setGroup_id(long group_id) {
        this.group_id = group_id;
    }

    public long getUser_id() {
        return user_id;
    }

    public void setUser_id(long user_id) {
        this.user_id = user_id;
    }

    public long getGroup_admin() {
        return group_admin;
    }

    public void setGroup_admin(long group_admin) {
        this.group_admin = group_admin;
    }
}
