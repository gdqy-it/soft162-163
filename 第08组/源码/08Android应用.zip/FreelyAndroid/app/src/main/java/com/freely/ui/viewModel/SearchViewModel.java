package com.freely.ui.viewModel;

import com.freely.component.BaseViewModel;
import com.freely.data.database.FreelyDatabase;
import com.freely.data.entities.Group;
import com.freely.ui.util.ErrorUtil;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import io.reactivex.Single;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * @author DaWan
 * @time 2018/11/27 9:46
 * @dscription
 */
public class SearchViewModel extends BaseViewModel {
    private MutableLiveData<List<Group>> groupList;

    public SearchViewModel() {
        this.groupList = new MutableLiveData<>();
    }

    public void loadSearchResultList(@NonNull String keyword) {
		Single<List<Group>> single = FreelyDatabase
				.getInstance()
				.groupDAO()
				.queryGroupsByKeyword(keyword);
		Disposable disposable = single
				.subscribeOn(Schedulers.io())
				.subscribe(groups -> {
					groupList.postValue(groups);
				},ErrorUtil::errorHint);
		register(disposable);
    }

	public MutableLiveData<List<Group>> getGroupList() {
		return groupList;
	}
}
