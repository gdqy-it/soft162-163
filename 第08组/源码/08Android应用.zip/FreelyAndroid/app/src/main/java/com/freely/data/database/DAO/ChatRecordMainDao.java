package com.freely.data.database.DAO;

import com.freely.data.entities.ChatRecord;
import com.freely.data.entities.ChatRecordMain;
import com.freely.data.entities.GroupMain;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface ChatRecordMainDao {
    @Query("SELECT * FROM chat_record_main  " +

            " WHERE group_id LIKE :groupId")
    List<ChatRecordMain> getChatRecordMainByUserId(long groupId);

    @Insert
    public void insertChatRecord(ChatRecordMain... chatRecordMains);

    @Update
    public void updateChatRecord(ChatRecordMain... chatRecordMains);

    @Delete
    public void deleteChatRecord(ChatRecordMain... chatRecordMains);
}
