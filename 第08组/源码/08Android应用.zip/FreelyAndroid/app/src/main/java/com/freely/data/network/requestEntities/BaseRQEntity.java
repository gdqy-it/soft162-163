package com.freely.data.network.requestEntities;

public interface BaseRQEntity {
}
