package com.freely.data.entities;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import io.reactivex.annotations.NonNull;

/*
        字段          	类型      	键       	    是否为空    	备注
        user_group_id	bigint  	primary key 	not null	普通用户_群组关联id
        group_id    	bigint  	foreign key 	not null	群id
        user_id     	bigint  	foreign key 	not null	普通用户id
*/
@Entity(tableName = "user_group_relation")
public class UserGroupRelation {
    @Ignore
    public static final String user_group_id = "user_group_id";


    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = UserGroupRelation.user_group_id)
    @NonNull
    private long userGroupId;//普通用户_群组关联id

    @ColumnInfo(name = Group.group_id)
    private long groupId;//群id

    @ColumnInfo(name = User.user_id)
    private long userId;//普通用户id

    public static String getUser_group_id() {
        return user_group_id;
    }

    public long getUserGroupId() {
        return userGroupId;
    }

    public void setUserGroupId(long userGroupId) {
        this.userGroupId = userGroupId;
    }

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }
}
