package com.freely.data.entities;

import com.google.gson.annotations.SerializedName;

import java.util.Date;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

/*
        字段              	类型	            键           	是否为空    	备注
        group_id        	bigint      	primary key 	not null	群id
        user_id         	bigint        	foreign key 	not null	群主id
        group_account   	varchar(10)	                	not null	群帐号id
        group_name      	varchar(16)	                	not null	群名称
        group_sum       	Int                     		not null	群人数
        group_image     	varchar(50)             		not null	群头像
        group_create_date	Timestamp	                	not null	群创建日期
        group_notice    	varchar(100)                    			群公告
        group_forbidden 	bool                    		not null	是否禁用
*/

@Entity(tableName = "chat_group")
public class Group {
    @Ignore
    public static final String group_id = "group_id";
    @Ignore
    public static final String group_admin = "group_admin";
    @Ignore
    public static final String group_account = "group_account";
    @Ignore
    public static final String group_name = "group_name";
    @Ignore
    public static final String group_sum = "group_sum";
    @Ignore
    public static final String group_image = "group_image";
    @Ignore
    public static final String group_create_date = "group_create_date";
    @Ignore
    public static final String group_notice = "group_notice";
    @Ignore
    public static final String group_forbidden = "group_forbidden";

    @PrimaryKey
    @ColumnInfo(name = Group.group_id)
    @SerializedName(Group.group_id)
    private long groupId;//群id

    @ForeignKey(
            entity = User.class,
            parentColumns = User.user_id,
            childColumns = Group.group_admin,
            onDelete = ForeignKey.CASCADE,
            onUpdate = ForeignKey.CASCADE
    )
    @ColumnInfo(name = Group.group_admin)
    @SerializedName(Group.group_admin)
    private long groupAdmin;//群主id

    @ColumnInfo(name = Group.group_account)
    @SerializedName(Group.group_account)
    private String groupAccount;//群帐号id

    @ColumnInfo(name = Group.group_name)
    @SerializedName(Group.group_name)
    private String groupName;//群名称

    @ColumnInfo(name = Group.group_sum)
    @SerializedName(Group.group_sum)
    private int groupSum;//群人数

    @ColumnInfo(name = Group.group_image)
    @SerializedName(Group.group_image)
    private String groupImage;//群头像

    @ColumnInfo(name = Group.group_create_date)
    @SerializedName(Group.group_create_date)
    private Date groupCreateDate;//群创建日期

    @ColumnInfo(name = Group.group_notice)
    @SerializedName(Group.group_notice)
    private String groupNotice;//群公告

    @ColumnInfo(name = Group.group_forbidden)
    @SerializedName(Group.group_forbidden)
    private boolean groupForbidden;//是否禁用

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }

    public long getGroupAdmin() {
        return groupAdmin;
    }

    public void setGroupAdmin(long groupAdmin) {
        this.groupAdmin = groupAdmin;
    }

    public String getGroupAccount() {
        return groupAccount;
    }

    public void setGroupAccount(String groupAccount) {
        this.groupAccount = groupAccount;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public int getGroupSum() {
        return groupSum;
    }

    public void setGroupSum(int groupSum) {
        this.groupSum = groupSum;
    }

    public String getGroupImage() {
        return groupImage;
    }

    public void setGroupImage(String groupImage) {
        this.groupImage = groupImage;
    }

    public Date getGroupCreateDate() {
        return groupCreateDate;
    }

    public void setGroupCreateDate(Date groupCreateDate) {
        this.groupCreateDate = groupCreateDate;
    }

    public String getGroupNotice() {
        return groupNotice;
    }

    public void setGroupNotice(String groupNotice) {
        this.groupNotice = groupNotice;
    }

    public boolean isGroupForbidden() {
        return groupForbidden;
    }

    public void setGroupForbidden(boolean groupForbidden) {
        this.groupForbidden = groupForbidden;
    }

    @Override
    public String toString() {
        return "Group{" +
                "groupId=" + groupId +
                ", groupAdmin=" + groupAdmin +
                ", groupAccount='" + groupAccount + '\'' +
                ", groupName='" + groupName + '\'' +
                ", groupSum=" + groupSum +
                ", groupImage='" + "..." + '\'' +
                ", groupCreateDate=" + groupCreateDate +
                ", groupNotice='" + groupNotice + '\'' +
                ", groupForbidden=" + groupForbidden +
                '}';
    }
}