package com.freely.component.repository;

public interface SQLDataGet<T> {
    T getSQLData();
}
