package com.freely.data.network.requestEntities;

import com.freely.data.entities.Group;
import com.freely.data.entities.User;
import com.google.gson.annotations.SerializedName;

/**
 * @author DaWan
 * @time 2018/12/6 9:06
 * @dscription
 */
public class RQQueryMemberInformation implements BaseRQEntity {
	@SerializedName(User.user_id)
	private long userId;
	@SerializedName(Group.group_id)
	private long groupId;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getGroupId() {
		return groupId;
	}

	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}
}
