package com.freely.data.adapter;

import android.util.Log;

import com.freely.data.entities.ChatRecord;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;
import java.util.Date;

/**
 * @author DaWan
 * @time 2018/12/5 14:35
 * @dscription
 */
public class GsonGroupChatMessageAdapter implements JsonDeserializer<ChatRecord> {
	private static final String TAG = "GsonGroupChatMessageAda";
	@Override
	public ChatRecord deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
			throws JsonParseException {
		Log.d(TAG, "deserialize: "+json.toString());
		JsonObject object = json.getAsJsonObject();
		ChatRecord record = new ChatRecord();

		long recordId = object.getAsJsonPrimitive("record_id").getAsLong();
		record.setRecordId(recordId);
		long userId = object.getAsJsonObject("user").getAsJsonPrimitive("user_id").getAsLong();
		record.setUserId(userId);
		long groupId = object.getAsJsonObject("group").getAsJsonPrimitive("group_id").getAsLong();
		record.setGroupId(groupId);
		long recordSendTime = object.getAsJsonPrimitive("record_send_time").getAsLong();
		record.setRecordSendTime(new Date(recordSendTime));
		String recordContent = object.getAsJsonPrimitive("record_content").getAsString();
		record.setRecordContent(recordContent);

		return record;
	}
}
