package com.freely.data.network.requestAPI;

import com.freely.data.entities.Group;
import com.freely.data.entities.Message;
import com.freely.data.entities.User;
import com.freely.data.network.responseEntities.RSResult;
import com.freely.data.network.responseEntities.RSUserLocation;

import java.util.List;

import io.reactivex.Single;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
@Deprecated
public interface FreelyAPI {

    String VERIFICATION_CODE = "verification_code";//验证码
    String location_longitude = "location_longitude";//经度
    String location_latitude = "location_latitude";//纬度
    String inviter_id = "inviter_id";//邀请人id
    String invitee_id = "invitee_id";//被邀请人id
    String deviceCode = "device_code";//设备码

    //获取图片验证码
    @FormUrlEncoded
    @POST("verification_request.action")
    Call<RSResult<String, String>> verificationRequest(
            @Field(FreelyAPI.deviceCode) String deviceCode//设备码
    );

    //验证图片验证码
    @FormUrlEncoded
    @POST("verification_check.action")
    Call<RSResult<String,String>> verificationCheck(
            @Field(FreelyAPI.deviceCode) String deviceCode,//设备码
            @Field(VERIFICATION_CODE) String verificationCode
    );

    //1.用户注册
    @FormUrlEncoded
    @POST("user_register.action")

    Call<RSResult<String, User>> register(
            @Field(FreelyAPI.deviceCode) String deviceCode,//设备码
            @Field(User.user_account) String userAccount,//登录账号
            @Field(User.user_password) String userPassword,//登录密码
            @Field(User.user_email) String userEmail//邮箱
    );

    //2.用户登录
    @FormUrlEncoded
    @POST("user_login.action")
    Call<RSResult<User, User>> login(
            @Field(User.user_account) String userAccount,//登录账号
            @Field(User.user_password) String userPassword,//登录密码
            @Field(FreelyAPI.VERIFICATION_CODE) String verificationCode//验证码
    );

    //3.找回密码
    //3.1请求验证码
    @FormUrlEncoded
    @POST("user_getBackPassword.action")
    Call<RSResult<String, String>> getVerification(
            @Field(User.user_email) String userEmail//用户邮箱
    );

    //3.2验证验证码
    @FormUrlEncoded
    @POST("user_getBackPassword.action")
    Call<RSResult<String, String>> checkVerification(
            @Field(User.user_email) String userEmail,//用户邮箱
            @Field(FreelyAPI.VERIFICATION_CODE) String verificationCode//验证码
    );

    //3.3重置密码
    @FormUrlEncoded
    @POST("user_getBackPassword.action")
    Call<RSResult<String, String>> resetPassword(
            @Field(User.user_email) String userEmail,//用户邮箱
            @Field(User.user_password) String userPassword//用户密码
    );

    //4.退出登录
    @FormUrlEncoded
    @POST("user_exit.action")
    Call<RSResult<String, String>> exitLogin(
            @Field(User.user_id) long userId//用户id
    );

    //todo 消息通知 socket

    //6.查看个人信息
    @FormUrlEncoded
    @POST("user_getPersonInformation.action")
    Call<RSResult<User, String>> userInformation(
            @Field(User.user_id) long userId//用户id
    );

    //7.更新个人信息
    @FormUrlEncoded
    @POST("user_updatePersonInformation.action")
    Single<RSResult<User, String>> updateUserInformation(
            @Field(User.user_id) long userId,//用户id
            @Field(User.user_name) String userName,//用户昵称
            @Field(User.user_email) String userEmail,//用户邮箱
            @Field(User.user_phone) String userPhone,//用户手机号
            @Field(User.user_image) String userImage//用户头像
    );

    //todo gps信息可做心跳包


    //1.搜索想要加入的群
    @FormUrlEncoded
    @POST("group_searchGroup.action")
    Call<RSResult<List<Group>, String>> searchGroup(
            @Field(Group.group_account) String groupAccount//群帐号
    );



    //4.查询已加入群
    @FormUrlEncoded
    @POST("group_queryAllAddedGroup.action")
    Call<RSResult<List<Group>, String>> queryAllJoinGroup(
            @Field(User.user_id) long userId//用户id
    );

    //5.查看群成员位置信息
    @FormUrlEncoded
    @POST("group_getMemberLocation.action")
    Call<RSResult<List<RSUserLocation>, String>> groupMemberLocation(
            @Field(Group.group_id) long groupId//群id
    );

    //邀请群成员
    @FormUrlEncoded
    @POST("group_inviteMember.action")
    Call<RSResult<String, String>> inviteMember(
            @Field(Group.group_id) long groupId,//群id
            @Field(FreelyAPI.inviter_id) long inviterId,//邀请人id
            @Field(FreelyAPI.invitee_id) long inviteeId//被邀请人id
    );

    //查看群成员
    @FormUrlEncoded
    @POST("group_queryAllMember.action")
    Call<RSResult<List<User>, String>> queryAllMember(
            @Field(Group.group_id) long groupId//群id
    );

    //搜索已加入群
    @FormUrlEncoded
    @POST("group_queryJoinedGroup.action")
    Call<RSResult<List<Group>, String>> queryJoinedGroup(
            @Field(Group.group_account) String groupAccount,//群帐号
            @Field(User.user_id) long userId//用户id
    );

    //搜索群成员
    @FormUrlEncoded
    @POST("group_queryMember.action")
    Call<RSResult<List<User>, String>> queryMember(
            @Field(Group.group_id) long groupId,//群id
            @Field(User.user_name) String userName//用户昵称
    );

    //搜索群员位置
    @FormUrlEncoded
    @POST("group_queryMemberLocation.action")
    Call<RSResult<List<RSUserLocation>, String>> queryMemberLocation(
            @Field(Group.group_id) long groupId,//群id
            @Field(User.user_name) String userName//用户昵称
    );

    //11.创建群
    @FormUrlEncoded
    @POST("group_createGroup.action")
    Call<RSResult<Group, String>> CreateGroup(
            @Field("group_admin") long userId,//用户id
            @Field(Group.group_image) String groupImage,//群头像
            @Field(Group.group_name) String groupName,//群名称
            @Field(Group.group_notice) String groupNotice//群公告
    );



    //13.修改群公告
    @FormUrlEncoded
    @POST("group_updateGroupNotice.action")
    Call<RSResult<String, String>> updateGroupNotice(
            @Field(Group.group_id) long groupId,//群id
            @Field(Group.group_notice) String groupNotice//群公告
    );

    //13.14.修改群名
    @FormUrlEncoded
    @POST("group_updateGroupName.action")
    Call<RSResult<String, String>> updateGroupName(
            @Field(Group.group_id) long groupId,//群id
            @Field(Group.group_name) String groupName//群名称
    );


    //16.加入群通过
    @FormUrlEncoded
    @POST("group_passApplication.action")
    Call<RSResult<String, String>> passJoinGroup(
            @Field(Group.group_id) long groupId,//群id
            @Field(User.user_id) long userId//用户id
    );

    //17.同意入群邀请
    @FormUrlEncoded
    @POST("group_agreeJoinGroup.action")
    Call<RSResult<Group, String>> agreeJoinGroup(
            @Field(Group.group_id) long groupId,//群id
            @Field(User.user_id) long userId//用户id
    );

    //1.查看所有消息通知
    @FormUrlEncoded
    @POST("message_queryAllMessage.action")
    Call<RSResult<List<Message>, String>> queryAllMessage(
            @Field(User.user_id) long userId//用户id
    );

    //2.同意或拒绝群邀请
    @FormUrlEncoded
    @POST("message_dealGroupInvite.action")
    Call<RSResult<Group, String>> dealGroupInvite(
            @Field(User.user_id) long userId,//用户id
            @Field(Group.group_id) long groupId,//群id
            @Field(Message.message_id) long messageId//消息id
    );

    //3.同意或拒绝群加入申请
    @FormUrlEncoded
    @POST("message_dealGroupApplication.action")
    Call<RSResult<String, String>> dealGroupJoin(
            @Field(User.user_id) long userId,//用户id
            @Field(Group.group_id) long groupId,//群id
            @Field(Message.message_id) long messageId//消息id
    );

}
