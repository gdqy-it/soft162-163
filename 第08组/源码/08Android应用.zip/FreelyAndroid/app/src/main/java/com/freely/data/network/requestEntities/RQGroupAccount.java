package com.freely.data.network.requestEntities;

import com.freely.data.entities.Group;
import com.google.gson.annotations.SerializedName;

/**
 * @author DaWan
 * @time 2018/11/27 15:48
 * @dscription
 */
public class RQGroupAccount {
	@SerializedName(Group.group_account)
	private String groupAccount;

	public RQGroupAccount(String groupAccount) {
		this.groupAccount = groupAccount;
	}

	public String getGroupAccount() {
		return groupAccount;
	}

	public void setGroupAccount(String groupAccount) {
		this.groupAccount = groupAccount;
	}
}
