package com.freely.ui.activities;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import com.freely.R;

import org.devio.takephoto.app.TakePhotoActivity;
import org.devio.takephoto.compress.CompressConfig;
import org.devio.takephoto.model.CropOptions;
import org.devio.takephoto.model.TResult;
import org.devio.takephoto.model.TakePhotoOptions;

import java.io.File;

public class PhotoSelectActivity extends TakePhotoActivity {
    private static final String TAG = "PhotoSelectActivity";
    public static final String SELECT_MODE = "select_mode";
    public static final String RESULT = "result";
    public static final int CAPTURE = 1;
    public static final int GALLERY = 2;
    private File path;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_select);
        path = new File(getFilesDir(), "tempHeadIcon.jpg");
        Log.d(TAG, "onCreate: " + path);
        //takePhoto 配置
        TakePhotoOptions takePhotoOptions = new TakePhotoOptions.Builder()
                .setWithOwnGallery(true)
                .setCorrectImage(true)
                .create();
        getTakePhoto().setTakePhotoOptions(takePhotoOptions);
        //裁剪选项
        CropOptions cropOptions = new CropOptions.Builder()
                .setAspectX(1)
                .setAspectY(1)
                .setWithOwnCrop(true)
                .create();
        //压缩选项
        CompressConfig compressConfig = new CompressConfig.Builder()
                .setMaxSize(1024 * 100)
                .setMaxPixel(800)
                .enableReserveRaw(true)
                .create();
        getTakePhoto().onEnableCompress(compressConfig, false);

        int selectMode = getIntent().getIntExtra(SELECT_MODE, GALLERY);
        if (selectMode == CAPTURE) {
            //从相机拍摄相片裁剪
            getTakePhoto().onPickFromCaptureWithCrop(Uri.fromFile(path), cropOptions);
        } else {
            //从相册选取图片裁剪
            getTakePhoto().onPickFromGalleryWithCrop(Uri.fromFile(path), cropOptions);
        }
    }

    @Override
    public void takeSuccess(TResult result) {
        super.takeSuccess(result);
        Intent intent = new Intent();
        intent.putExtra(RESULT, result.getImage().getCompressPath());
        setResult(RESULT_OK, intent);
        finish();
    }

    @Override
    public void takeFail(TResult result, String msg) {
        super.takeFail(result, msg);
        finish();
    }

    @Override
    public void takeCancel() {
        super.takeCancel();
        finish();
    }

    public static void startActivity(Activity context,int requestCode, int selectMode) {
        Intent intent = new Intent(context, PhotoSelectActivity.class);
        intent.putExtra(SELECT_MODE, selectMode);
        context.startActivityForResult(intent,requestCode);
    }

}
