package com.freely.data.network.webSocket;

import okhttp3.Response;
import okhttp3.WebSocket;

/**
 * @author DaWan
 * @time 2018/11/29 0:12
 * @dscription
 */
@FunctionalInterface
public interface OpenListener {
	boolean onOpen(WebSocket webSocket, Response response);
}
