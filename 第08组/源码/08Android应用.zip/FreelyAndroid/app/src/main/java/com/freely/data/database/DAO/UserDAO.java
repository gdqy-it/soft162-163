package com.freely.data.database.DAO;

import com.freely.data.entities.User;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import io.reactivex.Single;

@Dao
public interface UserDAO {

    @Insert
    void insertUser(User... users);

    @Update
    void updateUser(User... users);

    @Delete
    void deleteUser(User... users);

    //通过用户ID获得用户
    @Query("SELECT * FROM user where user_id = :userId")
    Single<User> queryUserByUserId(long userId);

    //获得所有用户
    @Query("select * from user")
    Single<List<User>> queryAllUser();

    @Query("UPDATE user set user_email=:userEmail,user_name=:userName,user_image =:userImage,user_phone=:userPhone where user_id=:userId")
    void updateUserById(long userId,String userImage,String userName,String userEmail,String userPhone);

    //根据群id获取所有群成员
    @Query("select * from user " +
            "where user_id in (" +
            "select user_id from user_group_relation where group_id = :groupId)"
    )
    Single<List<User>> queryUsersByGroupId(@NonNull Long groupId);
}
