package com.freely.ui.util;

import android.util.Log;
import android.widget.Toast;

import com.freely.component.activity.FreelyApplication;
import com.freely.data.network.ServerException;

import androidx.annotation.NonNull;
import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;

/**
 * @author DaWan
 * @time 2018/11/25 18:04
 * @dscription
 */
public class ErrorUtil {
    private static final String TAG = "ErrorUtil";

    private ErrorUtil() {

    }

    public static void errorHint(Throwable throwable) {
        //失败回调
        //服务端处理失败
        Single.just(throwable)
                .subscribeOn(AndroidSchedulers.mainThread())
                .subscribe(new SingleObserver<Throwable>() {
                    Disposable disposable;

                    @Override
                    public void onSubscribe(Disposable d) {
                        disposable = d;
                    }

                    @Override
                    public void onSuccess(Throwable throwable) {
                        if (throwable instanceof ServerException) {
                            Toast.makeText(
                                    FreelyApplication.getContext(),
                                    throwable.getMessage(),
                                    Toast.LENGTH_SHORT
                            ).show();
                            Log.e(TAG,
                                    "\n--------------------服务器错误--------------------\n",
                                    throwable
                            );
                            disposable.dispose();
                            return;
                        }
                        //连接失败
                        Toast.makeText(
                                FreelyApplication.getContext(),
                                "服务器无法连接",
                                Toast.LENGTH_SHORT
                        ).show();
                        Log.e(TAG,
                                "\n--------------------服务器无法连接--------------------\n",
                                throwable
                        );
                        disposable.dispose();
                    }

                    @Override
                    public void onError(Throwable e) {
                        Toast.makeText(
                                FreelyApplication.getContext(),
                                "未知错误",
                                Toast.LENGTH_SHORT
                        ).show();
                        Log.e(TAG,
                                "\n--------------------未知错误--------------------\n",
                                e
                        );
                        disposable.dispose();
                    }
                });

    }

    public static void dataReadErrorHint(@NonNull String errorHint,Throwable throwable) {
        Single.just(errorHint)
                .subscribeOn(AndroidSchedulers.mainThread())
                .subscribe(new SingleObserver<String>() {
                    Disposable disposable;
                    @Override
                    public void onSubscribe(Disposable d) {
                        disposable = d;
                    }

                    @Override
                    public void onSuccess(String s) {
                        Toast.makeText(
                                FreelyApplication.getContext(),
                                errorHint,
                                Toast.LENGTH_SHORT
                        ).show();
                        Log.e(TAG,
                                "\n--------------------未知错误--------------------\n",
                                throwable
                        );
                    }

                    @Override
                    public void onError(Throwable e) {
                        Toast.makeText(
                                FreelyApplication.getContext(),
                                "未知错误",
                                Toast.LENGTH_SHORT
                        ).show();
                        Log.e(TAG,
                                "\n--------------------未知错误--------------------\n",
                                e
                        );
                    }
                });
    }
}
