package com.freely.data.managerUtils;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.freely.FR;
import com.freely.component.activity.FreelyApplication;
import com.freely.data.entities.User;

import java.util.UUID;

public final class FreelySharedPreferences {
    private static FreelySharedPreferences freelySharedPreferences;
    private static SharedPreferences sharedPreferences;
    public static final long RESULT_NULL = -1;
    private String deviceCode;
    private Long userId;
    static {
        freelySharedPreferences = new FreelySharedPreferences();
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(FreelyApplication.getContext());

    }

    private FreelySharedPreferences() {
    }

    public static FreelySharedPreferences getInstance(){
        return freelySharedPreferences;
    }

    public String getDeviceCode() {
        if (deviceCode != null) {
            return deviceCode;
        }
        deviceCode = sharedPreferences.getString(FR.DEVICE_CODE, null);
        //设备码初始化
        if (deviceCode == null) {
            deviceCode = UUID.randomUUID().toString();
            sharedPreferences.edit().putString(FR.DEVICE_CODE, deviceCode).apply();
        }
        return deviceCode;
    }

    public void setUserId(long userId) {
        this.userId = userId;
        sharedPreferences.edit().putLong(User.user_id, userId).apply();
    }

    public long getUserId() {
        if (userId != null) {
            return userId;
        }
        userId = sharedPreferences.getLong(User.user_id, RESULT_NULL);
        return userId;
    }


}
