package com.freely.data.network.requestEntities;

import com.freely.data.entities.User;
import com.google.gson.annotations.SerializedName;

public class RQUserId implements BaseRQEntity {
    @SerializedName(User.user_id)
    private long userId;

    public RQUserId(long userId) {
        this.userId = userId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }
}
