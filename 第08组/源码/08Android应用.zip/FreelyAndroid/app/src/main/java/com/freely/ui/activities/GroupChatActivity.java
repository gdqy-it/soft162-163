package com.freely.ui.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.TextView;

import com.freely.R;
import com.freely.R2;
import com.freely.component.activity.NavigationActivity;
import com.freely.data.entities.Group;
import com.freely.ui.adapter.ChatViewPagerAdapter;
import com.freely.ui.viewModel.GroupChatViewModel;

import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProviders;
import androidx.viewpager.widget.ViewPager;
import butterknife.BindView;

public class GroupChatActivity extends NavigationActivity {
    private static final String TAG = "GroupChatActivity";
    private long groupId;
    private GroupChatViewModel viewModel;
    @BindView(R2.id.view_pager)
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_chat);
        init();
    }

    private void init() {

        groupId = getIntent().getLongExtra(Group.group_id,-1);
        viewModel = ViewModelProviders.of(this).get(GroupChatViewModel.class);
        viewModel.getGroupInformation().observe(this,group -> {
            setNavigationTitle(group.getGroupName());
        });
        Log.d(TAG, "init: groupId="+groupId);
        viewPager.setAdapter(new ChatViewPagerAdapter(getSupportFragmentManager(),groupId));
        viewModel.loadGroupInformation(groupId);
    }

    @Override
    protected void onCreateToolbar(Toolbar toolbar, TextView title, ImageButton logo) {
        super.onCreateToolbar(toolbar, title, logo);
        toolbar.inflateMenu(R.menu.group_chat);

        toolbar.setOnMenuItemClickListener(item -> {
            boolean result =false;
            switch (item.getItemId()) {
                case R.id.toolbar_more:
                    GroupChatInformationActivity.startActivity(this, groupId,false);
                    result = true;
                    break;
            }
            return result;
        });
    }

    public static void startActivity(Context context,long groupId) {
        Intent intent = new Intent(context, GroupChatActivity.class);
        intent.putExtra(Group.group_id, groupId);
        context.startActivity(intent);
    }

}
