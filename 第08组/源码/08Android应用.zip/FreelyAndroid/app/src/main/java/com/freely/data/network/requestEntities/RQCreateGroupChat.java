package com.freely.data.network.requestEntities;

import com.google.gson.annotations.SerializedName;

/**
 * @author DaWan
 * @time 2018/11/23 14:06
 * @dscription 创建群聊请求
 */
public class RQCreateGroupChat implements BaseRQEntity {
    @SerializedName("group_admin")
    private long groupAdmin;//用户id
    @SerializedName("group_image")
    private String groupImage;//群头像
    @SerializedName("group_name")
    private String groupName;//群名称
    @SerializedName("group_notice")
    private String groupNotice;//群公告

    public RQCreateGroupChat(long groupAdmin, String groupImage, String groupName, String groupNotice) {
        this.groupAdmin = groupAdmin;
        this.groupImage = groupImage;
        this.groupName = groupName;
        this.groupNotice = groupNotice;
    }

    public long getGroupAdmin() {
        return groupAdmin;
    }

    public void setGroupAdmin(long groupAdmin) {
        this.groupAdmin = groupAdmin;
    }

    public String getGroupImage() {
        return groupImage;
    }

    public void setGroupImage(String groupImage) {
        this.groupImage = groupImage;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupNotice() {
        return groupNotice;
    }

    public void setGroupNotice(String groupNotice) {
        this.groupNotice = groupNotice;
    }
}
