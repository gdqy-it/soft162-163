package com.freely.data.entities;

import java.util.Date;

/**
 * @author DaWan
 * @time 2018/12/5 14:24
 * @dscription web socket 接受群聊消息的实体类
 */
public class GroupChatMessage {
	private long groupId;
	private long recordId;
	private String recordContent;
	private Date recordSendTime;
	private long userId;

	public long getGroupId() {
		return groupId;
	}

	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

	public long getRecordId() {
		return recordId;
	}

	public void setRecordId(long recordId) {
		this.recordId = recordId;
	}

	public String getRecordContent() {
		return recordContent;
	}

	public void setRecordContent(String recordContent) {
		this.recordContent = recordContent;
	}

	public Date getRecordSendTime() {
		return recordSendTime;
	}

	public void setRecordSendTime(Date recordSendTime) {
		this.recordSendTime = recordSendTime;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}
}
