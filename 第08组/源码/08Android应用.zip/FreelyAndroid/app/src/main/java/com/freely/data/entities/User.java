package com.freely.data.entities;

import com.google.gson.annotations.SerializedName;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

/*
        字段	                    类型	            键           	是否为空     备注
        user_id	                bigint  	    primary key 	not null	普通用户id
        user_account    	    varchar(16)		                not null	帐号
        user_password   	    varchar(16)		                not null	密码
        user_email      	    varchar(16)		                not null	邮箱
        user_phone      	    varchar(11)		                not null	手机号
        user_name       	    varchar(16)		                not null	昵称
        user_image          	varchar(50)		                not null	头像
        user_last_login_time	timestamp		                not null	上次登录时间
        user_online         	bool		                    not null	是否在线
        user_forbidden	        bool		                    not null	是否禁用
*/
@Entity(tableName = "user")
public class User {

    @Ignore
    public static final String user_id = "user_id";
    @Ignore
    public static final String user_account = "user_account";
    @Ignore
    public static final String user_password = "user_password";
    @Ignore
    public static final String user_email = "user_email";
    @Ignore
    public static final String user_phone = "user_phone";
    @Ignore
    public static final String user_name = "user_name";
    @Ignore
    public static final String user_image = "user_image";
    @Ignore
    public static final String user_last_login_time = "user_last_login_time";
    @Ignore
    public static final String user_online = "user_online";
    @Ignore
    public static final String user_last_update_time = "user_last_update_time";
    @Ignore
    public static final String user_forbidden = "user_forbidden";

    @PrimaryKey
    @ColumnInfo(name = User.user_id)
    @SerializedName(User.user_id)
    private long userId;//普通用户id

    @ColumnInfo(name = User.user_account)
    @SerializedName(User.user_account)
    private String userAccount;//帐号

/*
    @NonNull
    @ColumnInfo(name = User.user_password)
    private String userPassword;//密码
*/

    @ColumnInfo(name = User.user_email)
    @SerializedName(User.user_email)
    private String userEmail;//邮箱

    @ColumnInfo(name = User.user_phone)
    @SerializedName(User.user_phone)
    private String userPhone;//手机号

    @ColumnInfo(name = User.user_name)
    @SerializedName(User.user_name)
    private String userName;//昵称

    @ColumnInfo(name = User.user_image)
    @SerializedName(User.user_image)
    private String userImage;//头像

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(String userAccount) {
        this.userAccount = userAccount;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserImage() {
        return userImage;
    }

    public void setUserImage(String userImage) {
        this.userImage = userImage;
    }

    @Override
    public String toString() {
        return "User{" +
                "userId=" + userId +
                ", userAccount='" + userAccount + '\'' +
                ", userEmail='" + userEmail + '\'' +
                ", userPhone='" + userPhone + '\'' +
                ", userName='" + userName + '\'' +
                ", userImage='" + userImage + '\'' +
                '}';
    }
}
