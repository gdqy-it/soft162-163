package com.freely.ui.viewModel

import androidx.lifecycle.MutableLiveData
import com.freely.component.BaseViewModel
import com.freely.data.entities.User
import com.freely.data.network.FreelyClient
import com.freely.data.network.ServerException
import com.freely.ui.util.ErrorUtil
import io.reactivex.schedulers.Schedulers

/**
 * @author DaWan
 * @time 2018/12/9 16:18
 * @description
 */
class ForgetPasswordViewModel : BaseViewModel() {
    val resetPassword = MutableLiveData<String>()
    val requestVerificationCode = MutableLiveData<String>()
    val verification = MutableLiveData<String>()

    fun resetPassword(email: String, password: String) {
        val arg = mapOf<Any, Any>(User.user_email to email, User.user_password to password)
        val reset = FreelyClient.getFreelyService().requestResetPassword(arg)
        val disposable = reset.subscribeOn(Schedulers.io()).subscribe({
            if (!it.isResult) {
                ErrorUtil.errorHint(ServerException(it.failure))
                return@subscribe
            }
            resetPassword.postValue(it.success)
        }, { ErrorUtil.errorHint(it) })
        register(disposable)
    }

    fun requestVerification(email: String, verificationCode: String) {
        val arg = mapOf<Any, Any>(User.user_email to email, "verification_code" to verificationCode)
        val single = FreelyClient.getFreelyService().requestEmailVerificationCode(arg)
        val disposable = single.subscribe()
    }
}
