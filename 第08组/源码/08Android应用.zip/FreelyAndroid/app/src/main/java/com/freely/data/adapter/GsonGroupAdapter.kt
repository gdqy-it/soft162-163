package com.freely.data.adapter

import android.util.Log
import com.freely.data.entities.Group
import com.freely.data.entities.User
import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import java.lang.reflect.Type
import java.util.*

/**
 * @author DaWan
 * @time 2018/12/14 14:04
 * @description
 */
class GsonGroupAdapter : JsonDeserializer<Group> {
    private val TAG = "GsonGroupAdapter"
    override fun deserialize(json: JsonElement?, typeOfT: Type, context:
    JsonDeserializationContext): Group {
//        Log.d(TAG, "deserialize: ${json.toString()}")
        val group = Group()
        val obj = json?.asJsonObject
        group.groupId = obj?.getAsJsonPrimitive(Group.group_id)?.asLong ?: 0
        group.groupAccount = obj?.getAsJsonPrimitive(Group.group_account)?.asString
        group.groupName = obj?.getAsJsonPrimitive(Group.group_name)?.asString
        group.groupSum = obj?.getAsJsonPrimitive(Group.group_sum)?.asInt ?: 0
        group.groupImage = obj?.getAsJsonPrimitive(Group.group_image)?.asString
        group.groupCreateDate = Date(obj?.getAsJsonPrimitive(Group.group_create_date)?.asLong ?: 0)
        group.groupNotice = obj?.getAsJsonPrimitive(Group.group_notice)?.asString
        group.isGroupForbidden = obj?.getAsJsonPrimitive(Group.group_forbidden)?.asBoolean ?: false
        group.groupAdmin = obj?.getAsJsonObject(Group.group_admin)?.getAsJsonPrimitive(User
                .user_id)?.asLong ?: 0
        Log.d(TAG, "deserialize: $group")
        return group
    }
}