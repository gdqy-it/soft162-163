package com.freely.ui.adapter.recyclerView;

import com.freely.component.BaseRecyclerViewAdapter;

import java.util.List;

import androidx.annotation.LayoutRes;

public class SingleViewAdapter<T> extends BaseRecyclerViewAdapter {
    private List<T> dataList;

    public SingleViewAdapter(List<T> dataList, @LayoutRes int layoutId) {
        this.dataList = dataList;
        getView(position -> layoutId);
    }

    @Override
    public int getItemCount() {
        return dataList == null ? 0 : dataList.size();
    }

    public List<T> getDataList() {
        return dataList;
    }

    public void setDataList(List<T> dataList) {
        this.dataList = dataList;
    }
}
