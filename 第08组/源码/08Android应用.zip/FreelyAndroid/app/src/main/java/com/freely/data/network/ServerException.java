package com.freely.data.network;

/**
 * @author DaWan
 * @time 2018/11/23 12:15
 * @dscription
 */
public class ServerException extends Exception {

    public ServerException() {
    }

    public ServerException(String message) {
        super(message);
    }
}
