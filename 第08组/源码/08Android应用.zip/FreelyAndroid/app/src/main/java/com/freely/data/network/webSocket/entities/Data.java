package com.freely.data.network.webSocket.entities;

import androidx.annotation.NonNull;

/**
 * @author DaWan
 * @time 2018/11/29 0:01
 * @dscription
 */
public class Data<T> extends DataType {
	private T data;

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	@NonNull
	@Override
	public String toString() {
		return "Data{" +
				"data=" + data +
				"} " + super.toString();
	}
}
