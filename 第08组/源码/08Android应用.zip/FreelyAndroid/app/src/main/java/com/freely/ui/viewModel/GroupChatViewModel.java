package com.freely.ui.viewModel;

import com.freely.component.BaseViewModel;
import com.freely.data.database.FreelyDatabase;
import com.freely.data.entities.Group;
import com.freely.ui.util.ErrorUtil;

import androidx.lifecycle.MutableLiveData;
import io.reactivex.Single;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * @author DaWan
 * @time 2018/11/30 11:53
 * @dscription
 */
public class GroupChatViewModel extends BaseViewModel {
	private static final String TAG = "GroupChatViewModel";
	private MutableLiveData<Group> groupInformation;

	public GroupChatViewModel() {
		groupInformation = new MutableLiveData<>();
	}

	public void loadGroupInformation(long groupId) {
		Single<Group> groupSingle = FreelyDatabase.getInstance()
				.groupDAO()
				.getGroupByGroupId(groupId);
		Disposable disposable = groupSingle.subscribeOn(Schedulers.io())
				.subscribe(group -> {
					groupInformation.postValue(group);
				},ErrorUtil::errorHint);
		register(disposable);
	}

	public MutableLiveData<Group> getGroupInformation() {
		return groupInformation;
	}

}
