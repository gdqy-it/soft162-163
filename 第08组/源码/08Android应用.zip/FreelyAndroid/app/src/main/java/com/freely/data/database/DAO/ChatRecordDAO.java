package com.freely.data.database.DAO;

import com.freely.data.entities.ChatRecord;
import com.freely.data.repository.entities.GroupChatMessage;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import io.reactivex.Single;

@Dao
public interface ChatRecordDAO {
    @Insert
    public void insertChatRecord(ChatRecord... chatRecord);

    @Update
    public void updateChatRecord(ChatRecord... chatRecords);

    @Delete
    public void deleteChatRecord(ChatRecord... chatRecords);

    //根据群id得到@number条群聊消息
    @Query("select record_id,user.user_id,user_name,user_image,record_content,record_send_time " +
            "from chat_record join user " +
            "on chat_record.user_id = user.user_id " +
            "where chat_record.group_id = :groupId " +
            "order by chat_record.record_send_time ASC " +
            "limit :start,:number")
    Single<List<GroupChatMessage>> getFiftyGroupChatMessage(long groupId, long start,long number);

    //根据群id得到最新一条群聊消息
    @Query("select record_id,user.user_id,user_name,user_image,record_content,record_send_time " +
            "from chat_record join user " +
            "on chat_record.user_id = user.user_id " +
            "where chat_record.group_id = :groupId " +
            "order by chat_record.record_send_time DESC " +
            "limit 1")
    Single<GroupChatMessage> getNewGroupChatMessage(long groupId);

/*    //通过群ID获得该群的所有消息
    @Query("SELECT * FROM chat_record WHERE group_id  LIKE:groupId")
    List<ChatRecord> getAllByGroupId(long groupId);

    //通过群ID以及用户收到该群的最后一条信息的时间获得最新消息
    @Query("SELECT * FROM chat_record WHERE record_send_time > :LastTime AND group_id LIKE:groupId")
    List<ChatRecord> getLastByGroupId(Date  LastTime, long groupId);*/
}
