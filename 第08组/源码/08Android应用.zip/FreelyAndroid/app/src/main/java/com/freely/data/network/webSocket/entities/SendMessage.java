package com.freely.data.network.webSocket.entities;

import com.freely.data.entities.Group;
import com.freely.data.entities.User;
import com.google.gson.annotations.SerializedName;

import java.util.Date;

/**
 * @author DaWan
 * @time 2018/11/29 9:25
 * @dscription
 */
public class SendMessage extends DataType {

	@SerializedName(User.user_id)
	private long userId;
	@SerializedName(Group.group_id)
	private long groupId;
	@SerializedName("send_time")
	private Date sendTime;
	@SerializedName("record_content")
	private String recordContent;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getGroupId() {
		return groupId;
	}

	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

	public Date getSendTime() {
		return sendTime;
	}

	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}

	public String getRecordContent() {
		return recordContent;
	}

	public void setRecordContent(String recordContent) {
		this.recordContent = recordContent;
	}

	@Override
	public String toString() {
		return "SendMessage{" +
				"userId=" + userId +
				", groupId=" + groupId +
				", sendTime=" + sendTime +
				", recordContent='" + recordContent + '\'' +
				"} " + super.toString();
	}
}
