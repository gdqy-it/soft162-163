package com.freely.ui.listener;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import com.freely.ui.activities.HomeActivity;


public class MessageListener implements View.OnClickListener {
    Context context;
    public MessageListener(Context context){
        this.context=context;
    }
    @Override
    public void onClick(View v) {
        Intent i = new Intent(context,HomeActivity.class);
        context.startActivity(i);
    }
}
