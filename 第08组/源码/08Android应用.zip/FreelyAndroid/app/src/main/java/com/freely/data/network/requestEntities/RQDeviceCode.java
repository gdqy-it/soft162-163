package com.freely.data.network.requestEntities;

import com.freely.FR;
import com.google.gson.annotations.SerializedName;

public class RQDeviceCode implements BaseRQEntity {
    @SerializedName(FR.DEVICE_CODE)
    private String deviceCode;//设备码

    public RQDeviceCode() {
    }

    public RQDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }
}
