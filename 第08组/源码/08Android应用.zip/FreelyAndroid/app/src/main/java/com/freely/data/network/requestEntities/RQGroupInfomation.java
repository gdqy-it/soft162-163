package com.freely.data.network.requestEntities;

public class RQGroupInfomation {
    	private long group_id;

    public long getGroup_id() {
        return group_id;
    }

    public RQGroupInfomation(long group_id) {
        this.group_id = group_id;
    }

    public void setGroup_id(long group_id) {
        this.group_id = group_id;
    }
}
