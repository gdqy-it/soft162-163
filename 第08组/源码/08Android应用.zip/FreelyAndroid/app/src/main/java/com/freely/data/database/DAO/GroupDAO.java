package com.freely.data.database.DAO;

import com.freely.data.entities.Group;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import io.reactivex.Single;

@Dao
public interface GroupDAO {

	//通过群id获取群
	@Query("select * " +
		   "from chat_group " +
		   "where group_id = :groupId")
	Single<Group> getGroupByGroupId(long groupId);

	//通过userId获取已加入群列表
	@Query("select * " +
			"from chat_group " +
			"where group_id in (" +
			"select group_id " +
			"from user_group_relation " +
			"where user_id = :useId)")
	Single<List<Group>> queryJoinedChatGroupList(long useId);

	//通过关键字获取群列表
	@Query("select * " +
			"from chat_group " +
			"where group_name like '%' || :keyword || '%'")
	Single<List<Group>> queryGroupsByKeyword(@NonNull String keyword);


	@Insert
    void insertGroup(Group... groups);

    @Insert
    void insertGroup(List<Group> groups);

    @Update
    void updateGroup(Group... groups);

    @Delete
    void deleteGroup(Group... groups);

	@Query("delete from chat_group")
	void clearAllGroup();

	@Query("update chat_group set group_name=:groupName,group_notice=:groupNotice,group_image=:groupImage where group_id=:groupId")
	void updateGroupInformation(long groupId,String groupName,String groupNotice,String groupImage);

	@Query("DELETE FROM chat_group WHERE group_id=:groupId")
	void deleteGroupById(long groupId);
}
