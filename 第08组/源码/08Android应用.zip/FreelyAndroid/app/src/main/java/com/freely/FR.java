package com.freely;

import com.freely.data.managerUtils.FreelySharedPreferences;

public interface FR {
    String DEVICE_CODE = "device_code";//设备码
    String LOCATION_LONGITUDE = "location_longitude";//经度
    String LOCATION_LATITUDE = "location_latitude";//纬度
    String VERIFICATION_CODE = "verification_code";//验证码
    String USER_ACCOUNT = "user_account";//登录账号
    String USER_PASSWORD = "user_password";//登录密码
    String USER_EMAIL = "user_email";//邮箱

    String deviceCodeContent = FreelySharedPreferences.getInstance().getDeviceCode();
    long USER_ID = FreelySharedPreferences.getInstance().getUserId();


    String inviter_id = "inviter_id";//邀请人id
    String invitee_id = "invitee_id";//被邀请人id
}
