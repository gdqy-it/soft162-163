package com.freely.ui.viewModel;

import com.freely.component.BaseViewModel;
import com.freely.data.network.FreelyClient;
import com.freely.data.network.ServerException;
import com.freely.data.network.requestEntities.RQGroupAccount;
import com.freely.data.network.responseEntities.RSGroup;
import com.freely.data.network.responseEntities.RSResult;
import com.freely.ui.util.ErrorUtil;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import io.reactivex.Single;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * @author DaWan
 * @time 2018/11/27 14:59
 * @dscription
 */
public class GroupJoinViewModel extends BaseViewModel {
	private MutableLiveData<List<RSGroup>> groupList;

	public GroupJoinViewModel() {
		groupList = new MutableLiveData<>();
	}

	public void loadGroupList(@NonNull String groupAccount) {
		Single<RSResult<RSGroup,String>> single = FreelyClient
				.getFreelyService()
				.searchThinkJoinGroup(new RQGroupAccount(groupAccount));
		Disposable disposable = single.subscribeOn(Schedulers.io())
				.subscribe(result -> {
					if (!result.isResult()) {
						ErrorUtil.errorHint(new ServerException("服务器无法连接"));
						return;
					}
					List<RSGroup> list = new ArrayList<>();
					list.add(result.getSuccess());
					groupList.postValue(list);
				},ErrorUtil::errorHint);
		register(disposable);
	}

	public MutableLiveData<List<RSGroup>> getGroupList() {
		return groupList;
	}
}
