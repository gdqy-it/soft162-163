package com.freely.ui.listener;

import android.content.Intent;
import android.view.View;

import com.freely.ui.activities.GroupChatActivity;

public class GroupChatListener implements View.OnClickListener {

    @Override
    public void onClick(View view) {
        switch (view.getId()){
                default:
            String ss=(String)view.getTag();
            Intent i = new Intent(view.getContext(),GroupChatActivity.class);
            i.putExtra("groupName",ss);
            view.getContext().startActivity(i);
        }
    }

}
