package com.freely.ui.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.freely.R;
import com.freely.data.entities.Group;
import com.freely.ui.adapter.recyclerView.SingleViewAdapter;
import com.freely.ui.viewModel.SearchViewModel;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import okio.ByteString;

public class SearchActivity extends com.freely.component.activity.SearchActivity {
    private static final String TAG = "SearchActivity";
    @BindView(R.id.recycler_view)
    RecyclerView recyclerView;

    private SearchViewModel viewModel;
    private SingleViewAdapter<Group> searchRecyclerAdapter;
    private String searchText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
		init();
    }

	@Override
	protected void onCreateSearchBar(@NonNull ImageButton back, @NonNull SearchView searchView) {
		super.onCreateSearchBar(back, searchView);
		searchView.setQueryHint("请输入群名称...");
		//文本更改监听器
		searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
			@Override
			public boolean onQueryTextSubmit(String query) {
				if (query.equals(searchText)) {
					return false;
				}
				searchText = query;
				Log.d(TAG, "onQueryTextSubmit: 开始搜索");
				viewModel.loadSearchResultList(query);
				return true;
			}

			@Override
			public boolean onQueryTextChange(String newText) {
				Log.d(TAG, "onQueryTextChange: "+newText);
				return false;
			}
		});

	}

	private void init() {
    	//适配器初始化
		searchRecyclerAdapter = new SingleViewAdapter<>(
				null,
				R.layout.item_search_joined
		).onBindView((holder, position) -> {
			ImageView headIcon = holder.getView(R.id.head_icon);
			TextView groupName = holder.getView(R.id.group_name);
			Group group = viewModel.getGroupList().getValue().get(position);

			groupName.setText(group.getGroupName());
			Glide.with(SearchActivity.this)
					.load(ByteString.decodeBase64(group.getGroupImage()).toByteArray())
					.apply(RequestOptions.circleCropTransform())
					.into(headIcon);
			Log.d(TAG, "init: 设置群列表item监听");
			if (!holder.itemView.hasOnClickListeners()) {
				holder.itemView.setOnClickListener(v -> {
					this.startGroupChatActivity(position);
				});
			}
		});
		//设置适配器、布局管理器
		recyclerView.setAdapter(searchRecyclerAdapter);
		recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //view model初始化
        viewModel = ViewModelProviders.of(this).get(SearchViewModel.class);
		viewModel.getGroupList().observe(this,groups -> {
			//设置数据并更新列表
			searchRecyclerAdapter.setDataList(groups);
			searchRecyclerAdapter.notifyDataSetChanged();
		});

    }

	public void startGroupChatActivity(int position) {
		Group group = viewModel.getGroupList().getValue().get(position);
    	GroupChatActivity.startActivity(this,group.getGroupId());
	}

    public static void startActivity(Context context) {
        Intent intent = new Intent(context, SearchActivity.class);
        context.startActivity(intent);
    }
}
