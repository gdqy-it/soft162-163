package com.freely.component.activity;

import android.content.Context;

import com.baidu.mapapi.SDKInitializer;

import androidx.multidex.MultiDexApplication;

public class FreelyApplication extends MultiDexApplication {
    private static final String TAG = "FreelyApplication";
    private static Context context;

    @Override
    public void onCreate() {
        super.onCreate();
        context = super.getApplicationContext();
        //百度地图初始化
        SDKInitializer.initialize(this);
/*
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            Log.d(TAG,
                    t.getName() +
                            "线程异常:" +
                            "\n" +
                            e.getLocalizedMessage()+
                            e.getMessage()+
                            e.getCause()+
                            e.getStackTrace()
            );
*/

/*            Completable.complete()
                    .subscribeOn(AndroidSchedulers.mainThread())
                    .subscribe(() -> {
                        Toast.makeText(
                                context,
                                "线程异常->" + t.getName() + "\n" + e,
                                Toast.LENGTH_SHORT
                        ).show();
                    }).dispose();

           });*/
    }

    public static Context getContext(){
        return context;
    }


}
