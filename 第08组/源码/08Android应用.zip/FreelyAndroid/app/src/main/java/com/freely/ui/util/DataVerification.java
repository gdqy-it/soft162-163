package com.freely.ui.util;

import android.text.TextUtils;

import androidx.annotation.NonNull;

public final class DataVerification {
    private DataVerification() {
    }

    //用户账号格式验证
    public static boolean userAccountFormatVerification(@NonNull String userAccount) {
        String regex = "^[0-9a-zA-Z]*$";//区分大小写的字母、数字
        return userAccount.matches(regex);
    }

    //用户账号长度验证
    public static boolean userAccountLengthVerification(@NonNull String userAccount) {
        boolean result = true;
        int length = userAccount.length();
        if (length > 16 || length < 8) {
            result = false;
        }
        return result;
    }

    //用户密码格式验证
    public static boolean userPasswordFormatVerification(@NonNull String password) {
        String regex = "^[0-9a-zA-Z]*$";//区分大小写的字母、数字
        return password.matches(regex);
    }

    //用户密码长度验证
    public static boolean userPasswordLengthVerification(@NonNull String password) {
        boolean result = true;
        int length = password.length();
        if (length > 16 || length < 8) {
            result = false;
        }
        return result;
    }

    //确认密码格式验证
    public static boolean userCheckPasswordFormatVerification(@NonNull String password,@NonNull
                                                              String checkPassword) {
        return password.equals(checkPassword);
    }

    //用户邮箱格式验证
    public static boolean userEmailFormatVerification(@NonNull String userEmail) {
        String regex = "^[0-9A-Za-z][.-_0-9A-Za-z]*@[0-9A-Za-z]+(.[0-9A-Za-z]+)+$";
        return userEmail.matches(regex);
    }

    //验证码格式验证
    public static boolean verificationCodeFormatVerification(String verificationCode) {
        return TextUtils.isEmpty(verificationCode);
    }

    /**
     * @param groupName 群名称
     * @return 群名称长度验证结果
     * @dscription 群名称长度验证
     */
    public static boolean groupNameLengthVerification(@NonNull String groupName) {
        int length = groupName.length();
        return length > 0 && length <= 20;
    }

    /**
     * @param groupIntro 群公告
     * @return 群公告长度验证结果
     * @dscription 群公告长度验证
     */
    public static boolean groupIntroLengthVerification(@NonNull String groupIntro) {
        int length = groupIntro.length();
        return length >= 0 && length <= 100;
    }

    /**
     * @param userPhone 用户手机号码
     * @return 用户手机号码长度验证结果
     * @dscription 用户手机号码长度验证
     */
    public static boolean userPhoneLengthVerification(@NonNull String userPhone){
        int length = userPhone.length();
        return length==11;
    }
    /**
     * @param userNick 用户昵称
     * @return 用户昵称长度验证结果
     * @dscription 用户昵称长度验证
     */
    public static boolean userNickLengthVerification(@NonNull String userNick){
        int length = userNick.length();
        return length>4&&length<16;
    }
}
