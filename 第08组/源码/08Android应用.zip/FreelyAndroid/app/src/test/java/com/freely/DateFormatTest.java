package com.freely;

import com.freely.ui.util.DateFormat;

import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author DaWan
 * @time 2018/12/2 13:21
 * @dscription
 */
public class DateFormatTest {

	@Test
	public void dateFormatTest() {
		SimpleDateFormat format = new SimpleDateFormat("HH:mm");
		Date date = new Date(System.currentTimeMillis());
		System.out.println(format.format(date));
		System.out.println(DateFormat.format(DateFormat.TIME_FORMAT, date));
	}
}
