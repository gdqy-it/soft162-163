package com.freely

import io.reactivex.Observable
import org.junit.Test

/**
 * @author DaWan
 * @time 2018/12/14 20:54
 * @description
 */
class RxJavaTest {
    @Test
    fun rxJavaTest() {
        Observable.just(2).subscribe{

        }
    }
}