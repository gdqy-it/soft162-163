package com.freely;

/**
 * @author DaWan
 * @time 2018/11/28 23:27
 * @dscription
 */
public class Son extends Parent {
	private String data;

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "Son{" +
				"data='" + data + '\'' +
				'}';
	}
}
