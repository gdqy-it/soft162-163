package com.freely;

import org.junit.Test;

import io.reactivex.Observable;
import io.reactivex.functions.Function;

public class RxJavaText {
    @Test
    public void rxjava(){
        Observable.just(1).map(new Function<Integer, Object>() {
            @Override
            public Object apply(Integer integer) throws Exception {
                return null;
            }
        });
    }
}
