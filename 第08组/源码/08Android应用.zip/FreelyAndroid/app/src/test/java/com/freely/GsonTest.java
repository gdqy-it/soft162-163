package com.freely;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * @author DaWan
 * @time 2018/11/28 23:27
 * @dscription
 */
public class GsonTest {

	@Test
	public void gsonTest() {
		Gson gson = new Gson();/*
		String json = "{\"result\":\"ok\",\"data\":\"ok\"}";
		Parent parent = gson.fromJson(json, Parent.class);
		System.out.println(parent);
		Son son = gson.fromJson(json, Son.class);
		System.out.println(son);
		String parentJson = gson.toJson(parent);
		String sonJson = gson.toJson(son);
		System.out.println(parentJson);
		System.out.println(sonJson);
		Son twoSon = new Son();
		twoSon.setData("no ok");
		System.out.println(gson.toJson(twoSon));*/
		Map<String, Long> map = new HashMap<>();
		map.put("hello", (long) 2);
		map.put("you", (long) 5);
		Map<String, Object> map1 = new HashMap<>();
		map1.put("one", 1);
		map1.put("two", "name");
		map1.put("three", map);
		System.out.println(gson.toJson(map1));
		String json = "[\"name\",\"hello\"]";
		String j = "{\"data\":\"暂无最新通知\",\"data_type\":200}";
		JsonElement e = gson.fromJson(j, JsonElement.class);
		JsonObject o = gson.fromJson(j, JsonObject.class);
		String data = o.getAsJsonPrimitive("data").getAsString();
		System.out.println(data);
	}
}
