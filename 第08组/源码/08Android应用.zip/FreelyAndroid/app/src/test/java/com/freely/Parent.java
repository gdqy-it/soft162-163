package com.freely;

/**
 * @author DaWan
 * @time 2018/11/28 23:27
 * @dscription
 */
public class Parent {
	public static String testStatic = "ok";
	private String result;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "Parent{" +
				"result='" + result + '\'' +
				'}';
	}
}
