package com.example.zhw.piontandpiont2.Util;

//判断连接状态的枚举
public enum WsStatus {
    CONNECT_SUCCESS,//连接成功
    CONNECT_FAIL,//连接失败
    CONNECTING;//正在连接
}