package com.example.zhw.piontandpiont2.Networksockets;

public class AdressHttp {
    private static String url = "172.17.145.10:8080/";
    public static String getUrl(){
        return "http://"+url;
    }
}


