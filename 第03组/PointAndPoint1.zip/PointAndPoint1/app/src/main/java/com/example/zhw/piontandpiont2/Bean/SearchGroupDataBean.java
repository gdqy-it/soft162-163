package com.example.zhw.piontandpiont2.Bean;

public class SearchGroupDataBean {
    private String groupDesc,groupName,groupPortarit,groupUuid;

    public String getGroupDesc() {
        return groupDesc;
    }

    public String getGroupName() {
        return groupName;
    }

    public String getGroupPortarit() {
        return groupPortarit;
    }

    public String getGroupUuid() {
        return groupUuid;
    }
}
