package com.example.zhw.piontandpiont2.Bean;

public class ConnectMemberBean {
    private String userName,userPortrait,userPhone,uuid;

    public String getUserName() {
        return userName;
    }


    public String getUserPhone() {
        return userPhone;
    }

    public String getUuid() {
        return uuid;
    }

    public String getUserPortrait() {
        return userPortrait;
    }
}
